from odoo import _, api, fields, models


class ResPartner(models.Model):
    _inherit = "crm.lead"

    partner_id = fields.Many2one(
            'res.partner', string='Customer', check_company=True, index=True, tracking=10,
            domain="[('is_customer', '=', True),'|', ('company_id', '=', False), ('company_id', '=', company_id)]",
            help="Linked partner (optional). Usually created when converting the lead. You can find a partner by its Name, TIN, Email or Internal Reference.")