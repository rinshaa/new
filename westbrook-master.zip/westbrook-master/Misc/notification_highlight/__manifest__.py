{
    "name": "Notification Hightlighting ",
    "summary": "Be able to set sort in notification",
    "version": "16.0.1.0.1",
    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "license": "OPL-1",
    "version": "16.0.0.1",
    "depends": ["base","mail"],
    "data": [
        
            # 'security/ir.model.access.csv',
            # 'views/hr_employee.xml',
    ],
    'assets': {
        'mail.assets_messaging': [
                'notification_highlight/static/src/models/mail_activity_group_view.js',
                'notification_highlight/static/src/models/mails_activity_group.js',
        ],
        'web.assets_backend': [
            'notification_highlight/static/src/components/activity_menu_view.xml',
            'notification_highlight/static/src/components/activity_menu_view.scss',
        ],
        
        
    }
    
}