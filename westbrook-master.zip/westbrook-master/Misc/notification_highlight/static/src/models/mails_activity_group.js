/** @odoo-module **/

import { registerPatch } from '@mail/model/model_core';
import { attr } from '@mail/model/model_field';

registerPatch({
    name: 'ActivityGroup',
    modelMethods: {
        convertData(data) {
            return {
                actions: data.actions,
                domain: data.domain,
                irModel: {
                    iconUrl: data.icon,
                    id: data.id,
                    model: data.model,
                    name: data.name,
                },
                overdue_count: data.overdue_count,
                planned_count: data.planned_count,
                today_count: data.today_count,
                total_count: data.total_count,
                display_name :  data.display_name,
                type: data.type,
            };
        },
    },

    fields: {
        display_name: attr({
            default: [],
        }),

    },
    onChanges: [
        {
            dependencies: ['total_count', 'type', 'planned_count','display_name'],
            methodName: '_onChangeTotalCount',
        },
    ],

});


