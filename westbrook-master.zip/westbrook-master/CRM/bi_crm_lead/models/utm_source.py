from odoo import fields, api, models, _


class UtmSource(models.Model):
    _inherit = "utm.source"

    assign_user_id = fields.Many2one('res.users',string="User",domain=lambda self: ['|',("groups_id", "=", self.env.ref("bi_crm_lead.group_md").id),("groups_id", "=", self.env.ref("bi_crm_lead.group_sale_manager").id)])
    
            

            



    
    