{
    "name": "CRM Stages and related customisation",
    "summary": """
        CRM Stages and related customisation""",
    "description": """
         This module is used for the customisation related to crm stages in CRM.
             """,
    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "license": "OPL-1",
    "version": "16.0.0.1",
    "depends": ['crm', 'mail', 'contacts', 'bi_crm_lead', "utm"],
    "data": [
        'security/ir.model.access.csv',
        'security/crm_security_group.xml',
        'data/mail_template.xml',
        'data/crm_stages.xml',
        'data/notification_cron.xml',
        'views/notification_activity.xml',
        'views/crm_lead_view.xml',
        "views/crm_revision.xml",
        "views/crm_estimation.xml",
        "views/crm_lead_lost.xml",
        "views/crm_lead2opportunity.xml",
        # "views/mail_template.xml",
        "views/ir_attachments.xml",
        "wizard/bi_revision_wiz.xml",
        "wizard/bi_estimation_wiz.xml",
    ],
}
