# See LICENSE file for full copyright and licensing details.
import time
from odoo import fields, models
import string
from datetime import datetime


class CrmRevisionWiz(models.TransientModel):
    _name = "crm.revision.wiz"
    _description = "Revision"

    # Function to create desgin revision from wizard
    revision_reason = fields.Char('Reason')
    revision_attachment_ids = fields.Many2many("ir.attachment","revision_rel",string="Customer Feedback",track_visibility="always")
    crm_id = fields.Many2one('crm.lead', string='crm')

    def create_revision(self):       
        for vals in self:
            revision_obj = self.env["crm.lead.revision"]
            alphabet_string = string.ascii_uppercase
            alphabet_list = list(alphabet_string)
            i = 0
            existing_revision = revision_obj.search(
                [
                    ("crm_id", "=", vals.crm_id.id),
                ]
            )
            i = len(existing_revision)
            i+=1
            if vals.revision_reason:
                val = {
                    "name": vals.crm_id.name,
                    "partner_id": vals.crm_id.partner_id.id,
                    "email_from": vals.crm_id.email_from,
                    "attachment_ids": [(6, 0, vals.crm_id.attachment_ids.ids)],
                    "design_attachment_ids": [(6, 0, vals.crm_id.design_attachment_ids.ids)],
                    "phone": vals.crm_id.phone,
                    "design_lead_id": vals.crm_id.designing_lead_id.id,
                    "designer_ids": [(6, 0, vals.crm_id.designer_ids.ids)],
                    "source_id": vals.crm_id.source_id.id,
                    "salesman_user_id": vals.crm_id.user_id.id,
                    "crm_id": vals.crm_id.id,
                    "revision_no":vals.crm_id.revision_no,
                    "document_ids":[(6, 0, self.revision_attachment_ids.ids)],
                    "client_submit_date":vals.crm_id.submit_date,
                    "document_date":vals.crm_id.document_upload_date,
                    "revision_reason":vals.revision_reason
                }
            rev_history_id = revision_obj.create(val)
            vals.crm_id.write(
                {
                    "stage_id": 3,
                    "revision_reason":vals.revision_reason,
                    "design_attachment_ids":False,
                    "revision_no":alphabet_list[i],
                }
            )
            
            users  = []
            if vals.crm_id.user_id:
                users.append(vals.crm_id.user_id.id)
            if vals.crm_id.designing_lead_id:
                users.append(vals.crm_id.designing_lead_id.id)
            for each in users:
                model = self.env["ir.model"].search([("model", "=", "crm.lead")])
                data = {
                        "res_id":vals.crm_id.id,
                        "res_model_id":model.id,
                        "user_id": each,
                        "summary":"Design created for "+ str(vals.crm_id.name) +str(" ") + " have been requested for revision" ,
                        "activity_type_id": self.env.ref("bi_crm_stage.send_revision_notification").id,
                        }
                self.env["mail.activity"].sudo().create(data)
        for each_doc in self.revision_attachment_ids:
            each_doc.res_id = vals.crm_id.id