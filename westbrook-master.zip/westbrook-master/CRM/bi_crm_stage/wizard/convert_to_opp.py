from odoo import models

class ConvertToOpp(models.TransientModel):
    _inherit = "crm.lead2opportunity.partner"
    
    
    def action_apply(self):
        res = super(ConvertToOpp,self).action_apply()
        # record = self.env["crm.lead"].browse(self.lead_id.id)
        # notification_to = self.env['res.users'].search(['|',('groups_id','in',self.env.ref("bi_crm_lead.group_md").id),('groups_id','in',self.env.ref("bi_crm_lead.group_sale_manager").id)])
        # for each in notification_to:
        #     model = self.env["ir.model"].search([("model", "=", "crm.lead")])
        #     data = {
        #             "res_id": record.id,
        #             "res_model_id":model.id,
        #             "user_id": each.id,
        #             "summary":"Lead has been converted to opportunity",
        #             "activity_type_id": self.env.ref("bi_crm_stage.send_revision_notification").id,
        #         }
        #     self.env["mail.activity"].sudo().create(data)
        # anurag is cmd in 15/dec/23
        return res