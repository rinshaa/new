# See LICENSE file for full copyright and licensing details.
import time
from odoo import fields, models
import string
from datetime import datetime


class CrmEstimationWiz(models.TransientModel):
    _name = "crm.estimation.wiz"
    _description = "Estimation"

    # Function to create estimation from wizard
    estimation_reason = fields.Char('Reason')
    revision_attachment_ids = fields.Many2many("ir.attachment",string="Customer Feedback",track_visibility="always")
    estimation_attachment_id = fields.Many2many("ir.attachment","estimate_lr",string="Customer Feedback",track_visibility="always")

    crm_id = fields.Many2one('crm.lead', string='crm')
    
    def create_estimation(self):
        for vals in self:
            estimation_obj = self.env["crm.lead.estimation"]
            alphabet_string = string.ascii_uppercase
            alphabet_list = list(alphabet_string)
            i = 0
            existing_estimation = estimation_obj.search(
                [
                    ("crm_id", "=", vals.crm_id.id),
                ]
            )
            i = len(existing_estimation)
            i+=1
            if vals.estimation_reason:
                val = {
                    "name": vals.crm_id.name,
                    "partner_id": vals.crm_id.partner_id.id,
                    "email_from": vals.crm_id.email_from,
                    "attachment_ids": [(6, 0, vals.crm_id.attachment_ids.ids)],
                    "estimation_attachment_ids": [(6, 0, vals.crm_id.estimation_attachment_ids.ids)],
                    "phone": vals.crm_id.phone,
                    "estimation_lead_id": vals.crm_id.estimation_lead_id.id,
                    "estimater_ids": [(6, 0, vals.crm_id.estimater_ids.ids)],
                    "source_id": vals.crm_id.source_id.id,
                    "salesman_user_id": vals.crm_id.user_id.id,
                    "crm_id": vals.crm_id.id,
                    "revision_no":vals.crm_id.revision_no,
                    "document_ids":[(6, 0, self.estimation_attachment_id.ids)],
                    "approval_submit_date":vals.crm_id.approval_date,
                    "document_date":vals.crm_id.document_upload_date,
                    "estimation_reason":vals.estimation_reason
                }
            est_history_id = estimation_obj.create(val)
            vals.crm_id.write(
                {
                    "stage_id": 4,
                    "estimation_reason":vals.estimation_reason,
                    "estimation_attachment_ids":False,
                    "revision_no":alphabet_list[i],
                }
            )
            if vals.crm_id.estimation_lead_id:
                model = self.env["ir.model"].search([("model", "=", "crm.lead")])
                data = {
                        "res_id": vals.crm_id.id,
                        "res_model_id":model.id,
                        "user_id": vals.crm_id.estimation_lead_id.id,
                        "summary":str(vals.crm_id.name)+" has been requested to revise by the customer",
                        "activity_type_id": self.env.ref("bi_crm_stage.send_revision_notification").id,
                    }
                self.env["mail.activity"].sudo().create(data)
            if vals.crm_id.estimater_ids:
                estimators = vals.crm_id.estimater_ids
                for each in estimators:
                    model = self.env["ir.model"].search([("model","=","crm.lead")])
                    data = {
                            "res_id":vals.crm_id.id,
                            "res_model_id":model.id,
                            "user_id":each.id,
                            "summary":str(vals.crm_id.name)+" has been requested to revise by the customer",
                            "activity_type_id":self.env.ref("bi_crm_stage.send_revision_notification").id,
                        }
                    self.env["mail.activity"].sudo().create(data)
                    
            users  = []
            if vals.crm_id.user_id:
                users.append(vals.crm_id.user_id.id)
            if vals.crm_id.estimation_lead_id:
                users.append(vals.crm_id.estimation_lead_id.id)
            for each in users:
                model = self.env["ir.model"].search([("model", "=", "crm.lead")])
                data = {
                        "res_id":vals.crm_id.id,
                        "res_model_id":model.id,
                        "user_id": each,
                        "summary":"Estimation created for "+ str(vals.crm_id.name) +str(" ") + " have been requested for revision" ,
                        "activity_type_id": self.env.ref("bi_crm_stage.send_revision_notification").id,
                        }
                self.env["mail.activity"].sudo().create(data)
        
        
            
        
