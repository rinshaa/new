from odoo import models, api, fields

class CrmEstimationDocuments(models.Model):
    _name = "crm.estimation.documents"
    _description = "Crm Estimation Documents"
    
    crm_lead_id = fields.Many2one('crm.lead', string="Lead")
    estimator_id = fields.Many2one('res.users', string="Estimator")
    is_estimator_doc = fields.Boolean(string="Is Designer Documents", default=False, compute="_compute_estimation_docs")
    estimation_attachment_ids = fields.Many2many(
            "ir.attachment", 
            "design_attach_doc6_rel", 
            string="Estimation Documents",
            track_visibility="always",
            tracking=True
            )
    
    @api.depends('is_estimator_doc')
    def _compute_estimation_docs(self):
        user = self.env.user.id
        for each in self:
        # if self.env.user.has_group("bi_crm_lead.group_estimator_crm_security"):
            if user == each.estimator_id.id or self.env.user.has_group("bi_crm_lead.group_estimator_crm_security")==user:
                each.is_estimator_doc = True
            else:
                each.is_estimator_doc = False


    @api.model
    def write(self, vals):
        res = super(CrmEstimationDocuments, self).write(vals)   
        if 'estimation_attachment_ids' in vals:
                    users = []
                    if self.crm_lead_id.user_id:
                        users.append(self.crm_lead_id.user_id.id)
                    if self.crm_lead_id.designing_lead_id:
                        users.append(self.crm_lead_id.estimation_lead_id.id)
                    for each in users:
                        model = self.env["ir.model"].search([("model", "=", "crm.lead")])
                        data = {
                                    "res_id": self.crm_lead_id.id,
                                    "res_model_id": model.id,
                                    "user_id": each,
                                    "summary":str(len(vals['estimation_attachment_ids'][0][2]))+" Documents uploaded by " +str(self.estimator_id.name) +" against " +self.crm_lead_id.display_name,
                                    "activity_type_id": self.env.ref("bi_crm_stage.send_revision_notification").id,
                                }
                        self.env["mail.activity"].sudo().create(data)
        return res