from odoo import models,fields, api

class ResPartner(models.Model):
    _inherit = "res.partner"
    
    user_id = fields.Many2one(
        'res.users', string='Account Manager',
        compute='_compute_user_id',
        precompute=True,  # avoid queries post-create
        readonly=False, store=True,
        default=lambda self: self.env.user,
        help='The internal user in charge of this contact.')

    @api.model
    def search_read(self, domain=None, fields=None, offset=0, limit=None, order=None):
        if self.env.user.has_group('bi_crm_stage.group_salesperson_own_customer'):
            domain += ['|', ('user_id', '=', self.env.user.id), ('user_id', '=', False)]
        return super(ResPartner, self).search_read(domain, fields, offset, limit, order)
