from odoo import models,fields


class CrmLeadEstimation(models.Model):
    _name = "crm.lead.estimation"

    name = fields.Char('Name')
    partner_id = fields.Many2one('res.partner', string='Customer')
    email_from = fields.Char('Email From')
    phone = fields.Char('Phone')
    estimation_lead_id = fields.Many2one('res.users', string='Estimation Lead')
    estimater_ids = fields.Many2many('res.users', string='Estimater')

    estimation_attachment_ids = fields.Many2many(
        "ir.attachment", "estimation_attachment_rel", string="Estimation Documents", track_visibility="always"
    )
    source_id = fields.Many2one('utm.source', string='Source')
    salesman_user_id = fields.Many2one("res.users", string="Salesman")
    attachment_ids = fields.Many2many('ir.attachment', "estimation_attachment_rel2", string='Attach a file')
    crm_id = fields.Many2one('crm.lead', string='crm')
    revision_no = fields.Char(string ="Revision No." , default="A")
    date = fields.Date(string="Revision Date",default=fields.Date.context_today)
    document_date = fields.Date(string="Document Uploaded Date") 
    approval_submit_date = fields.Date(string="Approval Date")  
    estimation_reason = fields.Char(string="Revision Reason")
    document_ids = fields.Many2many("ir.attachment", string="Customer Feedback", track_visibility="always",tracking=True)
