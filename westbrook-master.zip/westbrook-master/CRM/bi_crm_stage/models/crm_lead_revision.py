from odoo import models,fields


class CrmLeadRevision(models.Model):
    _name = "crm.lead.revision"

    name = fields.Char('Name')
    partner_id = fields.Many2one('res.partner', string='Customer')
    email_from = fields.Char('Email From')
    phone = fields.Char('Phone')
    design_lead_id = fields.Many2one('res.users', string='Design Lead')
    designer_ids = fields.Many2many('res.users',"designer_doc_rel", string='Designer')
    dead_line_date = fields.Date(string="Dead Line")

    design_attachment_ids = fields.Many2many(
        "ir.attachment", "design_attach_doc1_rel", string="Design Documents", track_visibility="always",tracking=True
    )
    source_id = fields.Many2one('utm.source', string='Source')
    salesman_user_id = fields.Many2one("res.users",string="Salesman")
    attachment_ids = fields.Many2many('ir.attachment',"attachment_doc_rel",string='Attach a file')
    crm_id = fields.Many2one('crm.lead', string='crm')
    revision_no = fields.Char(string ="Revision No." , default="A")
    date = fields.Date(string="Revision Date",default=fields.Date.context_today)
    document_date = fields.Date(string="Document Uploaded Date") 
    client_submit_date = fields.Date(string="Submit Date") 
    document_ids = fields.Many2many(
        "ir.attachment", "attach_doc1_rel_two", string="Customer Feedback", track_visibility="always",tracking=True
    )
    revision_reason = fields.Char(string="Revision Reason")
