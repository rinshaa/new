from odoo import models, fields,api
from datetime import datetime

class CrmEstimatorDeadline(models.Model):
    _name = "crm.estimator.deadline"
    _description = "Crm Estimator Deadline"
    
    estimator_lead_id = fields.Many2one('crm.lead', string="Estimator Lead")
    estimator_id = fields.Many2one('res.users', string="Estimator")
    dead_line_date = fields.Date(string="DeadLine Date")
    is_status = fields.Boolean(string="Is Status", default= False,compute="_compute_is_estimator")
    is_est = fields.Boolean(string="Is Estimator", default= False,compute="_compute_is_estimator")
    status = fields.Selection([('ongoing', 'Ongoing'), ('hold', 'Hold'),('complete', 'Completed')],string="Status")
    is_notification = fields.Boolean(string = "Is Notification", default=False)
    is_deadline = fields.Boolean(string="Is Deadline", default=False)
    
    def _compute_is_estimator(self):
        user = self.env.user.id
        for rec in self:
            if user == rec.estimator_id.id or rec.estimator_lead_id.estimation_lead_id.id==user:
                rec.is_status = True
            else:
                rec.is_status = False
            if rec.estimator_lead_id.estimation_lead_id.id==user:
                rec.is_est = True
            else:
                rec.is_est = False
    
    @api.depends('is_estimator_doc')
    def _compute_estimation_docs(self):
        if self.env.user.has_group("bi_crm_lead.group_estimator_crm_security"):
            for each in self:
                each.is_estimator_doc = True
        else:
            for each in self:
                each.is_estimator_doc = False
                
    @api.model
    def write(self, vals):
        res = super(CrmEstimatorDeadline, self).write(vals)
        if self.env.user.id== self.estimator_lead_id.estimation_lead_id.id:
            if 'status' in vals:
                users = []
                if self.estimator_lead_id.user_id:
                    users.append(self.estimator_lead_id.user_id.id)
                if self.estimator_id:
                    users.append(self.estimator_id.id)
                for each in users:
                    model = self.env["ir.model"].search([("model", "=", "crm.lead")])
                    data = {
                                "res_id": self.estimator_lead_id.id,
                                "res_model_id": model.id,
                                "user_id": each,
                                "summary":" Deadline Status for " +str(self.estimator_id.name) +" changed to " +str(self.status),
                                "activity_type_id": self.env.ref("bi_crm_stage.send_revision_notification").id,
                            }
                    self.env["mail.activity"].sudo().create(data)
        else:
            if 'status' in vals:
                users = []
                if self.estimator_lead_id.user_id:
                    users.append(self.estimator_lead_id.user_id.id)
                if self.estimator_lead_id.estimation_lead_id:
                    users.append(self.estimator_lead_id.estimation_lead_id.id)
                for each in users:
                    model = self.env["ir.model"].search([("model", "=", "crm.lead")])
                    data = {
                                "res_id": self.estimator_lead_id.id,
                                "res_model_id": model.id,
                                "user_id": each,
                                "summary":" Deadline Status for " +str(self.estimator_id.name) +" changed to " +str(self.status),
                                "activity_type_id": self.env.ref("bi_crm_stage.send_revision_notification").id,
                            }
                    self.env["mail.activity"].sudo().create(data)
                
        return res