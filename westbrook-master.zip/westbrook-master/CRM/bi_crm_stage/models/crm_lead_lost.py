
from odoo import fields, models, _


class CrmLeadLost(models.TransientModel):
    _inherit = 'crm.lead.lost'
    
    pipeline_id = fields.Many2one('crm.lead',string="Pipeline")
    
    def action_lost_reason_apply(self):
        res = super(CrmLeadLost,self).action_lost_reason_apply()
        stage = self.env["crm.stage"].search(
                [("name", "=", "Lost")]
            )
        self.pipeline_id.stage_id = stage.id
        self.pipeline_id.is_lost_hide = True
        return res