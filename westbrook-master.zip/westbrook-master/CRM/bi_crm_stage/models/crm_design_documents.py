from odoo import models, api, fields

class CrmDesinerDocuments(models.Model):
    _name = "crm.desiner.documents"
    _description = "Crm Desiner Documents"
    
    crm_lead_id = fields.Many2one('crm.lead', string="Lead")
    designer_id = fields.Many2one('res.users', string="Designers")
    is_designer_doc = fields.Boolean(string="Is Designer Documents", default=False, compute="_compute_designer_docs")
    design_attachment_ids = fields.Many2many(
            "ir.attachment", 
            "design_attach_doc5_rel", 
            string="Design Documents",
            track_visibility="always",
            tracking=True
            )
    
    @api.depends('is_designer_doc')
    def _compute_designer_docs(self):
        user = self.env.user.id
        for each in self:
        # if self.env.user.has_group("bi_crm_lead.group_designer_crm_security"):
            if user == each.designer_id.id or self.env.user.has_group("bi_crm_lead.group_designing_lead")==user:
                each.is_designer_doc = True
            else:
                each.is_designer_doc = False

    @api.model
    def write(self, vals):
        res = super(CrmDesinerDocuments, self).write(vals)   
        if 'design_attachment_ids' in vals:
                    users = []
                    if self.crm_lead_id.user_id:
                        users.append(self.crm_lead_id.user_id.id)
                    if self.crm_lead_id.designing_lead_id:
                        users.append(self.crm_lead_id.designing_lead_id.id)
                    for each in users:
                        model = self.env["ir.model"].search([("model", "=", "crm.lead")])
                        data = {
                                    "res_id": self.crm_lead_id.id,
                                    "res_model_id": model.id,
                                    "user_id": each,
                                    "summary":str(len(vals['design_attachment_ids'][0][2]))+" Documents uploaded by " +str(self.designer_id.name) +" against " +self.crm_lead_id.display_name,
                                    "activity_type_id": self.env.ref("bi_crm_stage.send_revision_notification").id,
                                }
                        self.env["mail.activity"].sudo().create(data)
        return res
       