from odoo import models, api, fields

class CrmDesinerDeadline(models.Model):
    _name = "crm.desiner.deadline"
    _description = "Crm Desiner Deadline"
    
    lead_id = fields.Many2one('crm.lead', string="Lead")
    designer_id = fields.Many2one('res.users', string="Designers")
    dead_line_date = fields.Date(string="Dead Line")
    is_status = fields.Boolean(string="Is Status", default= False, compute="_compute_is_status")
    is_des = fields.Boolean(string="Is Designer", default= False, compute="_compute_is_status")
    status = fields.Selection([('ongoing', 'Ongoing'), ('hold', 'Hold'),('complete', 'Completed')],string="Status")
    is_designer = fields.Boolean(string="Is Designer", default=False)
    is_notified = fields.Boolean(string="Is Notified", default=False)
    is_deadline = fields.Boolean(string="Is Deadline", default=False)
    
    def _compute_is_status(self):
        user = self.env.user.id
        for rec in self:
            if user == rec.designer_id.id or rec.lead_id.designing_lead_id.id==user:
                rec.is_status = True
            else:
                rec.is_status = False
            if rec.lead_id.designing_lead_id.id==user:
                rec.is_des = True
            else:
                rec.is_des = False

    @api.model
    def write(self, vals):
        res = super(CrmDesinerDeadline, self).write(vals)
        if self.env.user.id== self.lead_id.designing_lead_id.id:
            if 'status' in vals:
                users = []
                if self.lead_id.user_id:
                    users.append(self.lead_id.user_id.id)
                if self.designer_id:
                    users.append(self.designer_id.id)
                for each in users:
                    model = self.env["ir.model"].search([("model", "=", "crm.lead")])
                    data = {
                                "res_id": self.lead_id.id,
                                "res_model_id": model.id,
                                "user_id": each,
                                "summary":" Deadline Status for " +str(self.designer_id.name) +" changed to " +str(self.status),
                                "activity_type_id": self.env.ref("bi_crm_stage.send_revision_notification").id,
                            }
                    self.env["mail.activity"].sudo().create(data)
        else:
            if 'status' in vals:
                users = []
                if self.lead_id.user_id:
                    users.append(self.lead_id.user_id.id)
                if self.lead_id.designing_lead_id:
                    users.append(self.lead_id.designing_lead_id.id)
                for each in users:
                    model = self.env["ir.model"].search([("model", "=", "crm.lead")])
                    data = {
                                "res_id": self.lead_id.id,
                                "res_model_id": model.id,
                                "user_id": each,
                                "summary":" Deadline Status for " +str(self.designer_id.name) +" changed to " +str(self.status),
                                "activity_type_id": self.env.ref("bi_crm_stage.send_revision_notification").id,
                            }
                    self.env["mail.activity"].sudo().create(data)
        return res