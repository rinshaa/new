from odoo import models,fields,api,_
from odoo.exceptions import UserError
import base64
from datetime import datetime
from dateutil.relativedelta import relativedelta

class CrmLead(models.Model):
    _inherit = "crm.lead"

    def _default_group_ids(self):
        """
        Default method for group_ids: taken from default user
        """
        default_accountant_id = self.env["res.users"].search([("groups_id",'=', self.env.ref("bi_crm_lead.group_accountant_crm_security").id)])
        return default_accountant_id

    attachment_ids = fields.Many2many(comodel_name='ir.attachment',string='Attach a file')
    designing_lead_id = fields.Many2one(comodel_name='res.users', string="Designing Lead",domain=lambda self: [("groups_id", "=", self.env.ref("bi_crm_lead.group_designing_lead").id)])
    furniture_lead_id = fields.Many2one(comodel_name='res.users', string="Furniture Lead",domain=lambda self: [("groups_id", "=", self.env.ref("bi_crm_lead.group_furniture_team_crm_security").id)])
    designer_ids = fields.Many2many("res.users", string="Designers",domain=lambda self: [("groups_id", "=", self.env.ref("bi_crm_lead.group_designer_crm_security").id)])
    dead_line_date = fields.Date(string="Dead Line")
    estimater_ids = fields.Many2many("res.users","estimator_user_rel", string="Estimators",domain=lambda self: [("groups_id", "=", self.env.ref("bi_crm_lead.group_estimator_crm_security").id)])
    is_designers = fields.Boolean(string="Is Designers", default=False)
    is_design_lead = fields.Boolean(string="Is Design Lead", default=False)
    is_esti_lead = fields.Boolean(string="Is Estimation Lead", default=False)
    is_estimaters = fields.Boolean(string="Is Estimators", default=False)
    estimation_lead_id = fields.Many2one(comodel_name='res.users', string="Estimation Lead" ,domain=lambda self: [("groups_id", "=", self.env.ref("bi_crm_lead.group_estimation_crm_security").id)])
    estimation_lead_one_id= fields.Many2one(comodel_name='res.users', string="Estimation Lead 1")
    estimation_lead_two_id = fields.Many2one(comodel_name='res.users', string="Estimation Lead 2")
    estimation_lead_three_id = fields.Many2one(comodel_name='res.users', string="Estimation Lead 3")
    re_assign_to_id = fields.Many2one(comodel_name="res.users", string="Account Manager", help="'Reassign To 'a user by the 'Salesperson'.")
    is_md = fields.Boolean("Is MD",default=False,copy=False,compute="_compute_is_md")
    design_attachment_ids = fields.Many2many(
        "ir.attachment", "design_attach_doc_rel", string="Design Documents", track_visibility="always",tracking=True
    )
    furniture_attachment_ids = fields.Many2many(
        "ir.attachment", "furniture_attach_doc_rel", string="Furniture Documents", track_visibility="always"
    )
    is_salesmanager = fields.Boolean("Is Sales Manager",default=False,copy=False,compute="_compute_is_md")
    is_designlead = fields.Boolean("Is Design Lead",default=False,copy=False,compute="_compute_is_md")
    is_estimation_lead = fields.Boolean("Is Estimation Lead",default=False,copy=False,compute="_compute_is_md")
    revision_reason = fields.Char('Reason',track_visibility='always')
    estimation_reason = fields.Char('Reason',track_visibility='always')
    estimation_attachment_ids = fields.Many2many(
        "ir.attachment", "estimation_attach_doc_rel", string="Estimation Documents", track_visibility="always"
    )
    previous_stage_id = fields.Many2one('crm.stage', string='Previous Stage')
    revision_history_ids = fields.One2many('crm.lead.revision', 'crm_id', string='Revision History')
    estimation_history_ids = fields.One2many('crm.lead.estimation', 'crm_id', string='Revision History')
    revision_no = fields.Char(string ="Revision No." , default="A")
    designer_deadline_ids = fields.One2many('crm.desiner.deadline', 'lead_id' ,string="Designer Deadline")
    designer_documents_ids = fields.One2many('crm.desiner.documents', 'crm_lead_id' ,string="Designer Documents")
    estimation_documents_ids = fields.One2many('crm.estimation.documents', 'crm_lead_id' ,string="Estimator Documents")
    estimator_deadline_ids = fields.One2many('crm.estimator.deadline', 'estimator_lead_id', string="Estimator Deadline")
    assign_boolean = fields.Boolean(default=False)
    is_submit = fields.Boolean(
        string='is_submit',default=False,copy=False,compute="_compute_stage_submit_to_client"
    )
    is_hold = fields.Boolean(
        string='Is Hold',compute="_compute_stage_submit_to_client"
    )
    is_estimate = fields.Boolean(
        string='is_estimate',default=False,copy=False,compute="_compute_stage_submit_to_client"
    )
    is_submit_approval = fields.Boolean(
        string='Is Approved',default=False,copy=False
    )
    is_submit_approval_estimation = fields.Boolean(
        string='Is Submit Approved',default=False,copy=False
    )
    is_user = fields.Boolean(
        string='Is User',default=False,copy=False
    )
    is_job_card = fields.Boolean(default=False)
    job_card_number = fields.Char(string="Job Card Number")
    is_decision_making = fields.Boolean(default=False)
    decision_making = fields.Selection([('customer_with_design', 'Customer With Design'), ('customer_without_design', 'Customer Without Design')])
    is_lost_hide = fields.Boolean(default=False)
    is_design_lead_true = fields.Boolean(default=False)
    is_estimation_lead_true = fields.Boolean(default=False)
    is_accountant = fields.Boolean(default=False)
    operations_manager_id = fields.Many2one('res.users', string="Operations Lead",domain=lambda self: [("groups_id", "=", self.env.ref("bi_crm_lead.group_operations_crm_security").id)])
    project_manager_id = fields.Many2one('res.users', string="Project Lead",domain=lambda self: [("groups_id", "=", self.env.ref("bi_crm_lead.group_project_crm_security").id)])
    project_lead = fields.Char(
        string='Project Lead',
    )
    accountant_lead_id = fields.Many2one(comodel_name='res.users', string="Accountant" , default=_default_group_ids,domain=lambda self: [("groups_id", "=", self.env.ref("bi_crm_lead.group_accountant_crm_security").id)])
    user_id = fields.Many2one(
        'res.users', string='Account Manager',domain=lambda self: [("groups_id", "=", self.env.ref("bi_crm_lead.group_sales_person_crm_security").id)])
    is_estimation = fields.Boolean(string="Estimation", default=False)
    is_furniture = fields.Boolean(string="Furniture", default=False)
    document_upload_date = fields.Date(string="Document Upload Date")
    submit_date = fields.Date(string="submit date")
    approval_date = fields.Date(string="Approval Date")
    account_manager_attachment_ids = fields.Many2many("ir.attachment", "account_manager_attach_doc_rel", track_visibility="always",tracking=True)
    is_job_card_issue = fields.Boolean(string="Is Job Card Issue", compute="_compute_stage_job_card", default=False)
    decor_value = fields.Float(string="Decor value")
    location = fields.Char(string="Location")
    building_name = fields.Char(string="Bulding Name/Number")
    office_num = fields.Char(string="Office/Unit Number")

    # char_stage = fields.Char(compute="_compute_is_stage_id")

    @api.onchange('design_attachment_ids')
    def _onchange_design_attachment(self):
        self.document_upload_date =  fields.Date.today()


    def _compute_stage_job_card(self):
        for order in self:
            order.is_job_card_issue = False
            if self.env.user.has_group("bi_crm_lead.group_accountant_crm_security"):
                if order.stage_id.name == "Job Card Issue":
                    order.is_job_card_issue = True
                else:
                    order.is_job_card_issue = False
            else:
                order.is_job_card_issue = False

    @api.onchange('designer_ids')
    def _onchange_action_designer_deadline(self):
        designers = []
        self.designer_deadline_ids =False
        # unlink removed designers
        for line in self.designer_deadline_ids:
            if line.designer_id not in self.designer_ids :
                line.unlink()
        # add new designers
        for designer in self.designer_ids:
            if designer not in self.designer_deadline_ids.mapped('designer_id'):
                designers.append((0,0,{"designer_id": designer.id}))
        self.designer_deadline_ids = designers
        
    def action_designer_deadline(self):
        designers = []
        # unlink removed designers
        for line in self.designer_deadline_ids:
            if line.designer_id not in self.designer_ids :
                line.unlink()
        # add new designers
        for designer in self.designer_ids:
            if designer not in self.designer_deadline_ids.mapped('designer_id'):
                designers.append((0,0,{"designer_id": designer.id}))
        self.designer_deadline_ids = designers
        
    @api.onchange('designer_ids')
    def _onchange_action_attach_design_documents(self):
        designers = []
        # unlink removed designers
        self.designer_documents_ids =False
        for line in self.designer_documents_ids:
            if line.designer_id not in self.designer_ids :
                line.unlink()
        # add new designers
        for designer in self.designer_ids:
            if designer not in self.designer_documents_ids.mapped('designer_id'):
                designers.append((0,0,{"designer_id": designer.id}))
        self.designer_documents_ids = designers

    def action_attach_design_documents(self):
        designers = []
        # unlink removed designers
        for line in self.designer_documents_ids:
            if line.designer_id not in self.designer_ids :
                line.unlink()
        # add new designers
        for designer in self.designer_ids:
            if designer not in self.designer_documents_ids.mapped('designer_id'):
                designers.append((0,0,{"designer_id": designer.id}))
        self.designer_documents_ids = designers
    @api.onchange('estimater_ids')
    def _onchange_action_attach_estimator_documents(self):
        estimators = []
        self.estimation_documents_ids = False
        for line in self.estimation_documents_ids:
            if line.estimator_id not in self.estimater_ids :
                line.unlink()
        for estimator in self.estimater_ids:
            if estimator not in self.estimation_documents_ids.mapped('estimator_id'):
                estimators.append((0,0,{"estimator_id": estimator.id}))
        self.estimation_documents_ids = estimators
    def action_attach_estimator_documents(self):
        estimators = []
        # unlink removed estimators
        for line in self.estimation_documents_ids:
            if line.estimator_id not in self.estimater_ids :
                line.unlink()
        # add new estimators
        for estimator in self.estimater_ids:
            if estimator not in self.estimation_documents_ids.mapped('estimator_id'):
                estimators.append((0,0,{"estimator_id": estimator.id}))
        self.estimation_documents_ids = estimators
    @api.onchange('estimater_ids')
    def _onchange_action_estimator_deadline(self):
        estimators = []
        self.estimator_deadline_ids = False
        # unlink removed estimators
        for line in self.estimator_deadline_ids:
            if line.estimator_id not in self.estimater_ids:
                line.unlink()
        # add new estimator
        for estimator in self.estimater_ids:
            if estimator not in self.estimator_deadline_ids.mapped('estimator_id'):
                estimators.append((0,0,{"estimator_id": estimator.id}))
        self.estimator_deadline_ids = estimators
        
    def action_estimator_deadline(self):
        estimators = []
        # unlink removed estimators
        for line in self.estimator_deadline_ids:
            if line.estimator_id not in self.estimater_ids:
                line.unlink()
        # add new estimator
        for estimator in self.estimater_ids:
            if estimator not in self.estimator_deadline_ids.mapped('estimator_id'):
                estimators.append((0,0,{"estimator_id": estimator.id}))
        self.estimator_deadline_ids = estimators
            
    
    @api.onchange("is_estimation")
    def _onchange_is_estimate(self):
        for each in self:
            if each.is_estimation == False:
                each.estimation_lead_id = False
                
                
    @api.onchange("is_furniture")
    def _onchange_is_furniture(self):
        for each in self:
            if each.is_furniture == False:
                each.furniture_lead_id = False 


    @api.model
    def default_get(self, fields):
        res = super(CrmLead, self).default_get(fields)
        if "user_id" in res:
            res["user_id"] = False
        stage_obj = self.env["crm.stage"].search([('name','=','Estimation')])
        if "type" in res and res['type'] == "opportunity":
            res.update({"stage_id":stage_obj.id})
        return res
    
    # @api.depends("stage_id")
    # def _compute_is_stage_id(self):
    #     for rec in self:
    #         if rec.stage_id:
    #             rec.char_stage = rec.stage_id.name
    #         else:
    #             rec.char_stage = False    
    # @api.onchange("char_stage")
    # def _onchange_is_stage_id(self):
    #     domain = []
    #     if self.stage_id.id == 3 :
    #         domain.append(('id','in',[10,11,12,13]))
    #         domain = {"domain":{"stage_id":domain}}
    #         return domain

    @api.onchange('source_id')
    def _onchange_res_users(self):
        for rec in self:
            if rec.source_id.name == "Account Manager":
                rec.re_assign_to_id = self.env.user.id
                rec.user_id = self.env.user.id
                rec.assign_boolean = True
            else:
                rec.re_assign_to_id = self.env.user.id
                rec.user_id = self.env.user.id
    @api.onchange('decision_making')
    def _onchange_decision_making(self):
        for rec in self:
            design_stage = self.env["crm.stage"].search(
                    [("name", "=", "Design")])
            estimation_stage = self.env["crm.stage"].search(
                    [("name", "=", "Estimation")])
            if rec.decision_making == "customer_with_design":
                rec.stage_id = estimation_stage.id
            elif rec.decision_making == "customer_without_design":
                rec.stage_id = design_stage.id

    @api.depends('user_id')
    def _compute_is_md(self):
        for record in self:
            record.is_md = False
            record.is_salesmanager = False
            record.is_designlead = False
            record.is_estimation_lead = False
            record.is_design_lead_true = False
            record.is_estimation_lead_true = False
            record.is_accountant = False
            record.is_user = False
            if self.env.user.has_group("bi_crm_lead.group_accountant_crm_security"):
                record.is_accountant = True
            if self.env.user.id == record.user_id.id:
                record.is_design_lead_true = True
                record.is_estimation_lead_true = True
                record.is_user = True
            if self.env.user.id == self.re_assign_to_id.id:
                record.is_md = True
            if self.env.user.has_group("bi_crm_lead.group_sale_manager"):
                record.is_salesmanager = True
            if self.env.user.has_group("bi_crm_lead.group_designing_lead"):
                record.is_designlead = True
            if self.env.user.has_group("bi_crm_lead.group_estimation_crm_security"):
                record.is_estimation_lead = True

    def action_meeting_scheduled(self):
        # if not self.attachment_ids:
        #     raise UserError(_("Please upload Document"))
        stage = self.env["crm.stage"].search(
                [("name", "=", "Meetings Scheduled")]
            )
        # if self.user_id:
        #     notification_to = self.env['res.users'].search(['|',('groups_id','in',self.env.ref("bi_crm_lead.group_md").id),('groups_id','in',self.env.ref("bi_crm_lead.group_sale_manager").id)])
        #     for each in notification_to:
        #         model = self.env["ir.model"].search([("model", "=", "crm.lead")])
        #         data ={
        #             "res_id":self.id,
        #             "res_model_id":model.id,
        #             "user_id":each.id,
        #             "summary":str(self.name) +  " is moved from the stage " + self.stage_id.name + " to " + stage.name + " by " + self.user_id.name,
        #             "activity_type_id": self.env.ref("bi_crm_stage.send_meeting_shedule").id,
        #         }
        #         self.env["mail.activity"].sudo().create(data)
        self.stage_id = stage.id
            
        #     mail_content = str(self.name) +  " is moved from the stage " + self.stage_id.name + " to " + stage.name + " by " + self.user_id.name
        # else:
        #     mail_content = str(self.name) +  " is moved from the stage " + self.stage_id.name + " to " + stage.name
        # salesperson_name = str(self.user_id.name)
        # partner = []
        # mail_to = self.env['res.users'].search(['|',
        #                 ('groups_id','in',self.env.ref("bi_crm_lead.group_md").id),
        #                 ('groups_id','in',self.env.ref("bi_crm_lead.group_sale_manager").id),
        #                 ])
        # partners_obj = mail_to.mapped("partner_id")
        # main_content = {
        #     'subject':_('Stage moved by Salesperson, %s') % (salesperson_name),
        #     'author_id':self.env.user.partner_id.id,
        #     'body_html':mail_content,
        #     'recipient_ids':[(6,0,partners_obj.ids)],
        # }
        # mail_id = self.env['mail.mail'].sudo().create(main_content)
        # mail_id.write({"unrestricted_attachment_ids":[(6, 0, self.attachment_ids.ids)]})
        # mail_id.send()
        

    def action_design(self):
        stage = self.env["crm.stage"].search(
                [("name", "=", "Design")]
            )
        # if self.user_id:
        #     notification_to = self.env['res.users'].search(['|',('groups_id','in',self.env.ref("bi_crm_lead.group_md").id),('groups_id','in',self.env.ref("bi_crm_lead.group_sale_manager").id)])
        #     for each in notification_to:
        #         model = self.env["ir.model"].search([("model", "=", "crm.lead")])
        #         data ={
        #             "res_id":self.id,
        #             "res_model_id":model.id,
        #             "user_id":each.id,
        #             "summary":str(self.name) +  " is moved from the stage " + self.stage_id.name + " to " + stage.name + " by " + self.user_id.name,
        #             "activity_type_id": self.env.ref("bi_crm_stage.send_meeting_shedule").id,
        #         }
        #         self.env["mail.activity"].sudo().create(data)
        self.stage_id = stage.id
        # mail_content = str(self.name) +  " is moved from the stage " + self.stage_id.name + " to " + stage.name + " by " + self.user_id.name
        # salesperson_name = str(self.user_id.name)
        # mail_to = self.env['res.users'].search(['|','|',
        #                 ('groups_id','in',self.env.ref("bi_crm_lead.group_md").id),
        #                 ('groups_id','in',self.env.ref("bi_crm_lead.group_sale_manager").id),
        #                 ('id', '=', self.designing_lead_id.id)
        #                 ])
        # partners_obj = mail_to.mapped("partner_id")
        # main_content = {
        #     'subject':_('Stage moved by Salesperson, %s') % (salesperson_name),
        #     'author_id':self.env.user.partner_id.id,
        #     'body_html':mail_content,
        #     'recipient_ids':[(6,0,partners_obj.ids)],
        # }
        # self.env['mail.mail'].sudo().create(main_content).send()
        self.stage_id = stage.id
    def action_furniture(self):
        stage = self.env["crm.stage"].search(
                [("name", "=", "Furniture")]
            )
        if self.user_id:
            notification_to = self.env['res.users'].search(['|',('groups_id','in',self.env.ref("bi_crm_lead.group_md").id),('groups_id','in',self.env.ref("bi_crm_lead.group_sale_manager").id)])
            for each in notification_to:
                model = self.env["ir.model"].search([("model", "=", "crm.lead")])
                data={
                    "res_id": self.id,
                    "res_model_id":model.id,
                    "user_id": each.id,
                    "summary":str(self.name) +  " is moved from the stage " + self.stage_id.name + " to " + stage.name + " by " + self.user_id.name,
                    "activity_type_id": self.env.ref("bi_crm_stage.send_revision_notification").id,
                }
                self.env["mail.activity"].sudo().create(data)
            self.stage_id = stage.id
      
    def action_assign_designers(self):
        designers = []
        for designer in self.designer_ids:
            if designer not in self.designer_deadline_ids.mapped('designer_id'):
                raise UserError(_("Please load the designers in the 'Designers Deadline' lines..."))
        if not self.designer_ids:
            raise UserError(_("Please select designer"))
        ##.... notification - for the designers which are added in the 'Designer Deadline' lines....##
        if self.designer_deadline_ids:
            for rec in self.designer_deadline_ids:
                # if not rec.dead_line_date:
                #     raise UserError(_("Please add a 'deadline date' for the assigned designer %s...!") % (rec.designer_id.name))
                model = self.env["ir.model"].search([("model", "=", "crm.lead")])
                if rec.is_notified == False:
                    assignment_data = {
                        "res_id" : self.id,
                        "res_model_id" : model.id,
                        "user_id" : rec.designer_id.id,
                        "summary": f"{rec.designer_id.name} has been assigned to the project '{self.name}'.",
                        "activity_type_id": self.env.ref("bi_crm_stage.send_designer_assign_notification_activity").id,
                    }
                    self.env["mail.activity"].sudo().create(assignment_data)
                    rec.is_notified = True
                if rec.is_deadline == False and rec.dead_line_date:
                    deadline_data = {
                            "res_id": self.id,
                            "res_model_id":model.id,
                            "user_id": rec.designer_id.id,
                            "summary":" Your Dead Line Is" + str(" ")+ rec.dead_line_date.strftime('%d-%m-%Y'),
                            "activity_type_id": self.env.ref("bi_crm_stage.send_dead_line_notification_activity").id,
                            }
                    self.env["mail.activity"].sudo().create(deadline_data)
                    rec.is_deadline = True                
        else:
            raise UserError(_("Please load the designers and add their deadline in 'Designers Deadline' lines...!"))
        ####
        # mail_content = str(self.user_id.name) +  " assigned designers for " + self.name
        # design_lead = str(self.designing_lead_id.name)
        # mail_to = self.env['res.users'].search(['|',
        #                 ('groups_id','in',self.env.ref("bi_crm_lead.group_md").id),
        #                 ('groups_id','in',self.env.ref("bi_crm_lead.group_sale_manager").id),
        #                 ])
        # partner_obj = mail_to.mapped("partner_id").ids
        # partner_obj.append(self.user_id.mapped("partner_id").id)
        # if self.designer_ids:
        #     for design in self.designer_ids.mapped("partner_id").ids:
        #         partner_obj.append(design)
        # main_content = {
        #     'subject':_('Assigned designers by , %s') % (design_lead),
        #     'author_id':self.env.user.partner_id.id,
        #     'body_html':mail_content,
        #     'recipient_ids':[(6,0,partner_obj)],
        # }
        # self.env['mail.mail'].sudo().create(main_content).send()
        # self.is_designers = True

    def submit_to_client(self):
        # if not self.design_attachment_ids:
        #     raise UserError(_("Please upload Design Documents"))
       
        stage = self.env["crm.stage"].search(
                [("name", "=", "Submit to Client")]
            )
        
        notification_to = self.env['res.users'].search([('groups_id','in',self.env.ref("bi_crm_lead.group_designing_lead").id)])
        for each in notification_to:
            model = self.env["ir.model"].search([("model", "=", "crm.lead")])
            data = {
                    "res_id": self.id,
                    "res_model_id":model.id,
                    "user_id": each.id,
                    "summary":"Design is submitted to the client",
                    "activity_type_id": self.env.ref("bi_crm_stage.send_revision_notification").id,
                }
            self.env["mail.activity"].sudo().create(data)
        self.stage_id = stage.id
        self.submit_date = fields.Date.context_today(self)
        # mail_content = str(self.name) +  " is moved from the stage " + self.stage_id.name + " to " + stage.name + " by " + self.user_id.name
        # salesperson_name = str(self.user_id.name)
        # partner = []
        # mail_to = self.env['res.users'].search(['|','|',
        #                 ('groups_id','in',self.env.ref("bi_crm_lead.group_md").id),
        #                 ('groups_id','in',self.env.ref("bi_crm_lead.group_sale_manager").id),
        #                 ("id","=",self.user_id.id)
        #                 ])
        # partners_obj = mail_to.mapped("partner_id")
        # main_content = {
        #     'subject':_('Stage moved by Salesperson, %s') % (salesperson_name),
        #     'author_id':self.env.user.partner_id.id,
        #     'body_html':mail_content,
        #     'recipient_ids':[(6,0,partners_obj.ids)],
        # }
        # mail_id = self.env['mail.mail'].sudo().create(main_content)
        # mail_id.write({"unrestricted_attachment_ids":[(6, 0, self.design_attachment_ids.ids)]})
        # mail_id.send()
        

    def submit_for_approval(self):
        self.is_submit_approval = True
        if not self.estimater_ids:
            raise UserError(_("Please select Estimators"))
        # if not self.estimation_attachment_ids:
        #     raise UserError(_("Please upload Estimation Documents"))
        stage = self.env["crm.stage"].search(
                [("name", "=", "Submit for Approval")]
            )
        # mail_content = str(self.name) +  " is moved from the stage " + self.stage_id.name + " to " + stage.name + " by " + self.user_id.name
        # salesperson_name = str(self.user_id.name)
        # partner = []
        # mail_to = self.env['res.users'].search(['|','|',
        #                 ('groups_id','in',self.env.ref("bi_crm_lead.group_md").id),
        #                 ('groups_id','in',self.env.ref("bi_crm_lead.group_sale_manager").id),
        #                 ("id","=",self.user_id.id)
        #                 ])
        # partners_obj = mail_to.mapped("partner_id")
        # main_content = {
        #     'subject':_('Stage moved by Salesperson, %s') % (salesperson_name),
        #     'author_id':self.env.user.partner_id.id,
        #     'body_html':mail_content,
        #     'recipient_ids':[(6,0,partners_obj.ids)],
        # }
        # mail_id = self.env['mail.mail'].sudo().create(main_content)
        # mail_id.write({"unrestricted_attachment_ids":[(6, 0, self.design_attachment_ids.ids)]})
        # mail_id.send()
        self.stage_id = stage.id
        self.approval_date = fields.Date.context_today(self)

    def button_revision(self):
        for line in self.revision_history_ids:
            line.document_date = self.document_upload_date
            line.client_submit_date = self.submit_date
        return {
            'name': _('Reason for Revision'),
            "type": "ir.actions.act_window",
            "view_mode": "form",
            "res_model": "crm.revision.wiz",
            "target": "new",
            "context": {
                "default_crm_id": self.id,
            },
        }
    
    def button_revision_esti(self):
        for line in self.estimation_history_ids:
            line.document_date = self.document_upload_date
            line.approval_submit_date = self.approval_date
        return {
            'name': _('Reason for Revision'),
            "type": "ir.actions.act_window",
            "view_mode": "form",
            "res_model": "crm.estimation.wiz",
            "target": "new",
            "context": {
                "default_crm_id": self.id,
            },
        }

    def action_estimation(self):
        # if not self.estimater_ids:
        #     raise UserError(_("Please select Estimators"))
        stage = self.env["crm.stage"].search(
                [("name", "=", "Estimation")]
            )
        # if self.user_id:
        #     notification_to = self.env['res.users'].search(['|',('groups_id','in',self.env.ref("bi_crm_lead.group_md").id),('groups_id','in',self.env.ref("bi_crm_lead.group_sale_manager").id)])
        #     for each in notification_to:
        #         model = self.env["ir.model"].search([("model", "=", "crm.lead")])
        #         data = {
        #                 "res_id": self.id,
        #                 "res_model_id":model.id,
        #                 "user_id": each.id,
        #                 "summary":str(self.name) +  " is moved from the stage " + self.stage_id.name + " to " + stage.name + " by " + self.user_id.name,
        #                 "activity_type_id": self.env.ref("bi_crm_stage.send_revision_notification").id,
        #             }
        #         self.env["mail.activity"].sudo().create(data)
        self.stage_id = stage.id
        # mail_content = str(self.name) +  " is moved from the stage " + self.stage_id.name + " to " + stage.name + " by " + self.user_id.name
        # salesperson_name = str(self.user_id.name)
        # partner = []
        # mail_to = self.env['res.users'].search(['|','|',
        #                 ('groups_id','in',self.env.ref("bi_crm_lead.group_md").id),
        #                 ('groups_id','in',self.env.ref("bi_crm_lead.group_sale_manager").id),
        #                 ('id', '=', self.estimation_lead_id.id)
        #                 ])
        # partners_obj = mail_to.mapped("partner_id")
        # main_content = {
        #     'subject':_('Stage moved by Salesperson, %s') % (salesperson_name),
        #     'author_id':self.env.user.partner_id.id,
        #     'body_html':mail_content,
        #     'recipient_ids':[(6,0,partners_obj.ids)],
        # }
        # mail_id = self.env['mail.mail'].sudo().create(main_content)
        # mail_id.send()
        

    def action_secured(self):
        stage = self.env["crm.stage"].search(
                [("name", "=", "Job Card Issue")]
            )
        # if self.user_id:
        #     notification_to = self.env['res.users'].search(['|',('groups_id','in',self.env.ref("bi_crm_lead.group_md").id),('groups_id','in',self.env.ref("bi_crm_lead.group_sale_manager").id)])
        #     for each in notification_to:
        #         model = self.env["ir.model"].search([("model", "=", "crm.lead")])
        #         data = {
        #                 "res_id":self.id,
        #                 "res_model_id":model.id,
        #                 "user_id": each.id,
        #                 "summary":str(self.name) +  " is moved from the stage " + self.stage_id.name + " to " + stage.name + " by " + self.user_id.name,
        #                 "activity_type_id": self.env.ref("bi_crm_stage.send_revision_notification").id,
        #             }
        #         self.env["mail.activity"].sudo().create(data)
        # mail_content = str(self.name) +  " is moved from the stage " + self.stage_id.name + " to " + stage.name + " by " + self.user_id.name
        # salesperson_name = str(self.user_id.name)
        # mail_to = self.env['res.users'].search(['|','|','|',
        #                 ('groups_id','in',self.env.ref("bi_crm_lead.group_md").id),
        #                 ('groups_id','in',self.env.ref("bi_crm_lead.group_sale_manager").id),
        #                 ('id', '=', self.accountant_lead_id.id),
        #                 ('id', '=', self.estimation_lead_id.id)
        #                 ])
        # partners_obj = mail_to.mapped("partner_id")
        # main_content = {
        #     'subject':_('Stage moved by Salesperson, %s') % (salesperson_name),
        #     'author_id':self.env.user.partner_id.id,
        #     'body_html':mail_content,
        #     'recipient_ids':[(6,0,partners_obj.ids)],
        # }
        # mail_id = self.env['mail.mail'].sudo().create(main_content)
        # mail_id.write({"unrestricted_attachment_ids":[(6, 0, self.estimation_attachment_ids.ids)]})
        # mail_id.send()
        if self.accountant_lead_id:
            accountant = self.accountant_lead_id
            model = self.env["ir.model"].search([("model", "=", "crm.lead")])
            data = {
                    "res_id":self.id,
                    "res_model_id":model.id,
                    "user_id": accountant.id,
                    "summary":"Job card issued for opportunity by " + str(self.user_id),
                    "activity_type_id": self.env.ref("bi_crm_stage.send_revision_notification").id,
                }
            self.env["mail.activity"].sudo().create(data)
        
        self.stage_id = stage.id
        

    def write(self, vals):
        res = super(CrmLead, self).write(vals)
        # if self.attachment_ids:
        #     for attmnt in self.attachment_ids:
        #         self.attachment_ids.res_id = attmnt.id
        # partner_obj = []
        # if not self.is_design_lead:
        #     if self.designing_lead_id:
        #         mail_content = str(self.user_id.name) +  " assigned design lead for " + self.name
        #         mail_to = self.env['res.users'].search([
        #                         ('groups_id','in',self.env.ref("bi_crm_lead.group_md").id),
        #                         ])
        #         partner_obj = mail_to.mapped("partner_id").ids
        #         partner_obj.append(self.user_id.partner_id.id)
        #         if self.designing_lead_id:
        #             for design in self.designing_lead_id.mapped("partner_id").ids:
        #                 partner_obj.append(design)
        #         main_content = {
        #             'subject':_('Assigned Design Lead by , %s') % (self.designing_lead_id.id),
        #             'author_id':self.env.user.partner_id.id,
        #             'body_html':mail_content,
        #             'recipient_ids':[(6,0,partner_obj)],
        #         }
        #         self.env['mail.mail'].sudo().create(main_content).send()
        #         self.is_design_lead = True
        # if not self.is_esti_lead:
        #     if self.estimation_lead_id:
        #         mail_content = str(self.user_id.name) +  " assigned estimation lead for " + self.name
        #         mail_to = self.env['res.users'].search([
        #                         ('groups_id','in',self.env.ref("bi_crm_lead.group_md").id),
        #                         ])
        #         partner_obj = mail_to.mapped("partner_id").ids
        #         partner_obj.append(self.user_id.partner_id.id)
        #         if self.estimation_lead_id:
        #             for estimation in self.estimation_lead_id.mapped("partner_id").ids:
        #                 partner_obj.append(estimation)
        #         main_content = {
        #             'subject':_('Assigned Estimation Lead by , %s') % (self.designing_lead_id.id),
        #             'author_id':self.env.user.partner_id.id,
        #             'body_html':mail_content,
        #             'recipient_ids':[(6,0,partner_obj)],
        #         }
        #         self.env['mail.mail'].sudo().create(main_content).send()
        #         self.is_esti_lead = True
        # if self.is_furniture == True:
        #     if 'furniture_lead_id' in vals.keys():
        #         mail_content =  str(self.name) +  " has been assigned  for furniture layout " 
        #         mail_to = self.env['res.users'].search([('id','=',self.furniture_lead_id.id)]).mapped("partner_id")
        #         main_content = {
        #                 'subject':_('Opportunity Assigned For Furniture Layout , %s') % (self.furniture_lead_id.name),
        #                 'author_id':self.env.user.partner_id.id,
        #                 'body_html':mail_content,
        #                 'recipient_ids':[(6,0,mail_to.ids)],
        #             }
        #         self.env['mail.mail'].sudo().create(main_content).send()
        if self.is_estimation == True:
            if 'estimation_lead_id' in vals.keys():
                    estimation_lead = vals['estimation_lead_id']
                    model = self.env["ir.model"].search([("model", "=", "crm.lead")])
                    data = {
                            "res_id": self.id,
                            "res_model_id":model.id,
                            "user_id": estimation_lead,
                            "summary":"Opportunity : " + str(self.name) + " has been assigned",
                            "activity_type_id": self.env.ref("bi_crm_stage.send_revision_notification").id,
                            }
                    self.env["mail.activity"].sudo().create(data)
        if self.is_estimation == True:
            if 'estimater_ids' in vals.keys():
                estimaters = vals['estimater_ids']
                for each in estimaters:
                    model = self.env["ir.model"].search([("model", "=", "crm.lead")])
                    data = {
                            "res_id": self.id,
                            "res_model_id":model.id,
                            "user_id": each[0],
                            "summary":"Opportunity : " + str(self.name) + "has been assigned by " + str(self.estimation_lead_id),
                            "activity_type_id": self.env.ref("bi_crm_stage.send_revision_notification").id,
                            }
                    self.env["mail.activity"].sudo().create(data)
            
                    
                # mail_content =  str(self.name) +  " has been assigned  for estimation layout " 
                # mail_to = self.env['res.users'].search([('id','=',self.estimation_lead_id.id)]).mapped("partner_id")
                # main_content = {
                #         'subject':_('Opportunity Assigned For Estimation Layout , %s') % (self.estimation_lead_id.name),
                #         'author_id':self.env.user.partner_id.id,
                #         'body_html':mail_content,
                #         'recipient_ids':[(6,0,mail_to.ids)],
                #     }
                # self.env['mail.mail'].sudo().create(main_content).send()   
        if 'user_id' in vals.keys():
            record = self.env['crm.lead'].browse(self.id)
            reassign = vals['user_id'] 
            model = self.env["ir.model"].search([("model", "=", "crm.lead")])
            data ={
                    "res_id":record.id,
                    "res_model_id":model.id,
                    "user_id": reassign,
                    "summary":"lead has been assigned by " + str(self.re_assign_to_id.display_name),
                    "activity_type_id": self.env.ref("bi_crm_stage.send_revision_notification").id,
                 }
            self.env["mail.activity"].sudo().create(data)
        if 'designing_lead_id' in vals.keys():
            record = self.env['crm.lead'].browse(self.id)
            desgn_lead = vals['designing_lead_id']
            model = self.env["ir.model"].search([("model", "=", "crm.lead")])
            data = {
                'res_id':record.id,
                'res_model_id':model.id,
                'user_id':desgn_lead,
                'summary':"Opportunity : " + str(self.name) + " is assigned for you",
                'activity_type_id':self.env.ref("bi_crm_stage.send_revision_notification").id,
            }
            self.env["mail.activity"].sudo().create(data)
        if 'estimation_lead_id' in vals.keys():
                estimation_lead = vals['estimation_lead_id']
                model = self.env["ir.model"].search([("model", "=", "crm.lead")])
                data = {
                        "res_id": self.id,
                        "res_model_id":model.id,
                        "user_id": estimation_lead,
                        "summary":str(self.name) +  " has been assigned  for estimation layout ",
                        "activity_type_id": self.env.ref("bi_crm_stage.send_revision_notification").id,
                       }
                self.env["mail.activity"].sudo().create(data)
                
        if 'furniture_lead_id' in vals.keys():
            furniture_lead = vals['furniture_lead_id']
            model = self.env["ir.model"].search([("model", "=", "crm.lead")])
            data = {
                    "res_id":self.id,
                    "res_model_id":model.id,
                    "user_id": furniture_lead,
                    "summary":"Opportunity : " + str(self.name) + " is assigned for you",
                    "activity_type_id": self.env.ref("bi_crm_stage.send_furniture_lead_notification_activity").id,
                }
            self.env["mail.activity"].sudo().create(data)

        return res

    def action_assign_estimaters(self):
        for estimator in self.estimater_ids:
            if estimator not in self.estimator_deadline_ids.mapped('estimator_id'):
                raise UserError(_("Please load the estimator in the 'Estimator Deadline' lines..."))
        if not self.estimater_ids:
            raise UserError(_("Please select Estimators"))
        if self.estimator_deadline_ids:
            for rec in self.estimator_deadline_ids:
                model = self.env["ir.model"].search([("model", "=", "crm.lead")])
                if rec.is_notification == False:
                    assignment_data = {
                        "res_id": self.id,
                        "res_model_id":model.id,
                        "user_id": rec.estimator_id.id,
                        "summary": f"{rec.estimator_id.name} has been assigned to estimate the project '{self.name}'.",
                        "activity_type_id": self.env.ref("bi_crm_stage.send_estimater_assign_notification_activity").id,
                    }
                    self.env["mail.activity"].sudo().create(assignment_data)
                    rec.is_notification = True
                if rec.is_deadline == False and rec.dead_line_date:
                    deadline_data = {
                        "res_id": self.id,
                        "res_model_id":model.id,
                        "user_id": rec.estimator_id.id,
                        "summary": "Your Dead Line Is" + str(" ")+ rec.dead_line_date.strftime('%d-%m-%Y'),
                        "activity_type_id": self.env.ref("bi_crm_stage.send_revision_notification").id,
                    }
                    self.env["mail.activity"].sudo().create(deadline_data)
                    rec.is_deadline = True
        # mail_content = str(self.user_id.name) +  " assigned Estimaters for " + self.name
        # estimation_lead = str(self.estimation_lead_id.name)
        # mail_to = self.env['res.users'].search(['|',
        #                 ('groups_id','in',self.env.ref("bi_crm_lead.group_md").id),
        #                 ('groups_id','in',self.env.ref("bi_crm_lead.group_sale_manager").id),
        #                 ])
        # partner_obj = mail_to.mapped("partner_id").ids
        # if self.estimater_ids:
        #     for esti in self.estimater_ids.mapped("partner_id").ids:
        #         partner_obj.append(esti)
        # main_content = {
        #     'subject':_('Assigned Estimaters by , %s') % (estimation_lead),
        #     'author_id':self.env.user.partner_id.id,
        #     'body_html':mail_content,
        #     'recipient_ids':[(6,0,partner_obj)],
        # }
        # self.env['mail.mail'].sudo().create(main_content).send()
        self.is_estimaters = True

    def button_hold(self):
        self.previous_stage_id = self.stage_id.id
        stage = self.env["crm.stage"].search(
                [("name", "=", "Hold")]
            )
        self.write({"stage_id":stage.id})

    def button_release(self):
        self.write({"stage_id":self.previous_stage_id.id})

    def _compute_stage_submit_to_client(self):
        for order in self:
            order.is_submit = False
            order.is_job_card=False
            order.is_submit_approval_estimation=False
            order.is_estimate=False
            order.is_hold=False
            order.is_decision_making=False
            
            if order.user_id.id == self.env.user.id:
                if order.stage_id.name == "Submit to Client":
                    order.is_submit = True
                else:
                    order.is_submit = False
                if order.stage_id.name == "Submit for Approval":
                    order.is_submit_approval_estimation = True
                else:
                    order.is_submit_approval_estimation = False
                if order.stage_id.name == "Job Card Issue":
                    order.is_job_card = True
                else:
                    order.is_job_card = False
                if order.stage_id.name == "Estimation":
                    order.is_estimate = True
                else:
                    order.is_estimate = False 
                if order.stage_id.name == "Hold":
                    order.is_hold = True
                else:
                    order.is_hold = False
            if order.accountant_lead_id.id == self.env.user.id or order.operations_manager_id.id == self.env.user.id or order.project_manager_id.id == self.env.user.id:
                if order.stage_id.name == "Job Card Issue":
                    order.is_job_card = True
                else:
                    order.is_job_card = False
            if order.stage_id.name == "Meetings Scheduled":
                order.is_decision_making = True
            else:
                order.is_decision_making = False
                
    def action_job_card_report(self):
        if not self.job_card_number:
            raise UserError(_("Please Provide Job Card Number"))
        if not self.operations_manager_id:
            raise UserError(_("Please Select Operations Lead"))
        # if not self.project_manager_id:
        if not self.project_lead:
            raise UserError(_("Please Select Project Lead"))
        # mail_content = str(self.accountant_lead_id.name) +  " issued job card and assigned operational lead and project manager for " + self.name
        # account_lead = str(self.accountant_lead_id.name)
        # mail_to = self.env['res.users'].search(['|','|','|','|','|',
        #                 ('groups_id','in',self.env.ref("bi_crm_lead.group_md").id),
        #                 ('groups_id','in',self.env.ref("bi_crm_lead.group_sale_manager").id),
        #                 ('groups_id','in',self.env.ref("bi_crm_lead.group_operations_crm_security").id),
        #                 ('groups_id','in',self.env.ref("bi_crm_lead.group_project_crm_security").id),
        #                 ('groups_id','in',self.env.ref("bi_crm_lead.group_designing_lead").id),
        #                 ("id","=",self.user_id.id)
        #                 ])
        # partner_obj = mail_to.mapped("partner_id").ids
        # main_content = {
        #     'subject':_('Job Card Issued and Assigned Operations Lead and Project Lead by , %s') % (account_lead),
        #     'author_id':self.env.user.partner_id.id,
        #     'body_html':mail_content,
        #     'recipient_ids':[(6,0,partner_obj)],
        # }
        # mail_id = self.env['mail.mail'].sudo().create(main_content)
        # invoice_report_id = self.env.ref('bi_job_card_report.job_card_pdf')
        # generated_report = invoice_report_id._render_qweb_pdf(report_ref='bi_job_card_report.job_card_pdf',res_ids=self.id)
        # data_record = base64.b64encode(generated_report[0])
        # ir_values = {
        # 'name': 'Invoice Report',
        # 'type': 'binary',
        # 'datas': data_record,
        # 'store_fname': data_record,
        # 'mimetype': 'application/pdf',
        # 'res_model': 'account.move',
        # }
        # report_attachment = self.env['ir.attachment'].sudo().create(ir_values)
        # mail_id.write({"unrestricted_attachment_ids":[(4, report_attachment.id)]})
        # mail_id.send()
        managers_ids = []
        if self.operations_manager_id:
            if self.project_manager_id:
                managers_ids.append(self.operations_manager_id)
                managers_ids.append(self.project_manager_id)
                for each in managers_ids:
                    model = self.env["ir.model"].search([("model", "=", "crm.lead")])
                    data = {
                            "res_id": self.id,
                            "res_model_id":model.id,
                            "user_id": each.id,
                            "summary":"Job card report created for " + str(self.name)+ " by " + str(self.accountant_lead_id.name),
                            "activity_type_id": self.env.ref("bi_crm_stage.send_revision_notification").id,
                           }
                    self.env["mail.activity"].sudo().create(data)
        return self.env.ref('bi_job_card_report.job_card_pdf').report_action(self)

    # ar added on 24042023
    all_attachment_ids = fields.Many2many("ir.attachment", compute="get_all_attachments")

    @api.depends("attachment_ids", "design_attachment_ids", "estimation_attachment_ids")
    def get_all_attachments(self):
        print("get_all_attachments", self)
        for rec in self:
            ir_attachments = self.env["ir.attachment"]
            if rec.attachment_ids:
                ir_attachments += rec.attachment_ids
            if rec.design_attachment_ids:
                ir_attachments += rec.design_attachment_ids
            if rec.estimation_attachment_ids:
                ir_attachments += rec.estimation_attachment_ids

            rec.all_attachment_ids = ir_attachments.ids

    def action_view_all_attachments(self):
        domain = [("id", "in", self.all_attachment_ids.ids)]
        action = self.env["ir.actions.actions"]._for_xml_id("bi_crm_stage.action_view_all_attachments")
        return dict(action, domain=domain)
    ###
    
    # def action_send_dead_line_designers(self):
    #     if self.dead_line_date:
    #         designers = self.designer_ids
    #         for each in designers:
    #             model = self.env["ir.model"].search([("model", "=", "crm.lead")])
    #             data = {
    #                     "res_id": self.id,
    #                     "res_model_id":model.id,
    #                     "user_id": each.id,
    #                     "summary":" Your Dead Line Is" + str(" ")+ str(self.dead_line_date),
    #                     "activity_type_id": self.env.ref("bi_crm_stage.send_dead_line_notification_activity").id,
    #                    }
    #             self.env["mail.activity"].sudo().create(data)
                
    def action_dead_line_notify(self):
        current_date = fields.Date.today()
        records = self.env['crm.lead'].search([('dead_line_date','=',current_date)])
        for record in records:
            if current_date == record.dead_line_date:
                designers = record.designer_ids
                for each in designers:
                    model = self.env["ir.model"].search([("model", "=", "crm.lead")])
                    data = {
                            "res_id": record.id,
                            "res_model_id":model.id,
                            "user_id": each.id,
                            "summary":" Your dead line for the opportunity is" + str(" ") + str(" ")+ str(self.dead_line_date),
                            "activity_type_id": self.env.ref("bi_crm_stage.send_dead_line_notification_remainder").id,
                        }
                    self.env["mail.activity"].sudo().create(data)
    
    
    def action_project_completed(self):
        stage = self.env["crm.stage"].search([("name", "=", "Project Completed")])
        self.write({"stage_id":stage.id})
    
            
            
            
            
                
        