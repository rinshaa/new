from odoo import models,fields,api,_

class Lead2OpportunityPartner(models.TransientModel):
    _inherit = 'crm.lead2opportunity.partner'

    user_id = fields.Many2one(
        'res.users', 'Account Manager')

    @api.model
    def default_get(self, fields):
        res = super(Lead2OpportunityPartner, self).default_get(fields)
        if "lead_id" in res:
            crm_id = self.env["crm.lead"].search([("id","=",res["lead_id"])])
            if crm_id.user_id:
                res["user_id"] = crm_id.user_id.id
        return res
    

    def _action_merge(self):
        to_merge = self.duplicated_lead_ids
        result_opportunity = to_merge.merge_opportunity(auto_unlink=False)
        result_opportunity.action_unarchive()

        if result_opportunity.type == "lead":
            self._convert_and_allocate(result_opportunity, [self.user_id.id], team_id=self.team_id.id)
        else:
            if not result_opportunity.user_id or self.force_assignment:
                result_opportunity.write({
                    'user_id': self.user_id.id,
                    'team_id': self.team_id.id,
                })
        # (to_merge - result_opportunity).sudo().unlink()
        self.with_context(active_ids=(to_merge - result_opportunity).ids)._action_convert()
        return result_opportunity