{
    "name": "CRM INHERIT",
    "summary": """
                CRM Lead Customisation""",
    "description": """
                The purpose of this module is to customise CRM module.""",
    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "support": "sales@bassaminfotech.com",
    "license": "OPL-1",
    "category": "CRM",
    "version": "15.0.0.1",
    "depends": [
        "crm","utm","base",
    ],
    "data": [
        # "security/security.xml",
        # "security/crm_security_group.xml",
        # "views/utm_source.xml",
        # "views/crm_lead.xml"
    ],
}