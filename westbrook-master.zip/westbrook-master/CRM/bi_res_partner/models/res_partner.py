from odoo import models, fields,api

class Partner(models.Model):
    _inherit = 'res.partner'

    target = fields.Float(String="Target")
    @api.model
    def search_read(self, domain=None, fields=None, offset=0, limit=None, order=None):
        if domain is None:
            domain = []
        current_user = self.env.user
        salesperson_group = self.env.ref('bi_crm_lead.group_sales_person_crm_security')
        if salesperson_group in current_user.groups_id:
            if current_user and current_user.id:
                domain += [('user_id', '=', current_user.id), ('user_id', '!=', False)]

        return super(Partner, self).search_read(domain, fields, offset, limit, order)





