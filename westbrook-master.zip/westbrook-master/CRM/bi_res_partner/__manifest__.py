{
    "name": "res Partner",
    "summary": """
       """,
    "description": """
         This module is used for the customisation related to crm stages in CRM.
             """,
    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "license": "OPL-1",
    "version": "16.0.0.2",
    "depends": ['base','crm','bi_crm_lead'],
    "data": [
            'views/res_partner.xml',
    ],
}