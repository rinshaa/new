# -*- coding: utf-8 -*-
{
    "name": "bi_lost_vs_closed_report",

    "description": """
        Lost Vs Closed Report
    """,

    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "support": "sales@bassaminfotech.com",
    "license": "OPL-1",
    "category": "Uncategorized",
    "version": "16.0.0.1",
    "depends": ["crm","report_xlsx"],
    "data": [
        "security/ir.model.access.csv",
        "report/report.xml",
        "wizard/lost_vs_closed_wizard.xml",
    ],
}