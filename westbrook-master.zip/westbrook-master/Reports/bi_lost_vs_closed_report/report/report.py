import base64
import io
from odoo import models
from PIL import Image

class PartnerXlsx(models.AbstractModel):
    _name = 'report.bi_lost_vs_closed_report.lost_vs_closed_xls'
    _inherit = 'report.report_xlsx.abstract'
    
    def get_resized_image_data(self, byte_stream, bound_width_height):
        # get the byte stream of image and resize it
        im = Image.open(byte_stream)
        im.thumbnail(bound_width_height, Image.ANTIALIAS) # ANTIALIAS is important if shrinking
        # stuff the image data into a bytestream that excel can read
        im_bytes = io.BytesIO()
        im.save(im_bytes, format="PNG")
        return im_bytes
    

    def generate_xlsx_report(self, workbook, data, partners):
        date_from = data['date_from']
        to_date = data['date_to']
        sheet = workbook.add_worksheet('Lost Vs Closed')
        sheet.set_column('B:B',15)
        sheet.set_column('C:C',15)
        sheet.set_column('D:D',25)        
        sheet.set_row(0,35)
        sheet.set_row(3,25)
        bound_width_height = (150,200)
         
        company_id = self.env["res.company"].search([('id', '=', self.env.company.id )])
        if company_id.logo:
            image_byte_stream = io.BytesIO(base64.b64decode(company_id.logo))
            image_data = self.get_resized_image_data(image_byte_stream, bound_width_height)
            sheet.insert_image(
            "A1:B2", "Company Logo", {"image_data": image_data, "x_offset": 15, "y_offset": 15},
            )
        
        merge_format=workbook.add_format({"bold":True,"color":"black","valign":"center"})
        sheet.merge_range("A1:B2",'',merge_format)
        sheet.merge_range("C1:D2",f"Lost Vs Closed",merge_format)
        sheet.merge_range("A3:D3",'',merge_format)
        heading_format = workbook.add_format({'bold': True, 'color': 'black','align':'center','bg_color':'#f2d7d5','border':1})
        row = 3
        sheet.write(row,0,'Sl.No',heading_format)
        sheet.write(row,1,'Salesperson',heading_format)
        sheet.write(row,2,'Lost Value',heading_format)
        sheet.write(row,3,'Closed Value',heading_format)
        
        domain = []
        if date_from:
            domain += [('create_date','>=',date_from)]
        if to_date:
            domain += [('create_date','<=',to_date)]
            
        leads = self.env['crm.lead'].search([('type', '=', 'opportunity')])
        salespersons = leads.mapped('user_id')
        col = 0
        sl_no = 0
        for salesperson in salespersons:
            row += 1
            sl_no += 1
            sheet.write(row,col,sl_no)
            sheet.write(row,col+1,salesperson.name)
            sum_lost = 0
            sum_closed = 0
            for lead in leads:
                if lead.user_id.id == salesperson.id:
                    if lead.stage_id.name == 'Lost':
                        sum_lost += lead.expected_revenue
                    if lead.stage_id.name == 'Job Card Issue':
                        sum_closed += lead.expected_revenue
            sheet.write(row,col+2,sum_lost)   
            sheet.write(row,col+3,sum_closed)        
                        
        
        
        
        
        
        
        