from odoo import fields,models


class LostVsClosedWizard(models.TransientModel):
    _name = "lost.vs.closed.wizard"
    _description = "Lost Vs Closed Wizard"
    
    date_from = fields.Date(string="Date From")
    date_to = fields.Date(string="Date To")
    
    def action_export(self):
        data = {
            'date_from':self.date_from,
            'date_to':self.date_to,
        }
        return self.env.ref('bi_lost_vs_closed_report.lost_vs_closed_report_xlsx').report_action(self,data=data)