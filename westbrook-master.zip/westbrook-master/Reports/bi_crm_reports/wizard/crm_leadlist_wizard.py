from odoo import fields,models,api

class LeadlistSaleReportWizard(models.TransientModel):
    _name = "leadlist.sale.report.wizard"
    _description = "Leadlist sales report wizard"

    date_from = fields.Date(string="From",required=True)
    date_to = fields.Date(string="To",required=True)
    salesperson_id = fields.Many2one('res.users',string="Salesperson")
    source_type_ids = fields.Many2many('utm.source',sring="Source Type")

    @api.onchange('source_type_ids')
    def _onchange_source_type_ids(self):
        records = self.env['crm.lead'].search([('source_id','in',self.source_type_ids.ids),
                                               ('create_date','>=',self.date_from),('create_date','<=',self.date_to)
                                             ])
        # for order in self:
        #     if order.source_type_ids:
        #         user_ids = self.source_type_ids.mapped("assign_user_id")
                # if self.source_type_ids.name == 'Salesman':
        if records:
            return{'domain':{'salesperson_id':[('id','in',records.mapped("user_id").ids)]}}
                # else:
                #     return{'domain':{'salesperson_id':[('id','in',records.user_id.ids)]}}
        
    def print_excel(self):
        data = {
            "ids": self.ids,
            "model": self._name,
            "form": {
                "date_from": self.date_from,
                "date_to": self.date_to,
                "salesperson_id":self.salesperson_id.id,
                "source_type_ids": self.source_type_ids.ids,
            },
        }

        return self.env.ref("bi_crm_reports.action_report_leadlist_sale").report_action(
            self, data=data, config=False
        )
