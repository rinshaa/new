from odoo import models, _
from odoo.exceptions import UserError
from datetime import datetime, date
import io
import base64
from PIL import Image

class LeadlistSaleXlsx(models.AbstractModel):
    _name = 'report.bi_crm_reports.report_xlsx_leadlist_sale'
    _inherit = 'report.report_xlsx.abstract'
    
    def get_resized_image_data(self, byte_stream, bound_width_height):
        # get the byte stream of image and resize it
        im = Image.open(byte_stream)
        im.thumbnail(bound_width_height, Image.ANTIALIAS) # ANTIALIAS is important if shrinking
        # stuff the image data into a bytestream that excel can read
        im_bytes = io.BytesIO()
        im.save(im_bytes, format="PNG")
        return im_bytes

   
    def generate_xlsx_report(self, workbook, data, sale):
        
        sheet = workbook.add_worksheet('Leadlist Sale')
        date_from = data['form']['date_from']
        date_to = data['form']['date_to']
        salesperson_id = data['form']['salesperson_id']
        source_type_ids = data['form']['source_type_ids']

        merge_format_1 = workbook.add_format({
                                        'bold': 1,
                                        'align': 'center',
                                        'font_size':20,
                                        })
        
        format_1 = workbook.add_format({
                                    'align': 'center',
                                    'bold':1,
                                    'bg_color':'#f2d7d5',
                                    'border':1,
                                    'text_wrap':'true'
                                    })
        format_2 = workbook.add_format({
                                    'align': 'right',
                                    'bold':1,
                                    })
        format_3 = workbook.add_format({
                                    'valign':'right'
        })

        sheet.set_column('A:A',5)
        sheet.set_column('B:B',13)
        sheet.set_column('C:C',25)
        sheet.set_column('D:D',21)
        sheet.set_column('E:E',18)
        sheet.set_column('F:F',22)
        sheet.set_column('G:G',9)
        sheet.set_column('H:H',10)
        sheet.set_column('I:I',14)
        sheet.set_column('J:J',22)
        sheet.set_column('K:K',23)
        sheet.set_column('L:L',25)       
        sheet.set_column('M:M',14)
        sheet.set_row(0,35)
        sheet.set_row(4,41)
        bound_width_height = (150, 200)
        
        
        company_id = self.env["res.company"].search([('id', '=', self.env.company.id )])
        # crm_id = self.env["crm.lead"].search([])
        # for each in crm_id:
        #     created_date = each.create_date.date()
    
        if company_id.logo:
            image_byte_stream = io.BytesIO(base64.b64decode(company_id.logo))
            image_data = self.get_resized_image_data(image_byte_stream, bound_width_height)
            sheet.insert_image(
            "A1:C3", "Company Logo", {"image_data": image_data, "x_offset": 15, "y_offset": 20},
            )

        sheet.merge_range('A1:C3',"",merge_format_1 )
        sheet.merge_range('D1:J3','Lead List Report',merge_format_1 )
        sheet.merge_range('A4:L4','', )

        head_row = 1
        sheet.write("K%s" %head_row,'Form#:',format_2)
        head_row+=1
        sheet.write("K%s" %head_row,'Rev:',format_2)
        head_row+=1
        sheet.write("K%s" %head_row,'Issued:',format_2)

        row=5
        sheet.write("A%s" %row,'S.NO.', format_1)
        sheet.write("B%s" %row,'Date', format_1)
        sheet.write("C%s" %row,'Project / Client Name', format_1)
        sheet.write("D%s" %row,'Salesperson',format_1)
        sheet.write("E%s" %row,'Contact Person', format_1)   
        sheet.write("F%s" %row,'Contact Number', format_1)
        sheet.write("G%s" %row,'Value', format_1)
        sheet.write("H%s" %row,'Probability', format_1)
        sheet.write("I%s" %row,'Current Stage', format_1)
        sheet.write("J%s" %row,'All Drawings (Yes or No)', format_1)
        sheet.write("K%s" %row,'Client Requirements (Yes or No)', format_1)
        sheet.write("L%s" %row,'Statutory and Regulatory Requirement (Yes or No)', format_1) 
        sheet.write("M%s" %row,'Remarks', format_1)
        row+=1
        date_from = datetime.strptime(date_from, '%Y-%m-%d')
        date_to = datetime.strptime(date_to, '%Y-%m-%d')
        
        domain = []
        if date_from:
            domain += [('create_date','>=',date_from)]
        if date_to:
            domain += [('create_date','<=',date_to)]
        if salesperson_id:
            domain += [('user_id','=',salesperson_id)]
        if source_type_ids:
            domain += [('source_id','=',source_type_ids)]
        records = self.env['crm.lead'].search(domain)
        s_no = 1
        
        for rec in records:
            strip_date = rec.create_date.strftime('%Y-%m-%d')
            sheet.write("A%s" %row,s_no)
            sheet.write("B%s" %row,strip_date if strip_date else "")
            sheet.write("C%s" %row,rec.name if rec.name else "")
            sheet.write("D%s" %row,rec.user_id.name if rec.user_id.name else "")
            sheet.write("E%s" %row,rec.contact_name if rec.contact_name else "")
            sheet.write("F%s" %row,rec.phone if rec.phone else "",format_3)
            sheet.write("G%s" %row,rec.expected_revenue if rec.expected_revenue else "",format_3)
            sheet.write("H%s" %row,rec.probability if rec.probability else "",format_3)
            sheet.write("I%s" %row,rec.stage_id.name if rec.stage_id.name else "")
            # sheet.write("J%s" %row, format_1)
            # sheet.write("K%s" %row, format_1) 
            # sheet.write("L%s" %row,rec.description if rec.description else "")
            s_no+=1
            row+=1
        