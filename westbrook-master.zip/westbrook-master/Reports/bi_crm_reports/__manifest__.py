# -*- coding: utf-8 -*-
{
    "name": "bi_crm_report",

    "description": """
        Excel report in CRM
    """,

    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "support": "sales@bassaminfotech.com",
    "license": "OPL-1",
    "category": "Uncategorized",
    "version": "0.1",
    "depends": ["base","crm","report_xlsx"],
    "data": [
        "security/ir.model.access.csv",
        "views/report_action.xml",
        "wizard/crm_leadlist_wizard.xml",
    ],
}