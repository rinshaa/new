# -*- coding: utf-8 -*-
{
    "name": "Estimator Report",

    "description": """
        Excel report in CRM
    """,

    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "support": "sales@bassaminfotech.com",
    "license": "OPL-1",
    "category": "Uncategorized",
    "version": "0.1",
    "depends": ["base","crm","report_xlsx","bi_crm_lead"],
    "data": [
        "security/ir.model.access.csv",
        "report/report.xml",
        "wizard/estimator_report_wizard.xml",
    ],
}