from odoo import models,fields


class EstimatorReportWizard(models.TransientModel):
    _name = "estimator.report.wizard"
    
    from_date = fields.Date('From')
    to_date = fields.Date('To')
    estimator_ids = fields.Many2many('res.users', domain=lambda self: [("groups_id", "=", self.env.ref("bi_crm_lead.group_estimator_crm_security").id)])
    
    def action_estimator_wizard(self):
        data={
            
            'ids':self.ids,
            'model':self._name,
            'form':{
                
                'from_date':self.from_date,
                'to_date':self.to_date,
                'estimator_ids':self.estimator_ids.ids,
            }
        }
        return self.env.ref('bi_estimator_report.action_estimator_report').report_action(self, data=data)
    