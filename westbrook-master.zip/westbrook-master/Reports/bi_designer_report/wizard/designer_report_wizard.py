from odoo import models,fields


class DesingerReportWizard(models.TransientModel):
    _name = "designer.report.wizard"
    
    from_date = fields.Date('From')
    to_date = fields.Date('To')
    designer_ids = fields.Many2many('res.users', domain=lambda self: [("groups_id", "=", self.env.ref("bi_crm_lead.group_designer_crm_security").id)])
    
    def action_design_wizard(self):
        data={
            
            'ids':self.ids,
            'model':self._name,
            'form':{
                
                'from_date':self.from_date,
                'to_date':self.to_date,
                'designer_ids':self.designer_ids.ids,
            }
        }
        return self.env.ref('bi_designer_report.action_designer_report').report_action(self, data=data)
    