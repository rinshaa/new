from odoo import models
import io
import base64
from PIL import Image


class DesignerReport(models.AbstractModel):
    _name="report.bi_designer_report.report_xlsx"
    _inherit = "report.report_xlsx.abstract"
    
    def get_resized_image_data(self, byte_stream, bound_width_height):
        # get the byte stream of image and resize it
        im = Image.open(byte_stream)
        im.thumbnail(bound_width_height, Image.ANTIALIAS) # ANTIALIAS is important if shrinking
        # stuff the image data into a bytestream that excel can read
        im_bytes = io.BytesIO()
        im.save(im_bytes, format="PNG")
        return im_bytes
 
    
    def generate_xlsx_report(self, workbook, data,lines):
        sheet = workbook.add_worksheet('Designer Report')
        start_date = data['form']['from_date']
        end_date = data['form']['to_date']
        designer_ids = data['form']['designer_ids']
        sheet.set_row(4,20)
        sheet.set_column("A:A",10)
        sheet.set_column("B:B",15)
        sheet.set_column("C:C",25)
        sheet.set_column("D:D",20)
        sheet.set_column("E:E",20)
        sheet.set_column("F:F",20)
        format1 = workbook.add_format({
                                    'align':'center',
                                    'font_size':25,
                                    'bold':1
                                     })
        format2 = workbook.add_format({
                                    'align':'center',
                                    'valign':'center',
                                    'font_size':12,
                                    'bold':1,
                                    'bg_color':'#fa9b9b',
                                     })
        format3 = workbook.add_format({
                                    'align':'center',
                                    'valign':'center',
                                    'font_size':12,
                                     })
        
        company_id = self.env["res.company"].search([('id', '=',  self.env.company.id)])
        bound_width_height = (220,320)
        if company_id.logo:
            image_byte_stream = io.BytesIO(base64.b64decode(company_id.logo))
            image_data = self.get_resized_image_data(image_byte_stream, bound_width_height)
            sheet.insert_image(
            "A1:C3", "Company Logo", {"image_data": image_data,},
            )
            
        sheet.merge_range("D1:E3",'Designer Report',format1)
        sheet.write('A5','Sl No.',format2)
        sheet.write('B5','Date',format2)
        sheet.write('C5','Project / Client Name',format2)
        sheet.write('D5','Designer',format2)
        sheet.write('E5','Status',format2)
        sheet.write('F5','Account Manager',format2)
        domain = []
        if start_date:
            domain += [('create_date','>=', start_date)]
        if end_date:
            domain += [('create_date','<=', end_date)]
        if designer_ids:
            domain += [('designer_ids','in',designer_ids)]
        records = self.env['crm.lead'].search(domain)
        sl = 1
        row = 6
        for record in records:
            date = record.create_date
            create_date = date.strftime('%y-%m-%d')
            if lines.designer_ids:
                for each in lines.designer_ids:
                    flag = 0
                    for x in record.designer_ids:
                        if each == x:
                            flag = 1 
                    if flag==1:
                        sheet.write("A%s" %row,sl,format3)
                        sl+=1
                        sheet.write("B%s" %row,create_date if create_date else "",format3)
                        sheet.write("F%s" %row,record.user_id.name if record.user_id.name else "",format3)
                        sheet.write("C%s" %row,record.name if record.name else "",format3)
                        sheet.write("D%s" %row,each.name,format3)
                        dead_line = record.designer_deadline_ids.filtered(lambda l:l.designer_id == each)
                        if dead_line:
                            sheet.write("E%s" %row,dead_line.status if dead_line.status else "",format3)
                        row+=1
            
            else:   
                for each in record.designer_ids:
                    sheet.write("A%s" %row,sl,format3)
                    sl+=1
                    sheet.write("B%s" %row,create_date if create_date else "",format3)
                    sheet.write("F%s" %row,record.user_id.name if record.user_id.name else "",format3)
                    sheet.write("C%s" %row,record.name if record.name else "",format3)
                    sheet.write("D%s" %row,each.name,format3)
                    dead_line = record.designer_deadline_ids.filtered(lambda l:l.designer_id == each)
                    if dead_line:
                        sheet.write("E%s" %row,dead_line.status if dead_line.status else "",format3)
                    row+=1
                
                    
           
            
        
      