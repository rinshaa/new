# -*- coding: utf-8 -*-
{
    "name": "Job Card Report",

    "description": """
       
    """,

    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "support": "sales@bassaminfotech.com",
    "license": "OPL-1",
    "version": "0.1",
    "depends": ["crm"],
    "data": [
   
        "report/paperformat.xml",
        "report/job_card_template.xml",
        "report/report.xml",
        
    ],
}