# -*- coding: utf-8 -*-
{
    "name": "bi_conversion_rate_of_report",

    "description": """
        Converstion Rate of Report
    """,

    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "support": "sales@bassaminfotech.com",
    "license": "OPL-1",
    "category": "Uncategorized",
    "version": "16.0.0.1",
    "depends": ["crm","report_xlsx"],
    "data": [
        "security/ir.model.access.csv",
        "report/report.xml",
        "wizard/conversion_rate_wizard.xml",
    ],
}