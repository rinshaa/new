from odoo import fields,models


class ConverstionRateWizard(models.TransientModel):
    _name = "converstion.rate.wizard"
    _description = "Converstion Rate Wizard"
    
    date_from = fields.Date(string="Date From")
    to_date = fields.Date(string="Date To")
    
    def action_export(self):
        data = {
            'date_from':self.date_from,
            'to_date':self.to_date
        }
        return self.env.ref('bi_conversion_rate_of_report.converstion_rate_of_report_xlsx').report_action(self,data=data)