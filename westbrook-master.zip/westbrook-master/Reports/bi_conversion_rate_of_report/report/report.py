import base64
import io
from odoo import models
from PIL import Image

class PartnerXlsx(models.AbstractModel):
    _name = 'report.bi_conversion_rate_of_report.converstion_rate_xls'
    _inherit = 'report.report_xlsx.abstract'
    
    def get_resized_image_data(self, byte_stream, bound_width_height):
        # get the byte stream of image and resize it
        im = Image.open(byte_stream)
        im.thumbnail(bound_width_height, Image.ANTIALIAS) # ANTIALIAS is important if shrinking
        # stuff the image data into a bytestream that excel can read
        im_bytes = io.BytesIO()
        im.save(im_bytes, format="PNG")
        return im_bytes
 

    def generate_xlsx_report(self, workbook, data, partners):
        date_from = data['date_from']
        to_date = data['to_date']
        sheet = workbook.add_worksheet('CRM')
        sheet.set_column('B:B',15)
        sheet.set_column('C:C',15)
        sheet.set_column('D:D',25)
        sheet.set_column('E:E',20)
        
        sheet.set_row(0,35)
        sheet.set_row(3,25)
        bound_width_height = (150,200)
         
        company_id = self.env["res.company"].search([('id', '=', self.env.company.id )])

        if company_id.logo:
            image_byte_stream = io.BytesIO(base64.b64decode(company_id.logo))
            image_data = self.get_resized_image_data(image_byte_stream, bound_width_height)
            sheet.insert_image(
            "A1:B2", "Company Logo", {"image_data": image_data, "x_offset": 15, "y_offset": 15},
            )

        
        merge_format=workbook.add_format({"bold":True,"color":"black","valign":"center"})
        sheet.merge_range("A1:B2",'',merge_format)
        sheet.merge_range("C1:E2",f"Conversion Report",merge_format)
        sheet.merge_range("A3:E3",'',merge_format)
        heading_format = workbook.add_format({'bold': True, 'color': 'black','align':'center','bg_color':'#f2d7d5','border':1})
        row = 3
        sheet.write(row,0,'Sl.No',heading_format)
        sheet.write(row,1,'Salesperson',heading_format)
        sheet.write(row,2,'Leads Assigned',heading_format)
        sheet.write(row,3,'Converted to Opportunity',heading_format)
        sheet.write(row,4,'Conversion Rate (%)',heading_format)
        
        domain = []
        if date_from:
            domain += [('create_date','>=',date_from)] 
        if to_date:
            domain += [('create_date','<=',to_date)]
        leads = self.env['crm.lead'].search(domain)
        person = leads.mapped('user_id').ids
        domain.append(('active','=',False))
        lost_leads = self.env['crm.lead'].search(domain)
        total_lead_record = leads+lost_leads
        lost_lead_user_ids = lost_leads.mapped("user_id").ids
        for user in lost_lead_user_ids:
            if user not in person:
                person.append(user)
        salesperson = self.env['res.users'].search([('id','in',person)])
        col = 0
        sl_no = 0
        for each in salesperson:
            row += 1
            sl_no += 1
            sheet.write(row,col+1,each.name)
            sheet.write(row,col,sl_no)
            total_lead_count = 0
            lost = 0
            convert_to_oppurtunity = 0
            convertion_rate_percentage = 0
            for lead_record in total_lead_record:
                if lead_record.user_id.id == each.id:
                    total_lead_count += 1
                    if lead_record.active == False:
                        lost += 1
            convert_to_oppurtunity = total_lead_count - lost
            convertion_rate_percentage = (convert_to_oppurtunity/total_lead_count)*100
            sheet.write(row,col+2,total_lead_count) 
            sheet.write(row,col+3,convert_to_oppurtunity)    
            sheet.write(row,col+4,round(convertion_rate_percentage,2))     
        
        
        
        
        
        