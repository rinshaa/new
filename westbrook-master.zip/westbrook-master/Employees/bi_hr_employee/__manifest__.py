{
    "name": "bi_hr_employees",
    "summary": """
       """,
    "description": """
        
             """,
    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "license": "OPL-1",
    "version": "16.0.0.1",
    "depends": ['hr','bi_crm_lead'],
    "data": [
        
            'security/ir.model.access.csv',
            'views/hr_employee.xml',
    ],
}