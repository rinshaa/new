from odoo import models, fields,api
from datetime import datetime,timedelta
import calendar


class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    hr_employee_line_ids = fields.One2many('hr.employee.line', 'connection_id')
    is_md_and_manager = fields.Boolean(compute="_compute_is_md_or_sales_manager",default=False)
    

    def _compute_is_md_or_sales_manager(self):   
        for order in self:
            order.is_md_and_manager == False
            md = self.env.user.has_group("bi_crm_lead.group_md")
            sales_manager = self.env.user.has_group("bi_crm_lead.group_sale_manager")
            if sales_manager or md:
                order.is_md_and_manager = True
       

class HrEmployeeLine(models.Model):
    _name = 'hr.employee.line'


    @api.model
    def year_selection(self):
        year = 2023
        year_list = []
        while year != 2050: 
            year_list.append((str(year), str(year)))
            year += 1
        return year_list

    year = fields.Selection(year_selection, string="Year", default=str(datetime.now().year))
    month = fields.Selection([('1', 'January'),
                              ('2', 'February'),
                              ('3', 'March'),
                              ('4', 'April'),
                              ('5', 'May'),
                              ('6', 'June'),
                              ('7', 'July'),
                              ('8', 'August'),
                              ('9', 'September'),
                              ('10', 'October'),
                              ('11', 'November'),
                              ('12', 'December'),], string='Month')
    target = fields.Float(string="Target")
    actual_revenue = fields.Float(string="Actual Revenue", compute="compute_actual_revenue")
    connection_id = fields.Many2one('hr.employee')

    def compute_actual_revenue(self):
        for record in self:
            actual_revenue = 0
            if record.year and record.month:
                start_date = datetime(int(record.year), int(record.month), 1)
                end_date = datetime(int(record.year), int(record.month) + 1, 1) + timedelta(days=-1)
                actual_revenue = sum(self.env['crm.lead'].search([('user_id', '=', record.connection_id.user_id.id), 
                                                                  ('create_date', '>=', start_date),
                                                                  ('create_date', '<=', end_date)]).mapped('expected_revenue'))
            record.actual_revenue = actual_revenue    
        