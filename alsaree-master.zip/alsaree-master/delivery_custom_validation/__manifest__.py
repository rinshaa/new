{
    "name": "Delivery Custom Validation",
    "summary": """
        Delivery Custom Validation""",
    "author": "Bassam Infotech LLP",
    "website": "https://www.bassaminfotech.com",
    "category": "",
    "license": "OPL-1",
    "version": "15.0.0.1",
    "depends": ["stock", "sale"],
    "data": [],
}

