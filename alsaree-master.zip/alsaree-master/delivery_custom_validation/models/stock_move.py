from odoo import api, fields, models
from odoo.exceptions import ValidationError


class StockMove(models.Model):
    _inherit = 'stock.move'

    @api.model
    def create(self, values):
        if 'product_id' in values and 'picking_id' in values:
            picking = self.env['stock.picking'].browse(values['picking_id'])
            if picking.sale_id:
                order_lines = picking.sale_id.order_line.filtered(
                    lambda line: line.product_id.id == values['product_id'])
                if not order_lines.exists():
                    raise ValidationError(
                        "You don't have permission to add this Item")
        return super(StockMove, self).create(values)

    @api.model
    def write(self, values):
        if 'product_id' in values or 'picking_id' in values:
            for move in self:
                picking = self.env['stock.picking'].browse(move.picking_id.id)
                if picking.sale_id:
                    order_lines = picking.sale_id.order_line.filtered(
                        lambda line: line.product_id.id == values.get('product_id', move.product_id.id))
                    if not order_lines.exists():
                        raise ValidationError(
                            "You don't have permission to add this Item")
        return super(StockMove, self).write(values)
