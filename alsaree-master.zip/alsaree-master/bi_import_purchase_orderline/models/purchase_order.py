from odoo import api, fields, models

class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    def action_open_purchase_order_import_wizard(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Purchase Order Import',
            'res_model': 'purchaseorder.import.wizard',  
            'view_mode': 'form',
            'view_id': self.env.ref('bi_import_purchase_orderline.import_purchaseorder_wizard_view').id,  # Replace with your actual view reference
            'target': 'new',
            'context': {'default_purchase_order_form': self.id},


        }

