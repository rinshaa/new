{
    "name": "Import Purchase Orderline",
    "summary": """Import Purchase Orderline""",
    "author": "Bassam Infotech LLP",
    "website": "https://www.bassaminfotech.com",
    "category": "Purchase",
    "license": "OPL-1",
    "version": "15.0.0.1",
    "depends": ["purchase"],
    "data": [
        'security/ir.model.access.csv',
        'wizards/purchase_import_wizard.xml',
        'views/purchase_order.xml',
        
    ],
}

