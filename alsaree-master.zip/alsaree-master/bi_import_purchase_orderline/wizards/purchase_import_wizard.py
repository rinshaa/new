from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
import xlrd
import base64
from io import BytesIO
from datetime import datetime

class PurchaseImportWizard(models.TransientModel):
    _name = 'purchaseorder.import.wizard'
    _description = 'Purchase Order Import Wizard'

    import_file = fields.Binary(string='Import File')
    purchase_order_form = fields.Many2one('purchase.order', string='Purchase Order')

    def _get_template(self):
        """Generates the template file for the import."""
        import xlwt

        workbook = xlwt.Workbook()
        sheet = workbook.add_sheet('purchase order Template')

        header_style = xlwt.easyxf('font: bold 1; align: horiz center')

        headers = ['Product', 'Description', 'Delivery Date', 'Quantity', 'UOM', 'Packaging Quantity','Packageing','Unit Price','Taxes']
        column_widths = [5000, 5000, 4000, 4000, 4000, 4000, 4000, 4000, 4000]
       
        for i, header in enumerate(headers):
            sheet.write(0, i, header, header_style)
            sheet.col(i).width = column_widths[i]  # Set column width

        template_stream = BytesIO()
        workbook.save(template_stream)
        template_stream.seek(0)
        return base64.b64encode(template_stream.read()).decode()

    template = fields.Binary(string='Template', default=_get_template, readonly=True)

    def download_template(self):
        """Triggers the download of the template file."""
        template_data = self._get_template()
        template_name = 'purchaseorder_template.xls'

        return {
            'type': 'ir.actions.act_url',
            'url': 'web/content/?model=purchaseorder.import.wizard&id=%s&field=template&download=true&filename=%s' % (
                self.id, template_name),
            'target': 'self',
        }

    def import_template(self):
        """Imports data from the provided Excel template and creates purchase order lines."""
        if not self.import_file:
            raise ValidationError(_('Please upload a file to import.'))

        try:
            file_content = base64.b64decode(self.import_file)
            workbook = xlrd.open_workbook(file_contents=file_content)
            sheet = workbook.sheet_by_index(0)
        except Exception:
            raise ValidationError(_('Invalid file format. Please upload a valid Excel file.'))

        expected_columns =9
  
        if sheet.ncols != expected_columns:
            raise ValidationError(_('Invalid file structure. The file must have exactly %d columns.' % expected_columns))

        purchase_order_model = self.env['purchase.order.line']

        for row in range(1, sheet.nrows):
            if not any(sheet.cell_value(row, col) for col in range(sheet.ncols)):
                continue

            try:
                product_name = sheet.cell_value(row, 0).strip()
                description = sheet.cell_value(row, 1).strip()
                delivery_date = sheet.cell_value(row, 2).strip()
                quantity = float(sheet.cell_value(row, 3)) if sheet.cell_value(row, 3) else 0.0
                uom = sheet.cell_value(row, 4).strip()
                packing_qty = float(sheet.cell_value(row, 5)) if sheet.cell_value(row, 5) else 0.0
                packaging = sheet.cell_value(row, 6).strip()
                unit_price = float(sheet.cell_value(row, 7)) if sheet.cell_value(row, 7) else 0.0
                tax = sheet.cell_value(row, 8).strip()
            except Exception:
                raise ValidationError(_('Invalid data in row %d. Please check the file.') % (row + 1))

            
            product = self.env['product.product'].search([('name', 'ilike', product_name)], limit=1)
            if not product:
                raise ValidationError(_('Product "%s" not found in the system.') % product_name)

            packagings = self.env['product.packaging'].search([('name','=',packaging)])
            
            try:
                delivery_date = datetime.strptime(delivery_date, '%d-%m-%Y').date() if delivery_date else False
            except Exception:
                raise ValidationError(_('Invalid delivery date format for row %d. Expected format: DD-MM-YYYY') % (row + 1))

            purchase_order_model.create({
                'order_id': self.purchase_order_form.id,
                'product_id': product.id,
                'name': description,
                'date_planned': delivery_date,
                'product_qty': quantity,
                'product_uom': self.env['uom.uom'].search([('name','=',uom)]).id,
                'product_packaging_qty':packing_qty,
                'product_packaging_id':packagings.id,
                'price_unit': unit_price,
                'taxes_id':self.env['account.tax'].search([('name','=',tax),('type_tax_use','=','purchase')]).ids,
            })

        return {
            'type': 'ir.actions.client',
            'tag': 'reload',
        }
