from odoo import api, fields, models, _


class MultistoreProductDetail(models.Model):
    _inherit = 'multistore.product.detail'

    qty_on_hand = fields.Float(string='Qty On Hand', compute='_compute_qty_onhand', store=True)
    location_id = fields.Many2one('stock.location')

    @api.depends('product_id.qty_available')
    def _compute_qty_onhand(self):
        for rec in self:
            product_id = rec.product_id
            location_id = self.env['stock.location'].search([('store_id', '=', rec.store_id)], limit=1)
            rec.location_id = location_id.id
            stock_quant = self.env['stock.quant'].search(
                [('product_id.product_tmpl_id', '=', product_id.id), ('location_id', '=', location_id.id)])
            if stock_quant:
                rec.qty_on_hand = sum(stock_quant.mapped('quantity'))
            else:
                rec.qty_on_hand = 0.0

    def action_view_zero_quant_items(self):
        ctx = dict(self.env.context or {})
        zero_stock_item_detail = self.env['multistore.product.detail'].search([]).filtered(lambda x: x.qty_on_hand == 0.0)
        action = {
            'name': _('Zero Stock Report'),
            'view_mode': 'list',
            'view_id': self.env.ref('bi_alsaree_product_enhancement.multistore_product_detail_tree').id,
            'res_model': 'multistore.product.detail',
            'type': 'ir.actions.act_window',
            'context': ctx,
            'domain': [('id', 'in', zero_stock_item_detail.ids)],
        }
        return action

    # def action_view_zero_quant_items(self):
    #     ctx = dict(self.env.context or {})
    #     # zero_stock_item_detail = self.env['multistore.product.detail'].search([]).filtered(lambda x: x.qty_on_hand == 0.0)
    #     all_item_detail = self.env['multistore.product.detail'].search([])
    #     all_item_detail = all_item_detail.mapped('product_id')
    #     zero_stock_item_detail = self.env['multistore.product.detail'].search([])
    #     product_ids = [self.env['stock.quant'].search([('product_id', '!=', item.product_id.id)]) for item in zero_stock_item_detail]
    #     action = {
    #         'name': _('Zero Stock Report'),
    #         'view_mode': 'list',
    #         'view_id': self.env.ref('bi_alsaree_product_enhancement.multistore_product_detail_tree').id,
    #         'res_model': 'multistore.product.detail',
    #         'type': 'ir.actions.act_window',
    #         'context': ctx,
    #         'domain': [('id', 'in', zero_stock_item_detail.ids)],
    #     }
    #     return action

    def update_zero_quant_items(self):
        multistore_product_detail_ids = self.env['multistore.product.detail'].search([])
        for rec in multistore_product_detail_ids:
            product_id = rec.product_id
            location_id = self.env['stock.location'].search([('store_id', '=', rec.store_id)], limit=1)
            rec.location_id = location_id.id
            stock_quant = self.env['stock.quant'].search(
                [('product_id.product_tmpl_id', '=', product_id.id), ('location_id', '=', location_id.id)])
            if stock_quant:
                rec.qty_on_hand = sum(stock_quant.mapped('quantity'))
            else:
                rec.qty_on_hand = 0.0
