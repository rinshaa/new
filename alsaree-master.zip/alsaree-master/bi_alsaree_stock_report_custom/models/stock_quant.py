from odoo import fields,models, api, _
from collections import defaultdict, OrderedDict


class StockQuant(models.Model):
    _inherit = 'stock.quant'

    default_code = fields.Char(string='Internal Reference', compute='_compute_default_code')

    def _compute_default_code(self):
        for rec in self:
            store_id = rec.location_id.store_id
            product_detail_id = rec.product_id.multistore_product_detail_ids.filtered(lambda x: x.store_id == store_id)
            rec.default_code = product_detail_id.default_code
