{
    'name': 'Alsaree Custom Stock Report',
    'version': '15.0.0.1',
    'category': 'Inventory/Stock',
    "license": "OPL-1",
    'depends': ['base', 'bi_alsaree_product_enhancement'],
    'data': [
        "views/stock_quant.xml",
        "views/multistore_product_detail_views.xml",
    ],
    'installable': True,
    'auto_install': False,
}