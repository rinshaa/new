from odoo import models, fields,api
from datetime import datetime, timedelta



class InternalTransfer(models.Model):
    _name = "internal.transfer.data"
    _order = "id desc"
    _description =" InternalTransfer"

    # picking = fields.Char(string="Picking")
    picking_id = fields.Many2one('stock.picking', string="Picking")
    date = fields.Datetime(string="Date")
    request_data = fields.Text(string="Request Data")
    response_data = fields.Text(string="Response Data")
    location_type = fields.Selection([
        ("source", "Source"),
        ("destination", "Destination"), ])
    @api.model
    def delete_old_records(self):
        # manual_date = datetime(2023, 12, 24)
        # one_month_ago = manual_date - timedelta(days=30)
        one_month_ago = datetime.now() - timedelta(days=30)
        old_records = self.search([('create_date', '<', one_month_ago)])
        if old_records:
            old_records.unlink()
        return True
