from odoo import fields, models,api
from datetime import datetime, timedelta


class PurchaseOrderData(models.Model):
    _name = "purchase.order.data"
    _order = "id desc"
    _description ="Purchase Order Data"

    po_id = fields.Many2one('purchase.order', string="Purchase Order")
    picking_id = fields.Many2one('stock.picking', string="Picking")
    response = fields.Char(string="Response")
    date = fields.Datetime(string="Date")
    receipt_data = fields.Text(string="Receipt Data")

    @api.model
    def delete_old_records(self):
        one_month_ago = datetime.now() - timedelta(days=30)
        old_records = self.search([('create_date', '<', one_month_ago)])
        if old_records:
            old_records.unlink()
        return True
