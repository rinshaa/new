from odoo import models,fields,api
from datetime import datetime, timedelta


class SaleOrderData(models.Model):
    _name = "sale.order.data"
    _order = "id desc"
    _description ="Sale Order Data"

    order_name = fields.Char(string="Sale Order")
    request_data = fields.Text(string="Request Data")
    request_date = fields.Datetime(string="Request Date")
    order_response = fields.Char(string="Order Response")

    @api.model
    def delete_old_records(self):
        one_month_ago = datetime.now() - timedelta(days=30)
        old_records = self.search([('create_date', '<', one_month_ago)])
        if old_records:
            old_records.unlink()
        return True
