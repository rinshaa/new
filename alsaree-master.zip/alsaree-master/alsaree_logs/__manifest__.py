{
    "name": "AL-Saree Logs",
    "summary": """
        AL-Saree API Logs""",
    "author": "Bassam Infotech LLP",
    "website": "https://www.bassaminfotech.com",
    "category": "",
    "license": "OPL-1",
    "version": "15.0.0.1",
    "depends": ["base", "stock", "purchase"],
    "data": [
        "security/ir.model.access.csv",
        "views/sale_order_data.xml",
        "views/purchase_order_data.xml",
        "views/internal_transfer.xml",
        "data/sale_order_logs.xml",
        "data/purchase_order_logs.xml",
        "data/internal_transfer_log.xml"

    ],
}
