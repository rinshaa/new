from odoo import fields, models,api
from datetime import datetime, timedelta


class PurchaseOrderLine(models.Model):
    _inherit = "purchase.order.line"

    product_barcode =fields.Char(string="Barcode" ,related="product_id.barcode")