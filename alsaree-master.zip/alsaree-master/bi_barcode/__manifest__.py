{
    "name": "BI Barcode",
    "summary": """
        barcode in purchase orderline""",
    "author": "Bassam Infotech LLP",
    "website": "https://www.bassaminfotech.com",
    "category": "Purchase",
    "license": "OPL-1",
    "version": "15.0.0.1",
    "depends": ["purchase", "product"],
    "data": [
        "views/product_barcode.xml",
        "views/purchase_report.xml",
    ],
}

