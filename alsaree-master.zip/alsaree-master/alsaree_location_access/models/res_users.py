from odoo import fields,models, api, _
from collections import defaultdict, OrderedDict


class ResUsers(models.Model):
    _inherit = 'res.users'

    warehouse_ids = fields.Many2many('stock.warehouse', string='Warehouses')
    location_ids = fields.Many2many('stock.location', string='location')
