{
    'name': 'Alsaree location Access',
    'version': '15.0.0.1',
    'category': 'Inventory/Stock',
    "license": "OPL-1",
    'depends': ['base', 'stock'],
    'data': [
        "views/user_views.xml",
        "views/user_groups.xml",
        "views/manage_warehouse.xml"

    ],
    'installable': True,
    'auto_install': False,
}