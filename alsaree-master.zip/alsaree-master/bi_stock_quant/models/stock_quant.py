from odoo import models, fields, api


class StockQuant(models.Model):
    _inherit = 'stock.quant'

    expire_date =fields.Char(string="Expire Date", default="365 Days",store=True)

    

