{
    "name": "BI EXPIRE DATE",
    "summary": """
        expire date field in barcode module""",
    "author": "Bassam Infotech LLP",
    "website": "https://www.bassaminfotech.com",
    "category": "stock",
    "license": "OPL-1",
    "version": "15.0.0.1",
    "depends": ["base","stock", "product","sale","stock_barcode"],
    "data": [
        "views/stock_quant_view.xml",
        
    ],
}

