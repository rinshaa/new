from odoo import fields,models, api, _
from lxml import etree


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    @api.model
    def fields_view_get(self, view_id=None, view_type="form", toolbar=False, submenu=False):
        res = super(StockPicking, self).fields_view_get(
            view_id=view_id, view_type=view_type, toolbar=toolbar, submenu=submenu
        )
        doc = etree.XML(res["arch"])
        is_super_visor = self.env.user.has_group("al_saree_api_integration.group_stock_supervisor")
        is_picker = self.env.user.has_group("al_saree_api_integration.group_stock_picker")
        if is_picker or is_super_visor:
            for node in doc.xpath("//kanban"):
                node.set("create", "false")
        res["arch"] = etree.tostring(doc)
        return res
