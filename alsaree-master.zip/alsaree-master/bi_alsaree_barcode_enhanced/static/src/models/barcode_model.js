/** @odoo-module **/

import BarcodeModel from '@stock_barcode/models/barcode_model';
import {_t} from "web.core";
import { sprintf } from '@web/core/utils/strings';
import { patch } from 'web.utils';

patch(BarcodeModel.prototype, 'bi_alsaree_barcode_enhanced_barcode_picking_model_custom', {
    async validate() {
        const lines = this.initialState.lines;
        if (this.groups.group_supervisior && this.record.picking_type_code == "incoming") {
            if (lines) {
                for (const record of lines) {
                    if (record.product_uom_qty < record.qty_done) {
                        const message = sprintf(
                            _t("You Must be validate in the product quantity equal in Done Quantity...."))
                        this.notification.add(message, { type: 'warning' }
                        );
                        return;      
                    }
                }
            }
        }
        await this.save();
        const action = await this.orm.call(
            this.params.model,
            this.validateMethod,
            [this.recordIds]
        );
        const options = {
            on_close: ev => this._closeValidate(ev)
        };
        if (action && action.res_model) {
            return this.trigger('do-action', { action, options });
        }
        return options.on_close();
    },
    async _createNewLine(params) {
        if (this.groups.group_supervisior && this.record.picking_type_code == "incoming") {
           if (!params.fieldsParams.product_id.product_uom_qty) {
                const message = sprintf(
                    _t("The Product not in the List...."))
                this.notification.add(message, { type: 'warning' }
                );
                return;     
            } 
            return;
        }  
        if (params.fieldsParams && params.fieldsParams.uom && params.fieldsParams.product_id) {
            let productUOM = this.cache.getRecord('uom.uom', params.fieldsParams.product_id.uom_id);
            let paramsUOM = params.fieldsParams.uom;
            if (paramsUOM.category_id !== productUOM.category_id) {
                // Not the same UoM's category -> Can't be converted.
                const message = sprintf(
                    _t("Scanned quantity uses %s as Unit of Measure, but this UoM is not compatible with the product's one (%s)."),
                    paramsUOM.name, productUOM.name
                );
                this.notification.add(message, { title: _t("Wrong Unit of Measure"), type: 'danger'});
                return false;
            }
        }
        const newLine = Object.assign(
            {},
            params.copyOf,
            this._getNewLineDefaultValues(params.fieldsParams)
        );
        await this.updateLine(newLine, params.fieldsParams);
        this.currentState.lines.push(newLine);
        this._groupLinesByPage(this.currentState);
        return newLine;
    }

});
