
/** @odoo-module **/

import MainComponent from '@stock_barcode/components/main';
import { patch } from 'web.utils';

patch(MainComponent.prototype, 'bi_alsaree_barcode_enhanced', {
    _onBarcodeScanned(barcode) {
        if(this.env.model.currentState.lines){
            this.env.model.currentState.lines.forEach(record => {
                if(record.product_barcode == barcode){
                    record.is_barcode_value = true
                }
            });
        }
        if (this.displayBarcodeApplication) {
            this.env.model.processBarcode(barcode);
        }
    }
});