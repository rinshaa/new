{
    'name': 'Alsaree Barcode Enhanced',
    'version': '15.0.2.0.3',
    'category': 'Inventory/Stock',
    "license": "OPL-1",
    'depends': ['base', 'stock_barcode', 'web',"al_saree_api_integration"],
    'data': [],
    'assets': {
        'web.assets_qweb': [
            'bi_alsaree_barcode_enhanced/static/src/components/lines.xml',
        ],
        'web.assets_backend': [
            'bi_alsaree_barcode_enhanced/static/src/models/barcode_model.js',
            'bi_alsaree_barcode_enhanced/static/src/models/line.js',
        ]
    },
    'installable': True,
    'auto_install': False,
    
}
