# from odoo import api, fields, models
# from odoo.exceptions import ValidationError
#
#
# class SaleOrder(models.Model):
#     _inherit = 'sale.order'
#
#     def _get_product(self, product_details, source_details):
#         """
#         @private - Get or create the relevant product
#         """
#         # product_id = self.env['product.product'].search([('default_code', '=', product_details['unique_id'])])
#         print("product_details____UPDATED", product_details)
#         product_detail_id = self.env['multistore.product.detail'].search([('default_code', '=', product_details['unique_id']), ('store_id', '=', source_details['store_id'])], limit=1)
#         if len(product_detail_id) > 1:
#             return {'error': f"Multiple products found with the Internal reference - {product_details['unique_id']}",
#                     'status': 400}
#         elif not product_detail_id:
#              return {'error': f"Product not found with the Code - {product_details['unique_id']}",
#                     'status': 400}  # added on 30052023
#         elif len(product_detail_id) == 1:
#             return product_detail_id.product_id.product_variant_id
#         else:
#             return {'error': f"Unknown error occurred when finding product for code - {product_details['unique_id']}"}