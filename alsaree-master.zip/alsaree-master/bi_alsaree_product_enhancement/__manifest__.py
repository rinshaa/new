{
    "name": "Alsaree Product Enhancement",
    "summary": """
        Alsaree Product Enhancement""",
    "author": "Bassam Infotech LLP",
    "website": "https://www.bassaminfotech.com",
    "category": "",
    "license": "OPL-1",
    "version": "15.0.0.1",
    "depends": ["stock", "sale", "al_saree_api_integration"],
    "data": [
        "security/ir.model.access.csv",
        "views/product_views.xml",
        "views/multistore_product_detail.xml",
    ],
}
