import requests
import json

BASE_URL = 'http://localhost:8069'
# ====================Get access token==========================
payload = {
    'client_id': '46haWKojnVEMonSLmwhMc1FKIXQD8u',
    'client_secret': 'iUaRMRoYDUZSadwK9pwAiTKBcUFHTz',
    'grant_type': 'client_credentials',
}

response = requests.post(
    f'{BASE_URL}/oauth2/access_token',
    data=payload,
    headers={'Accept': '*/*'}
)
print("response__", response)
token_data = response.json()
print(response.json())

