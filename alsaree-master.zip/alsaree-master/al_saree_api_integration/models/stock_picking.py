from odoo import models, fields, api, _
import json
import requests
from datetime import datetime
import logging

_logger = logging.getLogger(__name__)


class StockPicking(models.Model):
    _inherit = "stock.picking"

    delivery_status = fields.Selection([
        ("initiated", "Initiated"),
        ("picked", "Picked"),
        ("packed", "Packed"),
        ("shipped", "Shipped"),
    ], default="initiated")

    last_updated_date = fields.Datetime(string="Last Updated On")

    def action_items_picked(self):
        self.delivery_status = "picked"
        # url = "www.sample.com"
        payload = {
            "picking_id": self.id,
            "picking_name": self.name,
            "delivery_status": self.delivery_status,
            "responsible_user_id": self.user_id.id,
            "responsible_user_name": self.user_id.name
        }
        # response = requests.post(url, data=payload)
        # print("response___", response)

    def action_items_packed(self):
        self.delivery_status = "packed"
        url = "www.sample.com"
        vals = {
            "picking_id": self.id,
            "picking_name": self.name,
            "delivery_status": self.delivery_status,
            "responsible_user_id": self.user_id.id,
            "responsible_user_name": self.user_id.name
        }
        # response = requests.post(url, data=vals)

    def button_validate(self):
        res = super(StockPicking, self).button_validate()
        header = {
            "Content-Type": "application/json",
            "x_api_key": "f44d2017-e99a-4473-b48b-dd9a24789ba8"
        }
        url = "https://alsaree3service.com/api/store/update_inventory_status"
        for picking in self:
            if picking.state == "done":
                data = {}
                if picking.picking_type_code == 'outgoing':
                    picking.delivery_status = "shipped"
                    if picking.sale_id:
                        data = {
                            "order_id": picking.sale_id.alsaree_id,
                            "order_status": 7,
                        }
                        url = "https://alsaree3service.com/api/store/update_order_status"
                        data_response = requests.post(url, data=json.dumps(data), headers=header)
                        return res

                    for line in picking.move_ids_without_package:
                        data = {
                            "store_id": picking.location_id.store_id,
                            "product_category_id": line.product_id.categ_id.alsaree_id,
                            # "product_id": line.product_id.alsaree_id,
                            "product_id": picking.get_product_alsaree_id(line.product_id,
                                                                         picking.location_id.store_id),
                            "quantity": -line.quantity_done
                        }

                        response = requests.post(url, data=json.dumps(data), headers=header)
                        _logger.info(f'Data-of-outgoing: {data}')
                        _logger.info(f'data_response_outgoing: {response}')

                elif picking.picking_type_code == 'incoming':
                    # TODO: Quantity will be updated if a return order created for a sales order manually. should fix it.
                    if picking.sale_id:
                        return res
                    for line in picking.move_ids_without_package:
                        data = {
                            "store_id": picking.location_dest_id.store_id,
                            "product_category_id": line.product_id.categ_id.alsaree_id,
                            # "product_id": line.product_id.alsaree_id,
                            "product_id": picking.get_product_alsaree_id(line.product_id, picking.location_dest_id.store_id),
                            "quantity": line.quantity_done
                        }
                        response = requests.post(url, data=json.dumps(data), headers=header)
                        purchase_order_data_id = self.env['purchase.order.data'].create({
                            "po_id": self.env['purchase.order'].search([('name', '=', picking.origin)]).id,
                            "picking_id": picking.id,
                            "response": str(response.text),
                            "date": datetime.now(),
                            "receipt_data": str(data),

                        })
                        _logger.info(f'data_of_incoming: {data}')
                        _logger.info(f'data_response_incoming: {response}')

                else:
                    # if picking.sale_id:
                    #     return res
                    source_location_data = {}
                    dest_location_data = {}
                    for line in picking.move_ids_without_package:
                        source_location_data = {
                            "store_id": picking.location_id.store_id,
                            "product_category_id": line.product_id.categ_id.alsaree_id,
                            # "product_id": line.product_id.alsaree_id,
                            "product_id": picking.get_product_alsaree_id(line.product_id,
                                                                         picking.location_id.store_id),
                            "quantity": -line.quantity_done
                        }
                        dest_location_data = {
                            "store_id": picking.location_dest_id.store_id,
                            "product_category_id": line.product_id.categ_id.alsaree_id,
                            # "product_id": line.product_id.alsaree_id,
                            "product_id": picking.get_product_alsaree_id(line.product_id,
                                                                         picking.location_dest_id.store_id),
                            "quantity": line.quantity_done
                        }

                        response_source_location = requests.post(url, data=json.dumps(source_location_data), headers=header)
                        response_dest_location = requests.post(url, data=json.dumps(dest_location_data), headers=header)
                        internal_trnasfer_source = self.env['internal.transfer.data'].create({
                            "picking_id": picking.id,
                            "date": datetime.now(),
                            "request_data": str(source_location_data),
                            "response_data": str(response_source_location.text),
                            "location_type": 'source',
                        })
                        internal_trnasfer_destination = self.env['internal.transfer.data'].create({
                            "picking_id": picking.id,
                            "date": datetime.now(),
                            "request_data": str(dest_location_data),
                            "response_data": str(response_dest_location.text),
                            "location_type": 'destination',
                        })
                        _logger.info(f'source_location_data: {source_location_data}')
                        _logger.info(f'data_response_source_location: {response_source_location}')
                        _logger.info(f'dest_location_data: {dest_location_data}')
                        _logger.info(f'data_response_response_dest_location: {response_dest_location}')
        return res

    def get_product_alsaree_id(self, product_id, store_id):
        multistore_line = product_id.multistore_product_detail_ids.filtered(lambda x: x.store_id == store_id)
        return multistore_line.alsaree_id

    @api.model
    def create(self, vals):
        """
        Assigning Available Picker Automatically.
        """
        res = super().create(vals)
        for rec in res:
            if rec.picking_type_code == 'outgoing':
                picker_ids = self.env.ref("al_saree_api_integration.group_stock_picker").users
                assigned_picker_ids = self.env['stock.picking'].search(
                    [('picking_type_code', '=', 'outgoing'), ('state', 'not in', ['done', 'cancel'])]).user_id.ids
                for picker in picker_ids:
                    if picker.id not in assigned_picker_ids:
                        rec.user_id = picker.id
                        break
        return res
