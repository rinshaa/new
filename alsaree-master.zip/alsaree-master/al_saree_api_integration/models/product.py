from odoo import models, fields, api, _
import json
import logging

_logger = logging.getLogger(__name__)


class ProductProduct(models.Model):
    _inherit = "product.product"

    # def create_product(self, data):  # replaced on 23112023
    #     product_details = data['params'].get('product_details')
    #     print("BARCODE", )
    #     category = product_details.get('product_category_id')
    #     # product_categ_id = self.env['product.category'].search([('id', '=', category)])
    #     product_categ_id = self.env['product.category'].search([('alsaree_id', '=', category)])
    #     if not product_categ_id:
    #         return {'error': f"The given Product Category doesn't exist in Odoo.", 'status': 400}
    #     try:
    #         product_id = self.env['product.product'].search([(
    #             "default_code", "=", product_details.get("code")
    #         )])
    #         if product_id:
    #             return {'error': f"A product is already exist with the code - {product_details['code']}",
    #                     'status': 400}
    #
    #         barcode_product = self.env['product.product'].search([(
    #             "barcode", "=", product_details.get("barcode")
    #         )])
    #         if barcode_product and barcode_product.barcode:
    #             return {'error': f"Product Barcode {product_details.get('barcode')} is already exist.",
    #                     'status': 400}
    #
    #         product_id = self.env['product.product'].create({
    #             'name': product_details.get('name', product_details['code']) or product_details['code'],
    #             'type': product_details.get('type'),
    #             'categ_id': product_categ_id.id,
    #             'default_code': product_details.get('code'),
    #             # 'list_price': product_details.get('sale_price', 0.00),
    #             'description': product_details.get('description'),
    #             'list_price': product_details.get('item_sales_price'),
    #             'standard_price': product_details.get('item_purchase_price'),
    #             # 'barcode': product_details.get('barcode'),
    #             'store_id': product_details.get('store_id'),
    #             'alsaree_id': product_details.get('product_id'),
    #             'tracking': 'lot',
    #             'use_expiration_date': True
    #         })
    #         if product_details.get('barcode'):
    #             product_id.barcode = product_details.get('barcode')
    #
    #         response = {'success': True, 'message': f'Product {product_id.name} created successfully',
    #                     'status': 200}
    #     except Exception as e:
    #         response = {'error': e, 'status': 400}
    #     return response
    #
    # def update_product(self, data):  # replaced on 23112023
    #     product_details = data['params'].get('product_details')
    #     category = product_details.get('product_category_id')
    #     product_categ_id = self.env['product.category'].search([('alsaree_id', '=', category)])
    #     if not product_categ_id:
    #         return {'error': f"The given Product Category doesn't exist in Odoo.", 'status': 400}
    #     try:
    #         product_id = self.env['product.product'].search([(
    #             "default_code", "=", product_details.get("code")
    #         )])
    #
    #         if product_details.get("barcode"):
    #             barcode_product = self.env['product.product'].search([(
    #                 "barcode", "=", product_details.get("barcode")), ("id", "!=", product_id.id)])
    #             if barcode_product:
    #                 return {'error': f"Product Barcode {product_details.get('barcode')} is already exist.",
    #                         'status': 400}
    #
    #         if not product_id:
    #             return {'error': f"product not found with the Product Code - {product_details['code']}",
    #                     'status': 400}
    #
    #         if len(product_id) > 1:
    #             return {'error': f"Multiple products found with the Product Code - {product_details['code']}",
    #                     'status': 400}
    #
    #         elif len(product_id) == 1:
    #             product_id.write({
    #                 'name': product_details.get('name'),
    #                 'type': product_details.get('type'),
    #                 'categ_id': product_categ_id.id,
    #                 'description': product_details.get('description'),
    #                 'list_price': product_details.get('item_sales_price'),
    #                 'standard_price': product_details.get('item_purchase_price'),
    #                 # 'barcode': product_details.get('barcode'),
    #                 'store_id': product_details.get('store_id')
    #             })
    #             if product_details.get("barcode"):
    #                 product_id.barcode = product_details.get("barcode")
    #             else:
    #                 product_id.barcode = False
    #         response = {'success': True, 'message': f'Product {product_id.name} updated successfully',
    #                     'status': 200}
    #     except Exception as e:
    #         response = {'error': e, 'status': 400}
    #     print("response___", response)
    #     return response

    def create_product(self, data):
        print("create_product___NEW")
        product_details = data['params'].get('product_details')
        # category = product_details.get('product_category_id')
        category = product_details.get('odoo_product_category_id')
        # product_categ_id = self.env['product.category'].search([('alsaree_id', '=', category)])
        product_categ_id = self.env['product.category'].search([('odoo_product_category_id', '=', category)])
        if not product_categ_id:
            return {'error': f"The given Product Category doesn't exist in Odoo.", 'status': 400}
        try:
            # product_id = self.env['product.product'].search([(
            #     "default_code", "=", product_details.get("code")
            # )])
            product_id = self.env['multistore.product.detail'].search([(
                "default_code", "=", product_details.get("code")
            ), ('store_id', '=', product_details['store_id'])
            ], limit=1)
            if product_id:
                return {'error': f"A product is already exist with the code - {product_details['code']}",
                        'status': 400}

            barcode_product = self.env['product.template'].search([(
                "barcode", "=", product_details.get("barcode")
            )])
            if barcode_product and barcode_product.barcode:
                multistore_detail_id = self.env['multistore.product.detail'].create(
                    {
                        'product_id': barcode_product.id,
                        'list_price': product_details.get('item_sales_price'),
                        'standard_price': product_details.get('item_purchase_price'),
                        'default_code': product_details.get('code'),
                        'store_id': product_details.get('store_id'),
                        'alsaree_id': product_details.get('product_id'),
                    })
                barcode_product.multistore_product_detail_ids = [(4, multistore_detail_id.id)]
                return {'success': True, 'message': f'Product {barcode_product.name} created successfully',
                            'status': 200}
                # return {'error': f"Product Barcode {product_details.get('barcode')} is already exist.",
                #         'status': 400}
            product_id = self.env['product.template'].create({
                'name': product_details.get('name', product_details['code']) or product_details['code'],
                'type': product_details.get('type'),
                'categ_id': product_categ_id.id,
                # 'default_code': product_details.get('code'),
                'description': product_details.get('description'),
                # 'list_price': product_details.get('item_sales_price'),
                # 'standard_price': product_details.get('item_purchase_price'),
                # 'store_id': product_details.get('store_id'),
                # 'alsaree_id': product_details.get('product_id'),
                'tracking': 'lot',
                'use_expiration_date': True,
                'multistore_product_detail_ids': [(0, 0, {'list_price': product_details.get('item_sales_price'),
                                                          'standard_price': product_details.get('item_purchase_price'),
                                                          'default_code': product_details.get('code'),
                                                          'store_id': product_details.get('store_id'),
                                                          'alsaree_id': product_details.get('product_id'),
                                                          })],
            })

            if product_details.get('barcode'):
                product_id.barcode = product_details.get('barcode')

            response = {'success': True, 'message': f'Product {product_id.name} created successfully',
                        'status': 200}
        except Exception as e:
            response = {'error': e, 'status': 400}
        return response

    def update_product(self, data):
        product_details = data['params'].get('product_details')
        # category = product_details.get('product_category_id')
        category = product_details.get('odoo_product_category_id')
        # product_categ_id = self.env['product.category'].search([('alsaree_id', '=', category)])
        product_categ_id = self.env['product.category'].search([('odoo_product_category_id', '=', category)])
        if not product_categ_id:
            return {'error': f"The given Product Category doesn't exist in Odoo.", 'status': 400}
        try:
            # product_id = self.env['product.product'].search([(
            #     "default_code", "=", product_details.get("code")
            # )])
            product_detail_id = self.env['multistore.product.detail'].search([(
                "default_code", "=", product_details.get("code")), ('store_id', '=', product_details['store_id'])
            ], limit=1)
            if product_details.get("barcode"):
                barcode_product = self.env['product.product'].search([(
                    # "barcode", "=", product_details.get("barcode")), ("id", "!=", product_detail_id.product_id.id)])
                    "barcode", "=", product_details.get("barcode")), ("id", "!=", product_detail_id.product_id.product_variant_ids[:1].id)])
                if barcode_product:
                    return {'error': f"Product Barcode {product_details.get('barcode')} is already exist.",
                            'status': 400}

            if not product_detail_id:
                return {'error': f"product not found with the Product Code - {product_details['code']}",
                        'status': 400}

            if len(product_detail_id) > 1:
                return {'error': f"Multiple products found with the Product Code - {product_details['code']}",
                        'status': 400}

            elif len(product_detail_id) == 1:
                product_detail_id.product_id.write({
                    'name': product_details.get('name'),
                    'type': product_details.get('type'),
                    'categ_id': product_categ_id.id,
                    'description': product_details.get('description'),
                    # 'list_price': product_details.get('item_sales_price'),
                    # 'standard_price': product_details.get('item_purchase_price'),
                    # 'store_id': product_details.get('store_id')
                })
                product_detail_id.write(
                    {
                        'list_price': product_details.get('item_sales_price'),
                        'standard_price': product_details.get('item_purchase_price'),
                        'store_id': product_details.get('store_id')
                    }
                )
                if product_details.get("barcode"):
                    product_detail_id.product_id.barcode = product_details.get("barcode")
                else:
                    product_detail_id.product_id.barcode = False
            response = {'success': True, 'message': f'Product {product_detail_id.product_id.name} updated successfully',
                        'status': 200}
        except Exception as e:
            response = {'error': e, 'status': 400}
        print("response___", response)
        return response


class ProductTemplate(models.Model):
    _inherit = "product.template"

    alsaree_id = fields.Char(string='Alsaree ID')
    arabic_name = fields.Char(string='Arabic Name')
    store_id = fields.Char(string='Store ID')
