from odoo import models, fields, api, _
import json


class AccountMove(models.Model):
    _inherit = "account.move"

    def action_register_payment(self):
        pass
        # val = [{'journal_id': bank_journal_id,
        #         'payment_method_id': payment_method_id,
        #         'invoice_ids': [(4, invoice_id)]}]
