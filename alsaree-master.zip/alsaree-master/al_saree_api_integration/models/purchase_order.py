from odoo import api, fields, models
from odoo.exceptions import ValidationError


class PurchaseOrderLine(models.Model):
    _inherit = 'purchase.order.line'

    @api.onchange('product_id', 'company_id')
    def onchange_product_id(self):
        res = super().onchange_product_id()
        multistore_detail_id = self.env['multistore.product.detail'].search([
            ('store_id', '=', self.order_id.picking_type_id.default_location_dest_id.store_id),
            ('product_id', '=', self.product_id.product_tmpl_id.id)
        ])
        self.price_unit = multistore_detail_id.standard_price
        return res

    @api.onchange('product_qty', 'product_uom', 'company_id')
    def _onchange_quantity(self):
        res = super()._onchange_quantity()
        multistore_detail_id = self.env['multistore.product.detail'].search([
            ('store_id', '=', self.order_id.picking_type_id.default_location_dest_id.store_id),
            ('product_id', '=', self.product_id.product_tmpl_id.id)
        ])
        self.price_unit = multistore_detail_id.standard_price
        return res
