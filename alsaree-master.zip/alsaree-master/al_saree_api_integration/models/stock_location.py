from odoo import models, fields, api, _
import json
import requests


class Location(models.Model):
    _inherit = "stock.location"

    store_id = fields.Char(string='Store ID')
