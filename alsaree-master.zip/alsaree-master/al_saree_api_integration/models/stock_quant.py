from odoo import models, fields, api, _
import json
import requests
from datetime import datetime


class StockQuant(models.Model):
    _inherit = "stock.quant"

    def _get_inventory_move_values(self, qty, location_id, location_dest_id, out=False):
        res = super()._get_inventory_move_values(qty, location_id, location_dest_id, out=False)
        header = {
            "Content-Type": "application/json",
            "x_api_key": "f44d2017-e99a-4473-b48b-dd9a24789ba8"
        }
        url = "https://alsaree3service.com/api/store/update_inventory_status"
        product_id = self.env['product.product'].browse(res.get('product_id'))
        if location_dest_id.usage == 'inventory':
            location_data = {
                "store_id": location_id.store_id,
                "product_category_id": product_id.categ_id.alsaree_id,
                # "product_id": product_id.alsaree_id,
                "product_id": product_id.multistore_product_detail_ids.filtered(lambda x: x.store_id == location_id.store_id).alsaree_id,
                "quantity": -qty
            }
        else:
            location_data = {
                "store_id": location_dest_id.store_id,
                "product_category_id": product_id.categ_id.alsaree_id,
                "product_id": product_id.multistore_product_detail_ids.filtered(lambda x: x.store_id == location_dest_id.store_id).alsaree_id,
                "quantity": qty
            }
        response_location = requests.post(url, data=json.dumps(location_data), headers=header)
        return res

    def get_product_alsaree_id(self, product_id, store_id):
        multistore_line = product_id.multistore_product_detail_ids.filtered(lambda x: x.store_id == store_id)
        return multistore_line.alsaree_id
