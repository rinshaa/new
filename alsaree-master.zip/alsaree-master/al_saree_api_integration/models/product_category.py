from odoo import models, fields, api, _
import json


class ProductCategory(models.Model):
    _inherit = "product.category"

    alsaree_id = fields.Char(string='Alsaree ID')
    arabic_name = fields.Char(string='Arabic Name')
    store_id = fields.Char(string='Store ID')
    odoo_product_category_id = fields.Char(string='Common Product Category ID')

    def get_all_product_categories(self):
        product_category_ids = self.env['product.category'].search([])
        try:
            product_category_list = []
            response = {}
            for product_category in product_category_ids:
                product_category_list.append(
                    {
                        "id": product_category.id,
                        "name": product_category.name,
                    }
                )
                response = {'success': True,
                            'product_category_list': product_category_list,
                            'status': 200}
        except Exception as e:
            response = {'error': e, 'status': 400}
        return response

    def create_product_category(self, data):
        product_category_details = data['params'].get('product_category_details')
        category_name = product_category_details.get('name')
        category_id = product_category_details.get('product_category_id')
        store_id = product_category_details.get('store_id')
        odoo_product_category_id = product_category_details.get('odoo_product_category_id')
        if not category_name:
            return {'error': f"The Category name should not be empty.", 'status': 400}
        product_categ_id = self.env['product.category'].search([('name', '=', category_name)])
        if not product_categ_id:
            product_categ_id = self.env['product.category'].create(
                {
                    'name': category_name,
                    'store_id': store_id,
                    'alsaree_id': category_id,
                    'odoo_product_category_id': odoo_product_category_id
                }
            )
            response = {'success': True, 'message': f'Product Category {product_categ_id.name} created successfully',
                        'product_category_id': product_categ_id.id,
                        'status': 200}
        else:
            return {'error': f"The given Product Category already exist in Odoo.", 'status': 400}

        return response

    def update_product_category(self, data):
        product_category_details = data['params'].get('product_category_details')
        old_category_id = product_category_details.get('product_category_id')
        new_category_name = product_category_details.get('name')
        store_id = product_category_details.get('store_id')
        odoo_product_category_id = product_category_details.get('odoo_product_category_id')
        # old_product_categ_id = self.env['product.category'].search([('alsaree_id', '=', old_category_id)])
        old_product_categ_id = self.env['product.category'].search([('odoo_product_category_id', '=', odoo_product_category_id)])
        new_product_categ_id = self.env['product.category'].search([('name', '=', new_category_name)])
        try:
            if not old_product_categ_id:
                return {'error': f"There is no Product Category with the id {odoo_product_category_id} in Odoo.", 'status': 400}
            elif not new_category_name:
                return {'error': f"The Product Category name should not be empty.", 'status': 400}
            elif len(new_product_categ_id) > 1:
                return {'error': f"The Product Category {new_category_name} is already exist in Odoo.", 'status': 400}
            elif len(old_product_categ_id) == 1:
                old_product_categ_id.name = new_category_name
                old_product_categ_id.store_id = store_id
            response = {'success': True, 'message': f'Product Category {old_product_categ_id.name} updated successfully',
                        'product_category_id': old_product_categ_id.id,
                        'status': 200}
        except Exception as e:
            response = {'error': e, 'status': 400}
        return response
