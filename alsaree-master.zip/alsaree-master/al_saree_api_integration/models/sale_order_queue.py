from odoo import models, fields, api
from datetime import datetime, timedelta
import json


class SaleOrderQueue(models.Model):
    _name = "sale.order.queue"
    _order = "id desc"
    _description = 'Sale Order Queue'


    order_name = fields.Char(string="Sale Order")
    request_data = fields.Text(string="Request Data")
    response_data = fields.Text(string="Response Data")
    request_date = fields.Datetime(string="Request Date")
    order_id = fields.Many2one('sale.order', string='Sale Order Id')
    state = fields.Selection([('in_queue', 'In Queue'), ('sale_order', 'Sale Order')], default='in_queue')

    def process_sale_order_queues(self):
        sale_order_queue_ids = self.env['sale.order.queue'].search(
            [('state', '=', 'in_queue'), ('order_id', '=', False)], order='id asc')
        for order in sale_order_queue_ids:
            json_request = json.loads(order.request_data)
            sale_order = self.env['sale.order'].sudo().create_sale_order(json_request)
            order.write(
                {
                    'state': 'sale_order',
                    'response_data': sale_order
                }
            )
            # order.unlink()

    @api.model
    def delete_sale_order_queues(self):
        one_month_ago = datetime.now() - timedelta(days=30)
        old_records = self.search([('create_date', '<', one_month_ago), ('state', '=', 'sale_order')])
        if old_records:
            old_records.unlink()
        return True
