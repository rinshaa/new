from odoo import models, fields, api, _
import json
import requests
from datetime import datetime


class StockScrap(models.Model):
    _inherit = "stock.scrap"

    def do_scrap(self):
        res = super().do_scrap()
        header = {
            "Content-Type": "application/json",
            "x_api_key": "f44d2017-e99a-4473-b48b-dd9a24789ba8"
        }
        url = "https://alsaree3service.com/api/store/update_inventory_status"
        for scrap in self:
            location_data = {
                "store_id": scrap.location_id.store_id,
                "product_category_id": scrap.product_id.categ_id.alsaree_id,
                # "product_id": scrap.product_id.alsaree_id,
                "product_id": scrap.get_product_alsaree_id(scrap.product_id,
                                                             scrap.location_id.store_id),
                "quantity": -scrap.scrap_qty
            }
            response_location = requests.post(url, data=json.dumps(location_data), headers=header)
        return res

    def get_product_alsaree_id(self, product_id, store_id):
        multistore_line = product_id.multistore_product_detail_ids.filtered(lambda x: x.store_id == store_id)
        return multistore_line.alsaree_id
