from odoo import models, fields, api, _
import json
import requests
from odoo.tools.float_utils import float_round


class SaleOrder(models.Model):
    _inherit = "sale.order"

    sale_auto_workflow_id = fields.Many2one("sale.auto.workflow.config", string="Sale Auto Workflow")
    alsaree_id = fields.Char(string="Alsaree ID")

    def create_sale_order(self, data):
        header = {
            "Content-Type": "application/json",
            "x_api_key": "f44d2017-e99a-4473-b48b-dd9a24789ba8"
        }
        # url = "https://alsaree3service.com/api/store/update_order_status"
        data_status = self._check_sale_order_data(data)
        if data_status:
            return data_status
        else:
            customer_details = data["params"].get("customer_details")
            if not customer_details.get("mobile"):
                return {'error': 'Mobile number is mandatory', 'status': 400}
            partner_id = self.env["res.partner"].search(
                [("mobile", "=", customer_details.get("mobile"))])  # added on 30052023 instead of email
            # mobile number should be unique - development needed.
            if not partner_id:
                partner_id = self.env["res.partner"].create({
                    "name": customer_details.get("name"),
                    "email": customer_details.get("email"),
                    "mobile": customer_details.get("mobile"),
                    "alsaree_id": customer_details.get("user_id"),
                })
            sale_order_data = []
            order_line = self._prepare_order_lines(data["params"].get('order_details'), data["params"].get('source_details'))
            if 'error' in order_line:
                return order_line

            location_id = self.env['stock.location'].search(
                [('store_id', '=', data["params"].get("source_details").get('store_id'))])
            if not location_id:
                return {
                    'error': f"store_id - {data['params'].get('source_details').get('store_id')} not found in the system",
                    'status': 400}

            sale_order_data.append({
                'partner_id': partner_id.id,
                'warehouse_id': location_id.warehouse_id.id,
                'order_line': order_line,
                'origin': data["params"].get("source_details").get('native_order_number'),
                'alsaree_id': data["params"].get("source_details").get('order_id')
            })

            try:
                sale_order_id = self.create(sale_order_data)
                sale_order_id.action_confirm()
                # invoice_ids = self.env["account.move"]
                # payment_details = data["params"].get("payment_details")
                # create_invoice = payment_details.get("create_invoice")
                # register_payment = payment_details.get("register_payment")
                #
                # sale_auto_workflow_id = self.env["sale.auto.workflow.config"].search(
                #     [("create_invoice", "=", create_invoice),
                #      ("register_payment", "=", register_payment)], limit=1)
                #
                # if sale_auto_workflow_id:
                #     sale_order_id.sale_auto_workflow_id = sale_auto_workflow_id.id
                #     if sale_auto_workflow_id.create_invoice:
                #         invoice_id = sale_order_id.action_generate_auto_invoice()  # Creating invoice
                #         # sale_order_id.invoice_status = "invoiced"
                #         if invoice_id:
                #             invoice_ids += invoice_id
                #
                #             # payment_register_id = invoice_id.action_register_payment()  # Creating Payment
                # created_invoices = ', '.join(invoice_ids.mapped('name'))

                created_sale_orders = ', '.join(sale_order_id.mapped('name'))
                native_order_no = data["params"].get("source_details").get('native_order_number')
                response = {'success': True,
                            'message': f'Sale order {created_sale_orders} created successfully against {native_order_no}',
                            'status': 200}

            except Exception as e:
                response = {'error': e, 'status': 400}

            return response

    def _prepare_order_lines(self, order_details, source_details):
        """
        @private - prepare data for sale order lines from order_details
        """
        data = []
        for detail in order_details:
            items = detail['items']
            for item in items:
                product_id = self._get_product(item, source_details)
                if 'error' in product_id:
                    return product_id
                data.append((0, 0, {
                    'name': product_id.display_name,
                    'product_id': product_id.id,
                    'product_uom_qty': item['quantity'],
                    'product_uom': product_id.uom_id.id,
                    'price_unit': item['item_price']
                }))
        return data

    # def _get_product(self, product_details):   # replaced on 23112023
    #     """
    #     @private - Get or create the relevant product
    #     """
    #     product_id = self.env['product.product'].search([('default_code', '=', product_details['unique_id'])])
    #     if len(product_id) > 1:
    #         return {'error': f"Multiple products found with the Internal reference - {product_details['unique_id']}",
    #                 'status': 400}
    #     elif not product_id:
    #         # try:
    #         #     return self.env['product.product'].create({
    #         #         'name': product_details.get('name', product_details['code']) or product_details['code'],
    #         #         'type': 'product',
    #         #         'default_code': product_details['code'],
    #         #         'list_price': product_details.get('sale_price', 0.00),
    #         #     })
    #         # except Exception as e:
    #         #     return {'error': e, 'status': 400}
    #
    #         return {'error': f"Product not found with the Code - {product_details['unique_id']}",
    #                 'status': 400}  # added on 30052023
    #     elif len(product_id) == 1:
    #         return product_id
    #     else:
    #         return {'error': f"Unknown error occurred when finding product for code - {product_details['unique_id']}"}


    def _get_product(self, product_details, source_details):
        """
        @private - Get or create the relevant product
        """
        # product_id = self.env['product.product'].search([('default_code', '=', product_details['unique_id'])])
        product_detail_id = self.env['multistore.product.detail'].search([('default_code', '=', product_details['unique_id']), ('store_id', '=', source_details['store_id'])], limit=1)
        if len(product_detail_id) > 1:
            return {'error': f"Multiple products found with the Internal reference - {product_details['unique_id']}",
                    'status': 400}
        elif not product_detail_id:
             return {'error': f"Product not found with the Code - {product_details['unique_id']}",
                    'status': 400}  # added on 30052023
        elif len(product_detail_id) == 1:
            return product_detail_id.product_id.product_variant_id
        else:
            return {'error': f"Unknown error occurred when finding product for code - {product_details['unique_id']}"}

    def _check_sale_order_data(self, sale_order_data):
        error = []
        # for data in sale_order_data:
        if sale_order_data["params"].get("customer_details", False):
            pass
        else:
            error.append('Missing customer details')

        if sale_order_data["params"].get('order_details', False):
            pass
        else:
            error.append('Missing order details')

        return error

    def _check_partner(self, partner_data):
        """
        @private - Find a partner assigned with the odoo system, otherwise raise an error
        """
        partner_id = self.env['res.partner'].search([('customer_code', '=', str(partner_data['code']))])
        if not partner_id:
            return {'error': 'Partner code invalid, Relevant partner not found in the odoo system', 'status': 400}
        elif len(partner_id) > 1:
            return {'error': 'Multiple partners found with the same partner code in the odoo system', 'status': 400}
        elif len(partner_id) == 1:
            return partner_id
        else:
            return {'error': 'Unknown error occurred when finding a partner inside the odoo system', 'status': 400}

    def cancel_sale_order(self, data):
        alsaree_order_id = data["params"].get("order_id")
        sale_order_id = self.env['sale.order'].search(
            [('alsaree_id', '=', alsaree_order_id), ('state', '!=', 'cancel')], limit=1)
        if sale_order_id:
            for picking_id in sale_order_id.picking_ids:
                if picking_id.picking_type_code == 'outgoing':
                    if picking_id.state != 'done':
                        sale_order_id.action_cancel()
                        return {'success': True,
                                'message': "Sales Order %s has been successfully cancelled." % sale_order_id.origin,
                                'status': 200}
                    else:
                        location_id = False
                        if picking_id:
                            location_id = picking_id.location_id.id

                        new_picking = self.env['stock.picking'].create({
                            'partner_id': picking_id.partner_id.id,
                            'picking_type_id': picking_id.picking_type_id.return_picking_type_id.id or picking_id.picking_type_id.id,
                            'state': 'draft',
                            'origin': _("Return of %s") % picking_id.name,
                            'location_id': picking_id.location_dest_id.id,
                            'location_dest_id': location_id,
                        })

                        for move_line in picking_id.move_lines:
                            vals_1 = {
                                'name': move_line.product_id.display_name,
                                'product_uom_qty': move_line.quantity_done,
                                'quantity_done': move_line.quantity_done,
                                'product_id': move_line.product_id.id,
                                "product_uom": move_line.product_id.uom_id.id,
                                "location_id": move_line.location_dest_id.id,
                                "location_dest_id": location_id,
                                "picking_id": new_picking.id
                            }

                            move_id = self.env['stock.move'].create(vals_1)
                            move_id.move_line_ids.unlink()

                            for move_line_id in move_line.move_line_ids:
                                vals_2 = {
                                    'move_id': move_id.id,
                                    'product_uom_qty': move_line_id.product_uom_qty,
                                    'qty_done': move_line_id.qty_done,
                                    'product_id': move_line_id.product_id.id,
                                    "product_uom_id": move_line_id.product_id.uom_id.id,
                                    "location_id": move_line_id.location_dest_id.id,
                                    "location_dest_id": location_id,
                                    "lot_id": move_line_id.lot_id.id,
                                    "picking_id": new_picking.id
                                }
                                self.env['stock.move.line'].create(vals_2)

                        sale_order_id.write({"picking_ids": [(4, new_picking.id)]})
                        new_picking.write({"sale_id": sale_order_id.id})
                        new_picking.action_confirm()
                        new_picking.action_assign()
                        new_picking.with_context(skip_expired=True).button_validate()
                        sale_order_id._action_cancel()
                        response = {'success': True,
                                    'message': "Sales Order %s has been successfully cancelled." % sale_order_id.origin,
                                    'status': 200}
                        return response
        return {'success': True, 'status': 200}
