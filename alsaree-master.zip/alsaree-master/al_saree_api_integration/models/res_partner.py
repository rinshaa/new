from odoo import models, fields, api, _
import json


class ResPartner(models.Model):
    _inherit = "res.partner"

    alsaree_id = fields.Char(string='Alsaree ID')

    def create_customer(self, data):
        customer_details = data['params'].get('customer_details')
        try:
            partner_id = self.env['res.partner'].create({
                'name': customer_details.get('name'),
                'email': customer_details.get('email'),
                'mobile': customer_details.get('mobile'),
                'alsaree_id': customer_details.get('user_id'),
            })
            response = {'success': True, 'message': f'Customer {partner_id.name} created successfully',
                        'status': 200}
        except Exception as e:
            response = {'error': e, 'status': 400}
        return response

    def update_customer(self, data):
        customer_details = data['params'].get('customer_details')
        try:
            partner_id = self.env['res.partner'].search([(
                "mobile", "=", customer_details.get("mobile")
            )])
            partner_id.write({
                'name': customer_details.get('name'),
                'email': customer_details.get('email'),
                'alsaree_id': customer_details.get('user_id'),
            })
            response = {'success': True, 'message': f'Customer {partner_id.name} updated successfully',
                        'status': 200}
        except Exception as e:
            response = {'error': e, 'status': 400}
        return response
