from odoo import fields, models, api, _


class SaleAutoWorkFlowConfig(models.Model):
    _name = "sale.auto.workflow.config"
    _description = "Sale Auto Workflow Config"

    name = fields.Char(string="Name")
    # sale_auto_confirm = fields.Boolean(string="Sale Auto Confirm")
    # generate_auto_invoice = fields.Boolean(string="Generate Auto Invoice")
    # generate_auto_payment = fields.Boolean(string="Generate Auto Payment")

    validate_order = fields.Boolean(
        "Confirm Quotation", default=False, help="If it's checked, Order will be Validated."
    )
    create_invoice = fields.Boolean(
        "Create Invoice",
        default=False,
        help="If it's checked, Invoice for Order will be Created.",
    )
    post_invoice = fields.Boolean(
        "Validate Invoice",
        default=False,
        help="If it's checked, Invoice for Order will be Posted.",
    )
    register_payment = fields.Boolean(default=False, help="If it's checked, Payment will be registered for Invoice.")

    post_payment = fields.Boolean(
        string='Post Payment', default=False, help="If it's checked, Payment will be Posted."
    )
