##############################################
# Authentication
auth_url = "http://localhost:8072/auth/"
auth_request_json = {
    "params": {
        "login": "admin",
        "password": "admin",
        "db": "15-al-saree-12052023"
    }
}
##############################################


##############################################
# Sale Order Creation
so_url = "http://localhost:8072/api/generate_sale_order"

so_request_json = {"jsonrpc": "2.0", "params": {
    "customer_details": {
        "name": "Customer Three",
        "email": "two@example.com"
    },
    "order_details": [{
        "product_details": {
            "code": "FURN_6666",
            "name": "TV",
            "product_type": "storable",
            "sale_price": 50000,
            "product_category": "All"
        },
        "currency": "USD",
        "quantity": 1,
        "unit_price": 120,
        # "taxes": false
    }, {
        "product_details": {
            "code": "E-COM11",
            "name": "Drawer",
            "product_type": "storable",
            "sale_price": 50500,
            "product_category": "All"
        },
        "currency": "USD",
        "quantity": 1,
        "unit_price": 125,
        # "taxes": false
    }],
    "payment_details": {
        # "create_invoice": true,
        # "register_payment": true
    }
}
                }
##############################################

{"jsonrpc": "2.0", "params": {
    "customer_details": {
        "name": "Customer Three",
        "email": "two@example.com"
    },
    "order_details": [{
        "product_details": {
            "code": "FURN_6666",
            "name": "TV",
            "product_type": "storable",
            "sale_price": 50000,
            "product_category": "All"
        },
        "currency": "USD",
        "quantity": 2,
        "unit_price": 110,
        "taxes": false
    }, {
        "product_details": {
            "code": "E-COM11",
            "name": "Drawer",
            "product_type": "storable",
            "sale_price": 50500,
            "product_category": "All"
        },
        "currency": "USD",
        "quantity": 3,
        "unit_price": 101,
        "taxes": false
    }],
    "payment_details": {
    "create_invoice": true,
    "register_payment": true
    }
    }
}
