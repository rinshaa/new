from odoo import http
from odoo.http import request
import json
import logging
from datetime import datetime

_logger = logging.getLogger(__name__)
from odoo import http, _, exceptions
# from .serializers import Serializer
# from .exceptions import QueryFormatError
from odoo.addons.odoo_auth2.controllers.auth2_authentication import validate_token


def success_response(record_id, name, msg):
    return {
        "jsonrpc": "2.0",
        "id": record_id,
        "result": {
            "code": 200,
            "message": msg,
            "data": {
                "name": name,
                "debug": "",
                "message": msg,
            },
        },
    }


def error_response(error, msg):
    return {
        "jsonrpc": "2.0",
        "id": None,
        "error": {
            "code": 200,
            "message": msg,
            "data": {
                "name": str(error),
                "debug": "",
                "message": msg,
                "arguments": list(error.args) if hasattr(error, "args") else "",
                "exception_type": type(error).__name__,
            },
        },
    }


class ALSareeAPI(http.Controller):

    @http.route("/auth/", type="json", auth="none", methods=["POST"], csrf=False)
    def authenticate(self, *args, **post):
        try:
            login = post["login"]
        except KeyError:
            raise exceptions.AccessDenied(message=_("`login` is required."))

        try:
            password = post["password"]
        except KeyError:
            raise exceptions.AccessDenied(message=_("`password` is required."))

        try:
            db = post["db"]
        except KeyError:
            raise exceptions.AccessDenied(message=_("`db` is required."))

        http.request.session.authenticate(db, login, password)
        res = request.env["ir.http"].session_info()
        return res

    # @validate_token
    # @http.route('/api/generate_sale_order', type='json', auth="public", methods=['GET', 'POST'], csrf=False)
    # def generate_sale_order(self, **kwargs):
    #     """
    #     Generate the sale order with data coming through the API
    #     """
    #     try:
    #         data = request.jsonrequest
    #         native_order = data["params"].get('source_details').get('native_order_number')
    #         _logger.info(f'Received data: {data}')
    #         if data:
    #             _logger.info('Creating sale order with received data')
    #             sale_order_data = request.env['sale.order.data'].sudo().create(
    #                 {
    #                     'order_name': native_order,
    #                     'request_data': data,
    #                     'request_date': datetime.now(),
    #                 })
    #             _logger.info(f'SO Log Created: {sale_order_data}')
    #             status = request.env['sale.order'].sudo().create_sale_order(data)
    #         else:
    #             status = {'error': 'JSON body is empty', 'error_code': False}
    #     except Exception as e:
    #         native_order = False
    #         status = {'error': e, 'error_code': False}
    #     _logger.info(status)
    #     print("status___", status)
    #     sale_order_data_id = request.env['sale.order.data'].search([('order_name', '=', native_order)], limit=1)
    #     sale_order_data_id.order_response = status
    #     return json.dumps(status)

    @validate_token
    @http.route('/api/generate_sale_order', type='json', auth="public", methods=['GET', 'POST'], csrf=False)
    def generate_sale_order(self, **kwargs):
        """
        Generate the sale order with data coming through the API
        """
        try:
            data = request.jsonrequest
            native_order = data["params"].get('source_details').get('native_order_number')
            _logger.info(f'Received data: {data}')
            if data:
                _logger.info('Creating sale order with received data')

                sale_order_queue = request.env['sale.order.queue'].sudo().create(
                    {
                        'order_name': native_order,
                        'request_data': json.dumps(data),
                        'request_date': datetime.now(),
                    })
                _logger.info(f'SO Queue Created: {sale_order_queue} for {native_order}')
                sale_order_data = request.env['sale.order.data'].sudo().create(
                    {
                        'order_name': native_order,
                        'request_data': data,
                        'request_date': datetime.now(),
                    })
                _logger.info(f'SO Log Created: {sale_order_data}')
                # status = request.env['sale.order'].sudo().create_sale_order(data)
                status = {'success': True,
                          'message': f'Sale order Queue created successfully against {native_order}',
                          'status': 200}
            else:
                status = {'error': 'JSON body is empty', 'error_code': False}
        except Exception as e:
            native_order = False
            status = {'error': e, 'error_code': False}
        _logger.info(status)
        sale_order_data_id = request.env['sale.order.data'].search([('order_name', '=', native_order)], limit=1)
        sale_order_data_id.order_response = status
        return json.dumps(status)

    @validate_token
    @http.route('/api/cancel_sale_order', type='json', auth="public", methods=['GET', 'POST'], csrf=False)
    def cancel_sale_order(self, **kwargs):
        """
        Cancel the sale order
        """
        try:
            data = request.jsonrequest
            _logger.info(f'Received data: {data}')
            if data:
                # sale_order_data = request.env['sale.order.data'].sudo().create(
                #     {
                #         'order_name': native_order,
                #         'request_data': data,
                #         'request_date': datetime.now(),
                #     })
                # _logger.info(f'SO Log Created: {sale_order_data}')
                status = request.env['sale.order'].sudo().cancel_sale_order(data)
            else:
                status = {'error': 'JSON body is empty', 'error_code': False}
        except Exception as e:
            status = {'error': e, 'error_code': False}
        _logger.info(status)
        return json.dumps(status)

    @validate_token
    @http.route('/api/create_product', type='json', auth="public", methods=['GET', 'POST'], csrf=False)
    def create_product(self, **kwargs):
        """
        Create Product with data coming through the API
        """
        try:
            data = request.jsonrequest
            _logger.info(f'Received data: {data}')
            if data:
                _logger.info('Creating Product with received data')
                status = request.env['product.product'].sudo().create_product(data)
            else:
                status = {'error': 'JSON body is empty', 'error_code': False}
        except Exception as e:
            status = {'error': e, 'error_code': False}
        _logger.info(status)
        return json.dumps(status)

    @validate_token
    @http.route('/api/update_product', type='json', auth="public", methods=['GET', 'POST'], csrf=False)
    def update_product(self, **kwargs):
        """
        Update Product with data coming through the API
        """
        try:
            data = request.jsonrequest
            _logger.info(f'Received data: {data}')
            if data:
                _logger.info('Updating Product with received data')
                status = request.env['product.product'].sudo().update_product(data)
            else:
                status = {'error': 'JSON body is empty', 'error_code': False}
        except Exception as e:
            status = {'error': e, 'error_code': False}
        _logger.info(status)
        return json.dumps(status)

    @validate_token
    @http.route('/api/create_customer', type='json', auth="public", methods=['GET', 'POST'], csrf=False)
    def create_customer(self, **kwargs):
        """
        Create Customer with data coming through the API
        """
        try:
            data = request.jsonrequest
            _logger.info(f'Received data: {data}')
            if data:
                _logger.info('Creating Customer with received data')
                status = request.env['res.partner'].sudo().create_customer(data)
            else:
                status = {'error': 'JSON body is empty', 'error_code': False}
        except Exception as e:
            status = {'error': e, 'error_code': False}
        _logger.info(status)
        return json.dumps(status)

    @validate_token
    @http.route('/api/update_customer', type='json', auth="public", methods=['GET', 'POST'], csrf=False)
    def update_customer(self, **kwargs):
        """
        Update Customer with data coming through the API
        """
        try:
            data = request.jsonrequest
            _logger.info(f'Received data: {data}')
            if data:
                _logger.info('Updating Customer with received data')
                status = request.env['res.partner'].sudo().update_customer(data)
            else:
                status = {'error': 'JSON body is empty', 'error_code': False}
        except Exception as e:
            status = {'error': e, 'error_code': False}
        _logger.info(status)
        return json.dumps(status)

    @validate_token
    @http.route('/api/all_product_categories', type='json', auth='public', methods=['GET', 'POST'], csrf=False)
    def all_product_categories(self, **kwargs):
        """
            Return all Product Categories.
        """
        try:
            status = request.env['product.category'].sudo().get_all_product_categories()
        except Exception as e:
            status = {'error': e, 'error_code': False}
        return json.dumps(status)

    @validate_token
    @http.route('/api/create_product_category', type='json', auth="public", methods=['GET', 'POST'], csrf=False)
    def create_product_category(self, **kwargs):
        """
        Create Product Category with data coming through the API
        """
        try:
            data = request.jsonrequest
            _logger.info(f'Received data: {data}')
            if data:
                _logger.info('Creating Product Category with received data')
                status = request.env['product.category'].sudo().create_product_category(data)
                print("status___", status)
            else:
                status = {'error': 'JSON body is empty', 'error_code': False}
        except Exception as e:
            status = {'error': e, 'error_code': False}
        _logger.info(status)
        return json.dumps(status)

    @validate_token
    @http.route('/api/update_product_category', type='json', auth="public", methods=['GET', 'POST'], csrf=False)
    def update_product_category(self, **kwargs):
        """
        Update Product Category with data coming through the API
        """
        try:
            data = request.jsonrequest
            _logger.info(f'Received data: {data}')
            if data:
                _logger.info('Updating Product Category with received data')
                status = request.env['product.category'].sudo().update_product_category(data)
            else:
                status = {'error': 'JSON body is empty', 'error_code': False}
        except Exception as e:
            status = {'error': e, 'error_code': False}
        _logger.info(status)
        return json.dumps(status)
