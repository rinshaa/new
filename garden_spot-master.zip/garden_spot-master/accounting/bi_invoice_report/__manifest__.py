{
    "name": "Bi Invoice Customization",
    "summary": """
       Customization In Invoice Report
    """,
    "description": """
        Customization In Invoice
    """,
    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "support": "sales@bassaminfotech.com",
    "license": "OPL-1",
    "category": "l10n_gcc_invoice",
    "version": "17.2",
    "depends": ["l10n_gcc_invoice","l10n_sa","account"],
    "data": [
        "views/report_invoice.xml",
        "views/paperformat.xml",
        "views/action.xml",
    ],
    "assets" :{
        'web.report_assets_common': [
            'bi_invoice_report/static/src/scss/style.scss',
        ],
    },
    
}