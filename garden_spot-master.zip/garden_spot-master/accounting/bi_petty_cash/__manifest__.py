{
    "name": "bi_petty_cash",
    "summary": """
        Module is used to do petty cash customisation""",
    "description": """
        Module is used to do petty cash customisation
    """,
    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "support": "sales@bassaminfotech.com",
    "license": "OPL-1",
    "category": "Account",
    "version": "17.6",
    "depends": ["account", "hr", "account_accountant","account_payment"],
    "data": [
        "security/security.xml",
        "security/ir.model.access.csv",
        "data/ir_sequence_data.xml",
        "views/account_journal.xml",
        "views/petty_cash_imbursement.xml",
        "views/petty_cash_expenses.xml",
        "views/petty_transfer.xml",
        # "views/account_payment.xml",
        # "views/account_payment_register.xml",
    ],
}
