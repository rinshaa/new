from odoo import fields, models, api, _
from odoo.exceptions import ValidationError


class AccountPayment(models.Model):
    _inherit = 'account.payment'

    attachment_ids = fields.Many2many("ir.attachment", string="Attachment", required=False)

    # @api.constrains('attachment_ids')
    # def check_attachment_ids(self):
    #     for rec in self:
    #         if not rec.attachment_ids:
    #             raise ValidationError(_("Please Add Attachment!"))
