from odoo import fields, models, _,api
from odoo.exceptions import ValidationError


class AccountPaymentRegister(models.TransientModel):
    _inherit = 'account.payment.register'
    
    attachment_ids = fields.Many2many("ir.attachment", string="Attachment", required=False)
    move_type_bool = fields.Boolean(string='Move_type')
    
    @api.model    
    def default_get(self, fields):        
        res = super(AccountPaymentRegister, self).default_get(fields)        
        res_id = self._context.get('active_id')        
        res_model = self._context.get('active_model')        
        task_id = self.env['account.move'].browse(res_id) 
        move_type =  task_id.move_type 
        if move_type == 'out_invoice':
            res['move_type_bool'] = True
        elif  move_type == 'in_invoice':
            res['move_type_bool'] = False
        return res
    def _create_payment_vals_from_wizard(self,first_batch_result):
        # OVERRIDE
        payment_vals = super()._create_payment_vals_from_wizard(first_batch_result)
        if self.attachment_ids:
            payment_vals['attachment_ids'] = self.attachment_ids.ids
        return payment_vals

    def create_payment(self):
        self.ensure_one()
        move_id = self.env['account.move'].browse(self._context.get('active_id'))
        if move_id and move_id.move_type == 'in_invoice' and not self.attachment_ids:
            raise ValidationError(_("Please Add Attachment!"))
        batches = self._get_batches()
        edit_mode = self.can_edit_wizard and (len(batches[0]['lines']) == 1 or self.group_payment)
        to_process = []

        if edit_mode:
            payment_vals = self._create_payment_vals_from_wizard()
            to_process.append({
                'create_vals': payment_vals,
                'to_reconcile': batches[0]['lines'],
                'batch': batches[0],
            })
        else:
            # Don't group payments: Create one batch per move.
            if not self.group_payment:
                new_batches = []
                for batch_result in batches:
                    for line in batch_result['lines']:
                        new_batches.append({
                            **batch_result,
                            'payment_values': {
                                **batch_result['payment_values'],
                                'payment_type': 'inbound' if line.balance > 0 else 'outbound'
                            },
                            'lines': line,
                        })
                batches = new_batches

            for batch_result in batches:
                to_process.append({
                    'create_vals': self._create_payment_vals_from_batch(batch_result),
                    'to_reconcile': batch_result['lines'],
                    'batch': batch_result,
                })

        payments = self._init_payments(to_process, edit_mode=edit_mode)
        move_ids = []
        if self._context.get('active_model', False) == 'account.move':
            move_ids = self._context.get('active_ids', False)
        payments.move_ids = [(6, 0, move_ids)]
        if self._context.get('dont_redirect_to_payments'):
            return True

        action = {
            'name': _('Payments'),
            'type': 'ir.actions.act_window',
            'res_model': 'account.payment',
            'context': {'create': False},
        }
        if len(payments) == 1:
            action.update({
                'view_mode': 'form',
                'res_id': payments.id,
            })
        else:
            action.update({
                'view_mode': 'tree,form',
                'domain': [('id', 'in', payments.ids)],
            })
        return action
