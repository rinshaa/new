from odoo import fields, models


class AccountJournal(models.Model):
    _inherit = "account.journal"

    is_petty_cash = fields.Boolean(string="Is Petty Cash Journal?", copy=False)
    # bi_department_id = fields.Many2one(
    #     string='Division',
    #     comodel_name='bi.department',
    # )

