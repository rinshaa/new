{
    'name': " Pos Receipt Printout",
    'depends': ['point_of_sale'],
    "version": "17.0.2.0.0",
    "summary": """ Pos Receipt Printout""",
    "description": """Pos Receipt Printout""",
    "license": "OPL-1",
    "author": "Bassam Infotech LLP",
    "company": "Bassam Infotech LLP",
    "maintainer": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    'data': [
    ],
    'assets': {
        'point_of_sale._assets_pos': [
            'bi_pos_receipt/static/src/js/pos_receipt.js',
            'bi_pos_receipt/static/src/xml/pos_receipt.xml',
        ],
    },

}
