from odoo import api, models
from datetime import date

class ReportSaleDetails(models.AbstractModel):
    _inherit = 'report.point_of_sale.report_saledetails'

    @api.model
    def _get_report_values(self, docids, data=None):
        res = super(ReportSaleDetails,self)._get_report_values(docids, data=None)

        invoices = []
        session_id = self.env['pos.session'].search([('id','in', docids)])
        inv_date = session_id.stop_at.strftime('%Y-%m-%d') if session_id.stop_at else date.today().strftime('%Y-%m-%d')
        move_ids = self.env['account.move'].search([
            ('move_type','=','out_invoice'),
            ('invoice_date','=', inv_date),
            ('payment_state','in', ['in_payment','partial','paid'])
            ])
        total_inv_amount = 0
        for move in move_ids:
            total_inv_amount += move.amount_total_signed
            move_dict = {
                'invoice_date': move.invoice_date.strftime('%Y-%m-%d') if move.invoice_date else '',
                'name': move.name,
                'origin' : move.invoice_origin if move.invoice_origin else '',
                'journal' : move.journal_id.name,
                'customer': move.partner_id.name,
                'amount' : move.amount_total_signed,
                'status' : dict(move._fields['state'].selection).get(move.state, '')
            }
            invoices.append(move_dict)
        res['invoices'] = invoices
        res['invoices_total'] = round(total_inv_amount,2)
        return res
