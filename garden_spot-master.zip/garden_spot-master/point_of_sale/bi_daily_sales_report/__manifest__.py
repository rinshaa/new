{
    "name": "Daily Sales Report",
    "summary": """
        Daily Sales Report.""",
    "description": """
        Daily Sales Report.
    """,
    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "support": "sales@bassaminfotech.com",
    "license": "OPL-1",
    "category": "Point of Sale",
    'version': '17.1',
    'depends': ['base', 'point_of_sale'],
    "data": [
        "report/report_salesdetails.xml",
    ],
    "installable": True,
    "application": False,
}
