from odoo import fields,models

class ProductTemplate(models.Model):
    _inherit = 'loyalty.reward'

    is_loyalty_point = fields.Boolean(string="Is Loyalty Points")