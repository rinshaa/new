from odoo import models


class PosSession(models.Model):
    _inherit = 'pos.session'

    """ load pos session"""
    def _loader_params_loyalty_reward(self):
        vals = super()._loader_params_loyalty_reward()
        vals['search_params']['fields'].extend(['is_loyalty_point'])
        return vals
