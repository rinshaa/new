// /** @odoo-module **/

import { Component } from "@odoo/owl";
import { ProductScreen } from "@point_of_sale/app/screens/product_screen/product_screen";
import { useService } from "@web/core/utils/hooks";
import { TextInputPopup } from "@point_of_sale/app/utils/input_popups/text_input_popup";
import { usePos } from "@point_of_sale/app/store/pos_hook";
import { _t } from "@web/core/l10n/translation";
import { ErrorPopup } from "@point_of_sale/app/errors/popups/error_popup";


export class LoyaltyButton extends Component{
static template = "bi_loyalty.LoyaltyButton";
    
    setup() {
        this.pos = usePos();
        this.popup = useService("popup");
        this.orm = useService("orm");
    
    }
    async onClick(){
        const { confirmed, payload } = await this.popup.add(TextInputPopup, {
            title: _t('Loyalty Points'),
            isInputSelected: true
        });
        if (confirmed) {
            const loyalty_id = parseInt(payload, 10);
            const currentOrder = this.pos.get_order();
            const loyality_program = currentOrder.getLoyaltyPoints();

            currentOrder.loyality_pro = loyalty_id;  
            currentOrder.is_loyalty = true;
            const rewards = currentOrder.pos.rewards
            const coupon_id_value = parseInt(loyality_program[0].couponId,10)
            const record = currentOrder.partner.id;

            //to get current Date
            let currentDate = new Date();
            let year = currentDate.getFullYear();
            let month = currentDate.getMonth() + 1; // Months are zero-based, so add 1
            let day = currentDate.getDate();
            let month_value =month.toString().padStart(2, '0');
            let day_value = day.toString().padStart(2, '0');

            let startOfDayFormatted = `${year}-${month_value}-${day_value} 00:00:00`
            let endOfDayFormatted = `${year}-${month_value}-${day_value} 23:59:59`;
            
            const order_lines = await this.orm.searchRead('pos.order.line',[["order_id.partner_id", "=", currentOrder.partner.id],['create_date', '<=', endOfDayFormatted],['create_date', '>=', startOfDayFormatted]]);
            if(order_lines){
                var points_spent = 0
                for(const line of order_lines){
                     
                    const reward = await this.orm.searchRead('loyalty.reward',[["id", "=", line.reward_id[0]],['is_loyalty_point', '=', true]]);
                    if(reward)
                        {
                            var points =line.points_cost
                            points_spent += points
                        }
                }
            }
            var total_points = 0
            total_points = points_spent+currentOrder.loyality_pro
            console.log("total_points",total_points)
            if(total_points>300){
                currentOrder.is_limit_exceed = true;
                this.popup.add(ErrorPopup, {
                    title: _t("Limit Exceeded!!"),
                    body: _t("Limit exceeded for Today!!"),
                });
            }
            else{
                currentOrder.is_limit_exceed = false;
            }
            if(loyality_program.length > 0 && ! currentOrder.is_limit_exceed){
                console.log("%%%%%%%%%%%%%%%%%%%%%%%%%%",loyality_program[0].points.total)
                let loyalty_points =loyality_program[0].points.total
                if(loyalty_points>=100){
                    if (loyalty_points < loyalty_id) {
                        currentOrder.is_limit_exceed = true;
                        this.popup.add(ErrorPopup, {
                            title: _t("Points Exceeded!!"),
                            body: _t("Limit exceeded for loyalty point"),
                        });
                    }
                    else{
                        currentOrder.is_limit_exceed = false;
                    }
                }
            }
            

            // apply loyalty points based on reward
            for(const reward of rewards){
                if (reward && !currentOrder.is_limit_exceed){
                    if(reward.is_loyalty_point === true){
                        console.log("JJJJJJJJJJJJJJJJJJJJJJJJ")
                        return currentOrder._applyReward(
                                reward,
                                coupon_id_value
                            );
                        }

                }
            }
            return false;    
        } 
    }

    //enable 'Loyalty Point' button if points greater than 100
    // hasenoughPoints() {
    //     const currentOrder = this.pos.get_order();
    //     const loyality_program = currentOrder.getLoyaltyPoints();
    //     if(loyality_program.length > 0){
    //         return loyality_program[0].points.won > 100;
    //     }
    // }
}

ProductScreen.addControlButton({
    component: LoyaltyButton,
    condition: function () {
        return true;
},
});
