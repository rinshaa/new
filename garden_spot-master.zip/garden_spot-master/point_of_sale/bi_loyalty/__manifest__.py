{
    'name': " Pos Loyalty Point Reward",
    'depends': ['base', 'point_of_sale','pos_loyalty'],
    "summary": """ Pos Loyalty Point""",
    "description": """Pos Loyalty Point""",
    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "support": "sales@bassaminfotech.com",
    "license": "OPL-1",
    "category": "",
    "version": "17.0.0.1",
    'data': [
        'views/loyalty_reward.xml'
       
    ],
    'assets': {
        'point_of_sale._assets_pos': [
            'bi_loyalty/static/src/xml/Loyalty.xml',
            'bi_loyalty/static/src/js/loyalty.js',
            'bi_loyalty/static/src/js/loyalty_pro.js',
        ],
    },
}
