from odoo import api, fields, models


class PosOrder(models.Model):
    _inherit = 'pos.order.line'

    discount_amount = fields.Integer(string="Discount Amount", 
        compute='_compute_discount_amount' )
    
    @api.depends('discount')
    def _compute_discount_amount(self):
        discount_amount = 0.00
        for record in self:
            price = record.price_unit * record.qty
            discount_amount = (price * record.discount) / 100
            record.discount_amount = discount_amount
    

