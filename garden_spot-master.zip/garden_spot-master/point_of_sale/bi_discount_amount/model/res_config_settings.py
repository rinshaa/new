
from odoo import api, fields, models

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    pos_discount_restriction = fields.Boolean(related='pos_config_id.discount_restriction', readonly=False)
    pos_pwd_discount_restriction = fields.Char(related='pos_config_id.pwd_discount_restriction', readonly=False)
    