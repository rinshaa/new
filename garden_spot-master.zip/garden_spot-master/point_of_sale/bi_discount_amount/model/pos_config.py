from odoo import fields, models


class PosConfig(models.Model):
    _inherit = 'pos.config'

    discount_restriction = fields.Boolean(string="Discount Restriction")
    pwd_discount_restriction = fields.Char(string="Password For Discount Restriction")
    

