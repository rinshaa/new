{
    'name': " Pos Discount Amount",
    'version': '17.0.0.3',
    'depends': ['base', 'point_of_sale'],
    "summary": """ Pos Discount Amount""",
    "description": """Pos Discount Amount""",
    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "support": "sales@bassaminfotech.com",
    "license": "OPL-1",
    "category": "",
    "version": "17.0.0.1",
    'data': [
        'views/pos_order.xml',
        'views/res_config_settings.xml'
    ],
    'assets': {
        'point_of_sale._assets_pos': [
            'bi_discount_amount/static/src/xml/DiscountAmount.xml',
            'bi_discount_amount/static/src/js/DiscountAmount.js',
        ],
    },
}
