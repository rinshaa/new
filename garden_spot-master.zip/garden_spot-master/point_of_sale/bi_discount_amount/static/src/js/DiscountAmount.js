/** @odoo-module **/

import { _t } from "@web/core/l10n/translation";
import { ProductScreen } from "@point_of_sale/app/screens/product_screen/product_screen";
import { useService } from "@web/core/utils/hooks";
import { TextInputPopup } from "@point_of_sale/app/utils/input_popups/text_input_popup";
import { Component } from "@odoo/owl";
import { usePos } from "@point_of_sale/app/store/pos_hook";
import { ErrorPopup } from "@point_of_sale/app/errors/popups/error_popup";
import { PasswordInputPopup } from "@bi_pos_password_popup/app/utils/PasswordInputPopup";


export class DiscountAmountButton extends Component {
    static template = "bi_discount_amount.DiscountAmountButton";

    setup() {
        this.pos = usePos();
        this.popup = useService("popup");
    }
    async onClick() {
        var self = this;
        if ((this.pos.config.discount_restriction)){
            const title = _t('Please enter the password for apply discount');
            const passwordEntered = await this.show_password_prompt_one(title);
            if (!passwordEntered) {
                return; // Do not apply discount
            } 
        }
        const { confirmed, payload } = await this.popup.add(TextInputPopup, {
            title: _t('Discount Amount'),
            isInputSelected: true
        });
        if (confirmed) {
            var disc_amount = payload
            const selectedOrderline = this.pos.get_order().get_selected_orderline();
            if (selectedOrderline && disc_amount > 0){
                this.qty_c = selectedOrderline.price * selectedOrderline.quantity
                this.disc_val = disc_amount/this.qty_c
                this.dis_pt = this.disc_val*100
                if(disc_amount > this.qty_c){
                    await this.popup.add(ErrorPopup, {
                        title: _t('Discount Amount'),
                        body: 'Please enter a discount less than the total price of the product.',
                    });
                }else{
                    selectedOrderline.discount_amount = disc_amount
                    selectedOrderline.discount = this.dis_pt.toFixed(2)
                    selectedOrderline.discountStr = this.dis_pt.toFixed(2).toString()
                }
            }                       
        }
    }
    async show_password_prompt_one(title) {
        let try_count = 1;
        let validPasswordEntered = false;
        while (try_count <= 3 && !validPasswordEntered) {
            const { confirmed, payload } = await this.popup.add(PasswordInputPopup, {
                title: title,
            });

            if (confirmed) {
                const pwd_discount_restriction = await this.pos.config.pwd_discount_restriction;
                if (payload && payload === pwd_discount_restriction) {
                    validPasswordEntered = true;
                } else {
                    try_count += 1;
                    title = "Incorrect password provided, please try again";
                }
            } else {
                break; // Cancel button was pressed or popup closed
            }
        }
        return validPasswordEntered;
    }
}
ProductScreen.addControlButton({
component: DiscountAmountButton,
condition: function () {
    return true;
},
});
