{
    'name': " Pos Product Stock Check",
    "version": "17.0.0.0",
    "summary": """ Pos Product Stock Check """,
    "description": """Pos Product Stock Check""",
    "license": "OPL-1",
    "author": "Bassam Infotech LLP",
    "company": "Bassam Infotech LLP",
    "maintainer": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    'depends': ['point_of_sale'], 
    'data': [
    ],
    'assets': {
        'point_of_sale._assets_pos': [
            'bi_pos_stock_check/static/src/js/pos_store.js',
            'bi_pos_stock_check/static/src/js/ProductScreen.js',
        ],
    },

}
