from odoo import models, fields


class POSConfig(models.Model):
    _inherit = 'pos.config'

    default_src_location_id = fields.Many2one(related='picking_type_id.default_location_src_id')