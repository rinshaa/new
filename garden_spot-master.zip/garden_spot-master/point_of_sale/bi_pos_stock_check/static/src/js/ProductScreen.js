/** @odoo-module **/

import { _t } from "@web/core/l10n/translation";
import { ProductScreen } from "@point_of_sale/app/screens/product_screen/product_screen";
import { patch } from "@web/core/utils/patch";
import { ErrorPopup } from "@point_of_sale/app/errors/popups/error_popup";

patch(ProductScreen.prototype, {
    async _setValue(val) {
        const { numpadMode } = this.pos;
        const selectedLine = this.currentOrder.get_selected_orderline();
        if (!selectedLine || numpadMode !== "quantity" || val === "remove") {
            super._setValue(val);
            return;
        }
        let result = await this.orm.searchRead('stock.quant', [
            ['product_id','=', selectedLine.product.id],['location_id','=', this.pos.config.default_src_location_id[0]]
        ],
        ['quantity','reserved_quantity'])
        if(result){
            let total_qty = 0
            let total_reserved_qty = 0
            result.forEach(line => {
                total_qty += line.quantity
                total_reserved_qty += line.reserved_quantity
            });
            if(total_qty - val < 0 || total_qty - total_reserved_qty - val  < 0){
                await this.popup.add(ErrorPopup, {
                    title: _t('No stock available!'),
                    body: `There is currently no ${val} quantity of this product in ${this.pos.config.default_src_location_id[1]}. 
                            Only ${total_qty - total_reserved_qty} available`,
                });
            }else{
                super._setValue(val);
            }
        }else{
            super._setValue(val);
        }
    }
});
