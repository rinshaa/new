/** @odoo-module */
import { patch } from "@web/core/utils/patch";
import { PosStore } from "@point_of_sale/app/store/pos_store";
import { ErrorPopup } from "@point_of_sale/app/errors/popups/error_popup";
import { _t } from "@web/core/l10n/translation";

patch(PosStore.prototype, {
    async addProductToCurrentOrder(product, options = {}) {
        let result = await this.orm.searchRead('stock.quant', [
            ['product_id','=', product.id],['location_id','=', this.config.default_src_location_id[0]]
        ],
        ['quantity','reserved_quantity'])
        if (result.length === 0){
            await this.popup.add(ErrorPopup, {
                title: _t('Product not found!'),
                body: `There is currently no stock of this product in ${this.config.default_src_location_id[1]}.`,
            });
        }
        else if(result){
            let total_qty = 0
            let total_reserved_qty = 0
            result.forEach(line => {
                total_qty += line.quantity
                total_reserved_qty += line.reserved_quantity
            });
            if(total_qty <= 0 || total_qty - total_reserved_qty <= 0){
                await this.popup.add(ErrorPopup, {
                    title: _t('No stock available!'),
                    body: `There is currently no stock of this product in ${this.config.default_src_location_id[1]}.`,
                });
            }else{
                super.addProductToCurrentOrder(...arguments)
            }
        }
    }
});