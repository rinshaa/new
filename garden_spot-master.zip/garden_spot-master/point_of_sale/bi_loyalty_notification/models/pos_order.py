from odoo import api, fields, models, tools


class PosOrder(models.Model):
    _inherit = 'pos.order'

    def confirm_coupon_programs(self, coupon_data):
        """
        This method notifies customers of their loyalty points.
        """
        res = super().confirm_coupon_programs(coupon_data)
        mail_template_id = self.env.ref("bi_loyalty_notification.mail_template_loyalty_points_loyalty_card")
        for coupon, points in coupon_data.items():
            coupon_id = self.env['loyalty.card'].search(
                [('program_id.program_type', '=', 'loyalty'), ('id', '=', points.get('coupon_id'))])
            coupon_id.last_addon_point = points.get('points')
            coupon_id.last_addon_order_ref = self.name
            if coupon_id and coupon_id.partner_id.mobile:
                mail_template_id.send_mail(res_id=coupon_id.id, force_send=True,
                                           email_layout_xmlid='mail.mail_notification_light'
                                           )
                whatsapp_message = coupon_id.send_wa_message()
                sms = coupon_id.send_sms()
        return res
