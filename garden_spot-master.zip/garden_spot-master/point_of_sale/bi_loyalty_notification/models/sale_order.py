from odoo import api, fields, models, tools


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    def _add_points_for_coupon(self, coupon_points):
        """
        This method stores the last addon point in the Loyalty card
        """
        res = super()._add_points_for_coupon(coupon_points)
        for coupon, points in coupon_points.items():
            if coupon.program_id.program_type == 'loyalty':
                coupon.last_addon_point = points
                coupon.last_addon_order_ref = self.name
        return res

    def action_confirm(self):
        """
        This method notifies customers of their loyalty points.
        """
        res = super().action_confirm()
        mail_template_id = self.env.ref("bi_loyalty_notification.mail_template_loyalty_points_loyalty_card")
        for coupon in self.coupon_point_ids:
            if coupon.coupon_id.program_id.program_type == 'loyalty':
                if coupon.coupon_id.partner_id.mobile:
                    mail_template_id.send_mail(res_id=coupon.coupon_id.id, force_send=True,
                                               email_layout_xmlid='mail.mail_notification_light'
                                               )
                    whatsapp_message = coupon.coupon_id.send_wa_message()
                    sms = coupon.coupon_id.send_sms()
        return res
