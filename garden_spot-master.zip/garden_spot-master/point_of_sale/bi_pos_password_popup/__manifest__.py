{
    'name': "POS Popup for Password Input",
    'version': '17.0.0.0',
    "summary": """ POS Popup for Password Input""",
    "description": """Popup defined for inputing password wherever required inside POS. Import and call the PasswordInputPopup for usage.""",
    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "support": "sales@bassaminfotech.com",
    "license": "OPL-1",
    "category": "Point Of Sale",
    'depends': ['base', 'point_of_sale'],
    'data': [],
    'assets': {
        'point_of_sale._assets_pos': [
            'bi_pos_password_popup/static/src/app/utils/PasswordInputPopup.xml',
            'bi_pos_password_popup/static/src/app/utils/PasswordInputPopup.js',
        ],
    },
}
