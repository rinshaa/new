from odoo import fields, models


class ResPartner(models.Model):
    _inherit = 'res.partner'

    provide_qr_in_pos = fields.Boolean('Print QR',default=True)