from . import pos_session
from . import res_partner
from . import pos_config
from . import res_config_settings