from odoo import api, fields, models

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    pos_is_show_invoice = fields.Boolean(related='pos_config_id.is_show_invoice', readonly=False)