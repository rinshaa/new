from odoo import models


class PosSession(models.Model):
    _inherit = 'pos.session'


    def _loader_params_res_company(self):
        res = super(PosSession,self)._loader_params_res_company()
        res['search_params']['fields'] += ('street','street2','country_code','mobile','city','zip')
        return res

    def _loader_params_res_partner(self):
        res = super(PosSession,self)._loader_params_res_partner()
        res['search_params']['fields'].append('provide_qr_in_pos')
        return res
    
    def _loader_params_product_product(self):
        result = super()._loader_params_product_product()
        result["search_params"]["fields"].append("arabic_name")
        return result