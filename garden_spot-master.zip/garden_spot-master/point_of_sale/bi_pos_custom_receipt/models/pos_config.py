from odoo import models, fields


class PosSession(models.Model):
    _inherit = 'pos.config'


    branch_address = fields.Char('Branch Address')
    branch_phone = fields.Char('Branch Phone')
    is_show_invoice = fields.Boolean('Hide Invoice inside POS')