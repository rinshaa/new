/** @odoo-module */

import { Order, Orderline } from "@point_of_sale/app/store/models";
import { patch } from "@web/core/utils/patch";

patch(Order.prototype, {
    export_for_printing() {
        const result = super.export_for_printing(...arguments);
        if(this.partner && !this.partner.provide_qr_in_pos){
            result.headerData.qr_code = ''
        }
        result.partner = this.partner ? this.partner.name : ''
        result.partner_vat = this.partner ? this.partner.vat : ''
        result.headerData['branch_address'] = this.pos.config.branch_address
        result.headerData['branch_phone'] = this.pos.config.branch_phone

        
        /// Removes Currency Symbol from Orderlines ///
        let currencySymbol = this.pos.currency.symbol
        if(currencySymbol){
            result.orderlines.forEach(e => {
                e.price = e.price.includes(currencySymbol) ? e.price.replace(currencySymbol, '') : e.price
                e.unitPrice = e.unitPrice.includes(currencySymbol) ? e.unitPrice.replace(currencySymbol, '') : e.unitPrice
            });
        }
        return result;
    },
    
});

patch(Orderline.prototype, {
    getDisplayData() {
        return {
            ...super.getDisplayData(),
            arabic_name: this.get_product().arabic_name,
            
        };
    },
});