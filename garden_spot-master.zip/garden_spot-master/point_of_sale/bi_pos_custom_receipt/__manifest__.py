{
    'name': " Custom Pos Receipt Printout",
    'depends': ['base', 'point_of_sale','l10n_gcc_pos','l10n_sa_pos'],
    "version": "17.0.2.0.1",
    "summary": """ Pos Receipt Printout""",
    "description": """Pos Receipt Printout""",
    "author": "Bassam Infotech LLP",
    "company": "Bassam Infotech LLP",
    "maintainer": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    'data': [
        'views/res_partner.xml',
        'views/pos_config.xml',
        'views/res_config_settings.xml'
    ],
    "license": "OPL-1",
    'assets': {
        'point_of_sale._assets_pos': [
            'bi_pos_custom_receipt/static/src/xml/custom_pos_receipt.xml',
            'bi_pos_custom_receipt/static/src/xml/receipt_header.xml',
            'bi_pos_custom_receipt/static/src/xml/payment_screen.xml',
            'bi_pos_custom_receipt/static/src/js/models.js',
            'bi_pos_custom_receipt/static/src/css/pos.css'
        ],
    },

}
