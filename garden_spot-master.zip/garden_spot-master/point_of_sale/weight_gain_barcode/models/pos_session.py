from odoo import models

class PosSession(models.Model):
    _inherit = "pos.session"



    def _loader_params_product_product(self):
        result = super()._loader_params_product_product()
        result["search_params"]["fields"].append("gw_barcode")
        return result


    def find_product_by_barcode(self, barcode):
        sp_barcode= barcode[0:7]
        product = self.env['product.product'].search([
            ('gw_barcode', '=', sp_barcode)
        ],limit=1)
        if product:
            return {'product_id': [product.id]}
        product = self.env['product.product'].search([
            ('barcode', '=', barcode),
            ('sale_ok', '=', True),
            ('available_in_pos', '=', True),
        ])
        if product:
            return {'product_id': [product.id]}

        packaging_params = self._loader_params_product_packaging()
        packaging_params['search_params']['domain'] = [['barcode', '=', barcode]]
        packaging = self.env['product.packaging'].search_read(**packaging_params['search_params'])
        if packaging:
            product_id = packaging[0]['product_id']
            if product_id:
                return {'product_id': [product_id[0]], 'packaging': packaging}
        return {}
