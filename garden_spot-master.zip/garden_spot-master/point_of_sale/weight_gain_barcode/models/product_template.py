from odoo import fields,models


class ProductTemplate(models.Model):
    _inherit = "product.template"

    gw_barcode = fields.Char(string="Weigh Scale Barcode")
