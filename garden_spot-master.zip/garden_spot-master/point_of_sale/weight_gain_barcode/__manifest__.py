{
    "name": "Weight Gain Barcode",
    "description": """
        This module is used for set weight gain barcode setup and set the quatitiy
    """,
    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "support": "sales@bassaminfotech.com",
    "license": "OPL-1",
    "category": "",
    "version": "17.0.3.0",
    "depends": ["base","stock","point_of_sale"],
    "data": [
        'views/product_template.xml',
    ],
     'assets': {
        'point_of_sale._assets_pos': [
            "weight_gain_barcode/static/src/js/barcode_weight.js",
            "weight_gain_barcode/static/src/js/db_patching.js",
        ],
    },
}
