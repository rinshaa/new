{
    "name": "set_default",
    "summary": """
       Set Default Product Type""",
    "description": """
        Set Default Product Type
    """,
    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "support": "sales@bassaminfotech.com",
    "license": "OPL-1",
    "category": "Uncategorized",
    "version": "17.0.0.0",
    "depends": ["base","sale", "product"],
    "data": [
        "views/set_default.xml"
    ],
}