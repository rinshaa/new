{
    "name": "Product Template",
    "summary": """
       Customisation In Product Template
    """,
    "description": """
       Customisation In Product Template
    """,
    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "support": "sales@bassaminfotech.com",
    "license": "OPL-1",
    "category": "Inventory",
    "version": "17.0.3.0.1",
    "depends": ["product"],
    "data": [
        "views/product_template.xml",
    ],
}
