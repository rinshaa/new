{
    "name": "Auto lot generation",
    "summary": """
       Auto lot generation""",
    "description": """
        Auto lot generation
    """,
    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "support": "sales@bassaminfotech.com",
    "license": "OPL-1",
    "category": "Uncategorized",
    "version": "17.0.7.0",
    "depends": ["base", "stock", "product", "purchase"],
    "data": [
        'views/ir_sequence.xml'
    ],
}
