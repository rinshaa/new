from odoo import fields,models
import random


class StockPicking(models.Model):
    _inherit='stock.picking'

    def button_validate(self):
        for each in self.move_line_ids:
            if each.product_id.tracking == 'lot' and not each.lot_name:
                each.lot_name= self.env["ir.sequence"].next_by_code("product.lot.new")        
        return super(StockPicking, self).button_validate()

    