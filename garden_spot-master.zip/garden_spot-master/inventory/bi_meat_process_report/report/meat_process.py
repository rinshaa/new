from odoo import models

class UtilityExpenses(models.AbstractModel):
    _name = "report.bi_meat_process_report.action_meat_process_xlsx"
    _inherit = "report.report_xlsx.abstract"
    _description = "Meat Process Report"
    
    def generate_xlsx_report(self, workbook, data, lines):
        product = lines.product_id
        lot = lines.lot_id
        
        format_head = workbook.add_format({
            'align': 'center',
            'bold': 1,
            'bg_color': '#f1c40f',
            'border': 1,
        })
        format1 = workbook.add_format({
            'align': 'left',
        })
        format2 = workbook.add_format({
            'align': 'right',
        })
        format4 = workbook.add_format({
            'align': 'center',
        })
        format3 = workbook.add_format({
            'bold': 1,
            'align': 'center',
            'bg_color': '#ecf0f1',
            'border': 1,

        })
        format5 = workbook.add_format({
            'bold': 1,
            'align': 'right',

        })
        format6 = workbook.add_format({
            'bold': 1,
            'align': 'center',

        })

        
        sheet = workbook.add_worksheet('Meat Processing Report')
        sheet.set_column("A:A", 8)
        sheet.set_column("B:B", 25)
        sheet.set_column("C:C", 30)
        sheet.set_column("D:D", 20)
        sheet.set_column("E:E", 20)
        sheet.set_column("F:F", 30)
        sheet.set_column("G:G", 20)
        sheet.set_column("H:H", 20)
        sheet.set_column("I:I", 20)
        sheet.set_column("J:J", 20)
        sheet.set_row(0, 35)
        sheet.set_row(1,20)
        # if start_date:
        #     sheet.merge_range("A1:I1", f"Meat Processing Report {start_date} To {end_date}",format_head)
        # else:
        sheet.merge_range("A1:J1", f"Meat Processing Report",format_head) 
        sheet.write("A2", 'SlNo', format3)
        sheet.write("B2", 'Meat Processing No', format3)
        sheet.write("C2", 'Date', format3)
        sheet.write("D2", 'Product', format3)
        sheet.write("E2", 'Quantity', format3)
        sheet.write("F2", 'Total cost', format3)
        sheet.write("G2", 'Product', format3)
        sheet.write("H2", 'Quantity', format3)
        sheet.write("I2", 'Unit cost', format3)
        sheet.write("J2", 'Total cost', format3)
        
        row_vals = 3
        
        meat_domain = []
        if product:
            meat_domain.append(('product_id', '=', product.id))
        if lot:
            meat_domain.append(('lot_id', "=", lot.id))
 
        meat_domain.append(('state', '=', 'done'))
        meat_process = self.env['kit.assembly'].search(meat_domain)
        sl_no = 1
        quant = 0
        for record in meat_process:
            entry = self.env['stock.move'].search([('product_id','=',record.product_id.id),('assembly_id','=',record.id)])
            sheet.write("A%s" % row_vals, sl_no if sl_no else "", format4)
            sheet.write("B%s" % row_vals, record.name if record.name else "", format1)
            sheet.write("C%s" % row_vals, str(record.date) if record.date else "", format1)
            sheet.write("D%s" % row_vals, record.product_id.display_name if record.product_id.display_name else "", format1)
            sheet.write("E%s" % row_vals, record.quantity if record.quantity else "", format2)
            quant += record.quantity
            if entry.account_move_ids:
                total = entry.account_move_ids.amount_total_signed
                sheet.write("F%s" % row_vals, total if total else "", format2)
            if record.kit_line_ids:
                total_quantity =0
                product_total =0
                total=0
                for line in record.kit_line_ids:
                    line_entry = self.env['stock.move'].search([('product_id','=',line.product_id.id),('assembly_id','=',record.id)])
                    if line_entry.account_move_ids:
                        total = line_entry.account_move_ids.amount_total_signed
                        sheet.write("J%s" % row_vals, total if total else "", format2)
                    sheet.write("G%s" % row_vals, line.product_id.display_name if line.product_id.display_name else "", format1)
                    sheet.write("H%s" % row_vals, line.line_quantity if line.line_quantity else "", format2)
                    product_total += total
                    total_quantity += line.line_quantity
                    unit_cost = round(product_total/total_quantity,2)
                    sheet.write("I%s" % row_vals, unit_cost if unit_cost else "", format2)
                    row_vals += 1
                sheet.write("D%s" % row_vals,"Total",format6)
                sheet.write("E%s" % row_vals, record.quantity if record.quantity else "", format5)
                sheet.write("H%s" % row_vals, total_quantity if total_quantity else "", format5)
                sheet.write("J%s" % row_vals, round(product_total) if product_total else "", format5)
                row_vals += 1
            if record.wastage_line_ids:
                sheet.write("G%s" % row_vals,"Wastage Product",format6)
                sheet.write("H%s" % row_vals,sum(record.wastage_line_ids.mapped('line_quantity')) if sum(record.wastage_line_ids.mapped('line_quantity')) else "", format5) 
                each_entry = 0
                row_vals += 1
                waste_total = 0
                waste_quantity=0
                for each in record.wastage_line_ids:
                    each_entry = self.env['stock.move'].search([('product_id','=',each.product_id.id),('assembly_id','=',record.id)])
                    if each_entry.account_move_ids:
                        sheet.write("G%s" % row_vals, each.product_id.display_name if each.product_id.display_name else "", format1)
                        sheet.write("H%s" % row_vals, each.line_quantity if each.line_quantity else "", format2)
                        waste_quantity += each.line_quantity
                        total = each_entry.account_move_ids.amount_total_signed
                        sheet.write("J%s" % row_vals, total if total else "", format2)
                        waste_total += total 
                        row_vals += 1
                # sheet.write("C%s" % row_vals,"Total",format6)
                sheet.write("H%s" % row_vals, waste_quantity if waste_quantity else "", format5)
                sheet.write("J%s" % row_vals, round(waste_total) if waste_total else "", format5)
                    
                row_vals += 1
                
                sl_no += 1
            row_vals += 1
        sheet.write("D%s" % row_vals,"Total",format6)
        sheet.write("E%s" % row_vals, quant if quant else "", format5)
        row_vals += 1
        sheet.write("D%s" % row_vals,"Remaining Quantity",format6)
        sheet.write("E%s" % row_vals, record.available_quantity if record.available_quantity else "", format5)
        row_vals += 1



            
                
           