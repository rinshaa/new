{
    "name": "Meat_Process_Excel_Report",
    "description": """
        This module is used for Meat process excel report
    """,
    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "support": "sales@bassaminfotech.com",
    "license": "OPL-1",
    "category": "",
    "version": "17.0.0.1",
    "depends": ["bi_kit_assembly","report_xlsx"],
    "data": [
        'security/ir.model.access.csv',
        'report/report.xml',
        'wizard/meat_process_wiz.xml',
          
    ],
}