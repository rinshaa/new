from odoo import models, fields

class MeatProcessWiz(models.TransientModel):
    _name = "meat.process.wiz"
    _description = "Meat Process Wiz"
    
    # start_date = fields.Date(string="Start Date")
    # end_date = fields.Date(string="End Date")
    product_id = fields.Many2one('product.product',string="Product")
    lot_id = fields.Many2one('stock.lot', domain="[('product_id', '=', product_id)]")
    
    def action_print(self):
        data={
            'ids':self.ids,
            'model':self._name,
            'form':{ 'product_id':self.product_id,
                    'lot_id':self.lot_id,
                    }
                    
                    }
      
        return self.env.ref('bi_meat_process_report.action_meat_process_report').report_action(self,data=data)
