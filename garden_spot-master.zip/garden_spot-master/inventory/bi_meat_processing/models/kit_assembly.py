from odoo import models, fields, api, _
from datetime import date
from calendar import monthrange
from odoo.exceptions import UserError
import datetime


class KitAssembly(models.Model):
    _inherit = "kit.assembly"
  
    current_processing_no = fields.Integer(string='Currect Processing')
    remaining_processing_no = fields.Integer(string="Remaining Processing")
    last_date = fields.Date(string="Last Date")

    @api.onchange('lot_id')
    def _onchange_product_processing(self):
        for record in self:
            if record.lot_id:
                cutting_no = self.env['ir.config_parameter'].sudo().get_param('bi_kit_assembly.process_number')
                cutting_procces_no = int(cutting_no)
                existing_record = self.env['kit.assembly'].search([('product_id', '=', record.product_id.id),
                                                                ('lot_id', '=', record.lot_id.id),('state', '=', 'done')])
                if(record.lot_id.purchase_date):
                    lot_month = record.lot_id.purchase_date.month
                    lot_year = record.lot_id.purchase_date.year
                    last_day = monthrange(lot_year,lot_month)[1]
                    last_date = date(lot_year,lot_month,last_day)
                    record.last_date = last_date
                len_of_record = len(existing_record)
                if len_of_record < cutting_procces_no:
                    if len_of_record:
                        record.current_processing_no = len_of_record + 1
                        record.remaining_processing_no =  cutting_procces_no - record.current_processing_no 
                    else:
                         record.current_processing_no = 1
                         record.remaining_processing_no = cutting_procces_no - record.current_processing_no 
                else:
                    False
            else:
                False

    

    @api.constrains('lot_id')
    def _check_lot(self):
        if self.lot_id:
            remaining = self.remaining_processing_no
                # if self.product_id:
                #     if self.lot_id.purchase_date.month != date.today().month:
                #         raise UserError(_("Expired..!"))
            if not remaining and (self.current_processing_no !=0):
                if self.lot_id.product_qty != self.quantity:
                    raise UserError(_("You cannot Processing..! Please use the entire quantity to process...."))
        if self.lot_id.purchase_date:
            if self.lot_id.purchase_date.month != date.today().month:
                raise UserError(_("Expired..!"))
        
 