from odoo import models, fields, api, _
from datetime import date

class StockLoT(models.Model):
    _inherit ='stock.lot'

    purchase_date = fields.Date(string="Purchased Date")


    @api.model_create_multi
    def create(self, vals_list):
        results = super(StockLoT, self).create(vals_list)
        for each in results:
            each.purchase_date = each.create_date.date()
        return results

