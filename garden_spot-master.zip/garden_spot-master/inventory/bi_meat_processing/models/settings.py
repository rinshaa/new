from odoo import models, fields


class ResConfigSettings(models.TransientModel):
   _inherit = 'res.config.settings'
  

   process_number = fields.Integer('Number of Process', config_parameter='bi_kit_assembly.process_number')