{
    "name": "Kit Assembly Customisation",
    "summary": """
       Kit Assembly""",
    "description": """
        Kit Assembly
    """,
    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "support": "sales@bassaminfotech.com",
    "license": "OPL-1",
    "category": "Uncategorized",
    "version": "17.0.0.1",
    "depends": ["base", "stock", "product", "account","mrp","stock_account","bi_kit_assembly"],
    "data": [
        "views/kit_assembly.xml",
        "views/settings_view.xml",
        "views/stock_lot.xml"
       
    ],
}
