{
    "name": "Kit Assembly",
    "summary": """
       Kit Assembly""",
    "description": """
        Kit Assembly
    """,
    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "support": "sales@bassaminfotech.com",
    "license": "OPL-1",
    "category": "Uncategorized",
    "version": "17.0.8.0",
    "depends": ["base", "stock", "product", "account","mrp","stock_account"],
    "data": [
        "security/ir.model.access.csv",
        "security/security.xml",
        "data/sequence.xml",
        "data/group.xml",
        "views/bom.xml",
        "views/product.xml",
        "views/kit_assembly.xml",
        "views/stock_move.xml",
        "views/account_journal.xml",
        "views/config.xml",
        "views/shrink_master.xml",
        "views/mrp_bom.xml"
    ],
}
