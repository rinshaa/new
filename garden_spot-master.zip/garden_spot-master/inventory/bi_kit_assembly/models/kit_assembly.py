from odoo import models, fields, api, _
from datetime import date
from odoo.exceptions import UserError
import datetime


class KitAssembly(models.Model):
    _name = "kit.assembly"
    _description = "Kit Assembly"
    _rec_name = "product_id"


    name = fields.Char(string="Sequence No",readonly=True,required=True,default=lambda self: _('New'))
    product_id = fields.Many2one("product.product", string="Product")
    quantity = fields.Float("Quantity",default=1.00,digits='Product Unit of Measure')
    uom_id = fields.Many2one("uom.uom", string="Unit")
    bom_id = fields.Many2one("mrp.bom", string="Bill Of Material")
    reference = fields.Char("Description")
    lot_id = fields.Many2one("stock.lot",string="Lots")
    total_line_quantity = fields.Float( compute='_compute_total_line_quantity', digits=(16, 3))
    cost_sum = fields.Float(compute='_compute_total_line_quantity', digits=(16, 3))
    wastage_line_quantity = fields.Float( compute='_compute_wastage_line_quantity', digits=(16, 3))
    def _get_default_warehouse_id(self):
        return self.env['stock.warehouse'].search([], limit=1).id
    warehouse_id = fields.Many2one("stock.warehouse", string="Warehouse",default=_get_default_warehouse_id)
    def _get_default_location_id(self):
        return self.env['stock.location'].search([('usage','=','internal')], limit=1).id
    location_id = fields.Many2one("stock.location", string="Location",default=_get_default_location_id)
    company_id = fields.Many2one("res.company", string="Company", default=lambda self: self.env.company.id)
    kit_line_ids = fields.One2many("kit.assembly.lines", "kit_assembly_id")
    date = fields.Date("Date", default=date.today())
    state = fields.Selection(
        [
            ("draft", "Draft"),
            ("approve", "Approve"),
            ("done", "Done"),
        ],
        string="State",

    )
    assembly_count = fields.Integer(string="Moves", compute="_compute_assembly_count")
    journal_count = fields.Integer(string="Entries", compute="_compute_journal_count")
    is_done = fields.Boolean("is_done", default=False, copy=False)
    is_disassembly = fields.Boolean("is_disassembly", default=False, copy=False)
    available_quantity = fields.Float('Available Quantity', compute='_compute_available_quantity',digits='Product Unit of Measure')
    available_quantity_uom_id = fields.Many2one('uom.uom', string='Unit')
    wastage = fields.Float(string="Wastage Qty")
    wastage_line_ids = fields.One2many('wastage.line','assembly_id','Wastage Line')
    arabic_name = fields.Char(related='product_id.product_tmpl_id.arabic_name', string='Arabic Name')
    total_quantity = fields.Float('Total Quantity', compute="_compute_total_quantity", digits=(16, 3))
    lot_ids_binary = fields.Binary(compute="_compute_domain_lot_ids_binary",string="domain lot")
    lot_ids = fields.Many2many('stock.lot',string="Lot ids", compute="_compute_domain_lot_ids_binary")
    tracking = fields.Selection(related="product_id.tracking")


    @api.depends('kit_line_ids.line_quantity','kit_line_ids.unit_cost')
    def _compute_total_line_quantity(self):
        for record in self:
            total_qty = 0.0
            total_cost = 0.0
            for line in record.kit_line_ids:
                total_qty += line.line_quantity
                total_cost += line.unit_cost
            record.total_line_quantity = round(total_qty, 3)
            record.cost_sum = round(total_cost, 3)


    @api.depends('wastage_line_ids.line_quantity')
    def _compute_wastage_line_quantity(self):
        for record in self:
            sum_wastage_qty = 0.0
            for line in record.wastage_line_ids:
                sum_wastage_qty += line.line_quantity
            record.wastage_line_quantity = round(sum_wastage_qty, 3)

    @api.depends('total_line_quantity', 'wastage_line_quantity')
    def _compute_total_quantity(self):
        total_qty = 0.0
        for record in self:
            total_qty = record.total_line_quantity + record.wastage_line_quantity
            record.total_quantity = round(total_qty, 3)


    @api.depends('product_id','location_id','lot_id')
    def _compute_available_quantity(self):
        for rec in self:
            if rec.lot_id:
                rec.available_quantity = rec.lot_id.with_context(
                location=rec.location_id.id
            ).product_qty
            else:
                rec.available_quantity = rec.product_id.with_context(
                    location=rec.location_id.id
                ).qty_available


    # @api.onchange("product_id")
    # def _onchange_product_id_uom(self):
    #     if self.product_id:
    #         if self.product_id.uom_id:
    #             self.uom_id = self.product_id.uom_id.id
    #             self.available_quantity_uom_id = self.product_id.uom_id.id
    is_bom_id = fields.Binary(compute="_compute_is_bom_id")

    @api.depends('product_id')
    def _compute_is_bom_id(self):
        for record in self:
            bom_ids = self.env["mrp.bom"].search([('product_tmpl_id','=',self.product_id.product_tmpl_id.id)]).ids
            self.is_bom_id = "[('id','in',%s)]"%bom_ids


    @api.onchange("product_id")
    def _onchange_product_bom_id(self):
        bom_ids = self.env["mrp.bom"].search([('product_tmpl_id','=',self.product_id.product_tmpl_id.id)])
        lot_id = self.env["stock.lot"].search([('product_id','=',self.product_id.id)])
        wastage_products = self.env['product.product'].search([('is_wastage','=', True)])

        for each in bom_ids:
            self.bom_id = each.id
            break
        self.uom_id=self.product_id.uom_id.id
        if len(lot_id) == 1:
            self.lot_id = lot_id.id

        wastage_list = []
        for each in wastage_products:
            wastage_list.append((0,0,{
                'product_id' :  each.id,
                "line_quantity": 0,
                "line_uom_id": each.uom_id.id,
                "assembly_id": self.id,
            }))
        self.wastage_line_ids = False
        self.sudo().write({
            'wastage_line_ids' : wastage_list
        })
        # self.is_bom_id = [('id','in',bom_ids.ids)]
        # return {'domain':{'bom_id': [('id', 'in', bom_ids.ids)],'lot_id':[('id','in',lot_id.ids)]}}

    @api.onchange("warehouse_id")
    def _onchange_warehouse_id(self):
        if self.warehouse_id:
            self.location_id = self.warehouse_id.lot_stock_id.id

    def unlink(self):
        for each in self:
            if each.state in ["done","approve"]:
                raise UserError(_("You cannot delete approved or done process."))
        return super(KitAssembly, self).unlink()

    def action_approve(self):
        self.state = "approve"

    def assembly_create_account_move(self, assembly_id, assembly_line_id, value):
        move_vals = []
        product_id = assembly_id.product_id
        kit_journal_id = self.env["ir.config_parameter"].sudo().get_param("bi_kit_assembly.journal_id")
        if kit_journal_id:
            kit_journal_id = int(kit_journal_id)
        w_journal_id = self.env['account.journal'].browse(kit_journal_id)
        valuation_account_id = product_id.categ_id.property_stock_valuation_account_id
        production_cost_account_id = product_id.categ_id.property_stock_account_production_cost_id
        move_vals.append({
            'journal_id': w_journal_id.id,
            'date': date.today(),
            'ref': assembly_id.reference or assembly_id.name or 'Miscellaneous',
            'move_type': 'entry',
            'line_ids': [
                (0, 0, {
                    'name': 'Miscellaneous',
                    'account_id': production_cost_account_id.id,
                    'debit': 0.0,
                    'credit': value,
                }),
                (0, 0, {
                    'name': 'Miscellaneous',
                    'account_id': valuation_account_id.id,
                    'debit': value,
                    'credit': 0.0,
                }),
            ],
        })
        account_move = self.env['account.move'].create(move_vals)
        account_move.action_post()
        return account_move

    def action_create_wastage_finished_stock_move(self):
        source_location = self.location_id.id
        config_location_id = self.env['ir.config_parameter'].sudo().get_param('bi_kit_assembly.location_id')
        if not config_location_id:
            raise UserError(_(f"Check Wastage Location"))
        self.env['stock.location'].browse(int(config_location_id))
        production_location = self.env['stock.location'].search([('usage', '=', 'production')], limit=1).id
        total_wastage_qty = sum(self.wastage_line_ids.mapped('line_quantity'))
        finished = {
            'name': f"{self.product_id.name} - {self.name}",
            'product_id': self.product_id.id,
            'product_uom_qty': total_wastage_qty,
            'product_uom': self.uom_id.id,
            'location_id': source_location,
            'location_dest_id': production_location,
            'assembly_id': self.id,
            'state': 'draft',
        }
        if self.is_disassembly:
            finished['origin'] = self.name

        finished_move_id = self.env["stock.move"].sudo().create(finished)
        finished_move_id._action_confirm()
        finished_move_id._action_assign()
        for move_line_id in finished_move_id.move_line_ids:
            move_line_id.write(
                {
                    "quantity": finished_move_id.product_uom_qty,
                    "location_id": source_location,
                    "lot_id": self.lot_id and self.lot_id.id or False,
                }
            )
        # finished_move_id._onchange_move_line_ids()
        finished_move_id.picked = True
        finished_move_id.with_context(
            is_meat=True, kit_id=self.id, is_finished=True, is_finished_wastage_move=True)._action_done()
        return finished_move_id

    def action_done_assembly(self):
        for assembly in self:
            bi_product_id = assembly.product_id
            bi_product_id.qty_available
            total_product_value = assembly.quantity * bi_product_id.standard_price
            # total_product_value = total_available_product_qty * bi_product_id.standard_price
            total_wastage_qty = assembly.wastage_line_ids and \
                                sum(assembly.wastage_line_ids.mapped('line_quantity')) or 0.0
            new_available_qty = assembly.quantity - total_wastage_qty
            new_product_cost = total_product_value / new_available_qty

            # for kit_line in assembly.kit_line_ids:
            #     kit_line.product_id.update({'standard_price':kit_line.unit_cost})
            for line in assembly.kit_line_ids.filtered(lambda rline: rline.line_quantity > 0):
                if line.product_id.tracking == "serial":
                    if line.line_quantity < len(line.mapped("serial_ids")):
                        raise UserError(
                            _(f"You can enter only {line.line_quantity} serial numbers for {line.product_id.name}.")
                        )
                    elif line.line_quantity > len(line.mapped("serial_ids")):
                        raise UserError(_(f"Enter serial number for all {line.line_quantity} {line.product_id.name}."))

                elif line.product_id.tracking == "lot":
                    if line.mapped("serial_ids"):
                        total_lot_capacity = 0
                        for check in line.mapped("serial_ids"):
                            if check.serial_quantity == 0:
                                raise UserError(_("Enter the quantity for all lots."))
                        total_actual_qty = line.line_quantity
                        serial_qty = sum(line.mapped("serial_ids").mapped("serial_quantity"))
                        if total_actual_qty != serial_qty:
                            raise UserError(_(f"Incorrect Quantity for {line.product_id.name}"))
                        for each_lot in line.mapped("serial_ids").mapped("serial_id"):
                            total_lot_capacity += line.product_id.with_context(
                                {
                                    "to_date": datetime.datetime.now(),
                                    "lot_id": each_lot.id,
                                    "location_id": line.kit_assembly_id.location_id.id,
                                }
                            ).qty_available
                        if line.line_quantity > total_lot_capacity:
                            raise UserError(
                                _(
                                    f"Return quantity {line.line_quantity} for {line.product_id.name}"
                                    f" is greater than the available quantity in given lots."
                                )
                            )
                    # else:
                    #     raise UserError(_(f"Enter lot number for all {line.line_quantity} {line.product_id.name}."))

            for line in assembly.kit_line_ids.filtered(lambda rline: rline.line_quantity > 0):
                transfer_name = ""
                picking_type = self.env["stock.picking.type"].search([("code", "=", "mrp_operation")], limit=1).id
                if assembly.is_disassembly:
                    dest_location = assembly.location_id.id
                    from_location = self.env["stock.location"].search([("usage", "=", "production")], limit=1).id
                    transfer_name = f"{line.product_id.name} - {self.name}"
                    template = {
                        "name": transfer_name,
                        "origin":assembly.name,
                        "product_id": line.product_id.id,
                        "product_uom_qty": line.line_quantity,
                        "product_uom": line.line_uom_id.id,
                        "location_id": from_location,
                        "location_dest_id": dest_location,
                        "state": "draft",
                        "assembly_id": assembly.id,
                    }
                else:
                    from_location = assembly.location_id.id
                    dest_location = self.env["stock.location"].search([("usage", "=", "production")], limit=1).id
                    transfer_name = f"{line.product_id.name} - {self.name}"
                    template = {
                        "name": transfer_name,
                        "product_id": line.product_id.id,
                        "product_uom_qty": line.line_quantity,
                        "product_uom": line.line_uom_id.id,
                        "location_id": from_location,
                        "location_dest_id": dest_location,
                        "picking_type_id": picking_type,
                        "state": "draft",
                        "assembly_id": assembly.id,
                    }
                move_id = self.env["stock.move"].sudo().create(template)
                move_id._action_confirm()
                move_id._action_assign()

                for line_moves in move_id.filtered(lambda rline: rline.product_uom_qty > 0):
                    stock_move_line = self.env["stock.move.line"].search([("move_id", "=", move_id.id)])
                    if line_moves.product_id.tracking != "none":
                        if line_moves.product_id.tracking == "serial":
                            serial_ids = line.serial_ids.mapped("serial_id")
                            moveline = stock_move_line.filtered(
                                lambda mv_line: mv_line.product_id == line_moves.product_id
                                and mv_line.move_id == move_id
                                and mv_line.product_id.tracking == "serial"
                            )
                            if moveline:
                                for x in range(0, len(serial_ids)):
                                    moveline[x].lot_id = serial_ids[x]
                                    moveline[x].quantity = 1
                            else:
                                raise UserError(_("Incorrect Values"))
                        elif line_moves.product_id.tracking == "lot":
                            qty = line_moves.product_uom_qty
                            moveline = stock_move_line.filtered(
                                lambda mv_line: mv_line.product_id == line_moves.product_id
                                and mv_line.move_id == move_id
                                and mv_line.product_id.tracking == "lot"
                            )
                            if moveline:
                                for lot in line.serial_ids.mapped("serial_id"):
                                    lot_qty = line.product_id.with_context(
                                        {
                                            "to_date": datetime.datetime.now(),
                                            "lot_id": lot.id,
                                            "location_id": assembly.location_id.id,
                                        }
                                    ).qty_available
                                    if qty > lot_qty:
                                        moveline_qty = lot_qty
                                        qty -= moveline_qty
                                    else:
                                        moveline_qty = qty
                                    if not moveline.lot_id:
                                        moveline.lot_id = lot.id
                                        moveline.quantity = moveline_qty
                                    else:
                                        moveline.copy(
                                            {
                                                "lot_id": lot.id,
                                                "quantity": moveline_qty,
                                            }
                                        )
                            else:
                                raise UserError(_("Incorrect Values"))
                    else:
                        moveline = stock_move_line.filtered(
                            lambda mv_line: mv_line.product_id == line_moves.product_id
                            and mv_line.move_id == move_id
                            and mv_line.product_id.tracking == "none"
                        )
                        moveline.quantity = line_moves.product_uom_qty
                # for rec in move_id.move_line_nosuggest_ids:
                #     rec._onchange_serial_number()
                # move_id._onchange_move_line_ids()
                line.product_id.qty_available
                line.product_id.standard_price
                # total_available_qty = line.product_id.qty_available
                # new_product_line_cost = standard_price if standard_price <= 0 else new_product_cost if \
                #     new_product_cost <= 0 else 0
                # total_product_valuation = total_available_qty * new_product_line_cost
                # line_product_qty = line.line_quantity
                # new_total_product_qty = total_available_qty + line_product_qty
                # new_product_line_valuation = line.line_quantity * new_product_cost
                # new_line_product_price = (total_product_valuation + new_product_line_valuation) / new_total_product_qty
                # line.product_id.with_context(disable_auto_svl=True).standard_price = new_line_product_price

                # Older Code
                # if self.product_id == line.product_id:
                #     new_price = (qty_before*standard_price)+(qty_before*standard_price-self.quantity*standard_price)
                #     price_cost = line.line_quantity+(qty_before-self.quantity)
                #     new_price_cost = new_price/price_cost
                #     line.product_id.with_context(disable_auto_svl=True).standard_price = new_price_cost
                # else:
                #     new_price = (line.line_quantity*line.single_product_cost)+(qty_before*standard_price)
                #     total_qty = (qty_before+line.line_quantity)
                #     if total_qty != 0.0:
                #         new_price = new_price/(qty_before+line.line_quantity)
                #         line.product_id.with_context(disable_auto_svl=True).standard_price = new_price
                ######################### Line Product New Cost Calculation #################################
                # tmp_kpl_standard_price = line.product_id.standard_price
                # tmp_lpt_available_qty = line.product_id.qty_available
                # tmp_new_product_line_cost = tmp_kpl_standard_price if tmp_kpl_standard_price > 0 else new_product_cost if \
                #     new_product_cost > 0 else 0
                # tmp_line_product_qty = line.line_quantity
                # tmp_lpt_qty_bfr_done = tmp_lpt_available_qty if tmp_lpt_available_qty > 0 else 0
                # tmp_total_product_valuation = tmp_lpt_qty_bfr_done * tmp_new_product_line_cost
                # tmp_new_pl_valuation = tmp_line_product_qty * new_product_cost
                # tmp_new_pl_price = (tmp_total_product_valuation + tmp_new_pl_valuation) / \
                #                    (tmp_lpt_available_qty + tmp_line_product_qty)

                tmp_line_product_qty = line.line_quantity
                tmp_line_cost = line.single_product_cost
                tmp_lpt_available_qty = line.product_id.qty_available
                tmp_lpt_standard_price = line.product_id.standard_price

                all_product_total_qty = tmp_lpt_available_qty + tmp_line_product_qty + \
                                        (bi_product_id.qty_available - assembly.quantity)

                line.product_id.standard_price
                # if lp_std_price > 0:
                #     # tmp_new_pl_price = ((total_available_product_qty + tmp_lpt_available_qty) * lp_std_price) / \
                #     #                    all_product_total_qty
                #     # new_product_cost = tmp_new_pl_price
                # else:
                tmp_new_pl_price = new_product_cost
                # product_cost = (tmp_line_product_qty*tmp_line_cost)/(tmp_lpt_available_qty+tmp_line_product_qty)
                (tmp_lpt_available_qty+tmp_line_product_qty)

                if tmp_lpt_available_qty > 0:
                    product_standard_price = ((tmp_line_product_qty*tmp_line_cost)+(tmp_lpt_available_qty*tmp_lpt_standard_price))/(tmp_lpt_available_qty+tmp_line_product_qty)
                else:
                    product_standard_price = (tmp_line_product_qty*tmp_line_cost)/tmp_line_product_qty


                if not line.product_id.is_wastage:
                    line.product_id.with_context(disable_auto_svl=True).standard_price = product_standard_price
                #############################################################################################
                move_id.picked = True
                move_id.with_context(is_meat=True,kit_id=self.id, bi_new_product_price=tmp_new_pl_price,
                                     line_new_product_qty = tmp_line_product_qty)._action_done()
                ################################### Account Journal ##########################################
                # ap_value = bi_product_id.standard_price * assembly.quantity
                # lp_value = tmp_line_product_qty * tmp_new_pl_price
                # misc_acc_mv_cost = ap_value - lp_value
                # account_move_id = self.assembly_create_account_move(assembly, line, misc_acc_mv_cost)

                ##############################################################################################
            ################
            if assembly.wastage_line_ids:
                for line in assembly.wastage_line_ids:
                    transfer_name = ""
                    picking_type = self.env["stock.picking.type"].search([("code", "=", "mrp_operation")], limit=1).id
                    if assembly.is_disassembly:
                        config_location_id = self.env['ir.config_parameter'].sudo().get_param('bi_kit_assembly.location_id')
                        if not config_location_id:
                            raise UserError(_(f"Check Wastage Location"))
                        location_id = self.env['stock.location'].browse(int(config_location_id))
                        dest_location = location_id.id
                        from_location = self.env["stock.location"].search([("usage", "=", "production")], limit=1).id
                        product_id = line.product_id
                        transfer_name = f"{line.product_id.name} - {self.name}"
                        template = {
                            "name": transfer_name,
                            "origin":assembly.name,
                            "product_id": product_id.id,
                            "product_uom_qty": line.line_quantity,
                            "product_uom": product_id.uom_id.id,
                            "location_id": from_location,
                            "location_dest_id": dest_location,
                            "state": "draft",
                            "assembly_id": assembly.id,
                        }
                        move_id = self.env["stock.move"].sudo().create(template)
                        move_id._action_confirm()
                        move_id._action_assign()
                    for line_moves in move_id.filtered(lambda rline: rline.product_uom_qty > 0):
                        stock_move_line = self.env["stock.move.line"].search([("move_id", "=", move_id.id)])
                        moveline = stock_move_line.filtered(
                                    lambda mv_line: mv_line.product_id == line_moves.product_id
                                    and mv_line.move_id == move_id
                                    and mv_line.product_id.tracking == "none"
                                )
                        moveline.quantity = line_moves.product_uom_qty
                    # for rec in move_id.move_line_nosuggest_ids:
                    #     rec._onchange_serial_number()
                    # move_id._onchange_move_line_ids()
                    move_id.picked = True
                    move_id.with_context(is_meat=True,kit_id=self.id,is_wastage=True)._action_done()
                    move_vals = []
                    kit_journal_id = self.env["ir.config_parameter"].sudo().get_param("bi_kit_assembly.journal_id")
                    if kit_journal_id:
                        kit_journal_id = int(kit_journal_id)
                    w_journal_id = self.env['account.journal'].browse(kit_journal_id)
                    out_acc = product_id.categ_id.property_stock_valuation_account_id
                    exp_acc = product_id.categ_id.property_stock_account_output_categ_id
                    master_qty = assembly.quantity
                    master_price = assembly.product_id.standard_price
                    total_cost = master_qty*master_price
                    cost_per_unit = total_cost/master_qty
                    total_wastage_cost = cost_per_unit* line.line_quantity
                    if not product_id.is_wastage:
                        move_vals.append({
                                'journal_id': w_journal_id.id,
                                'date': date.today(),
                                'ref': assembly.reference,
                                'move_type':'entry',
                                'line_ids': [
                                    (0, 0, {
                                        'name': product_id.name,
                                        'account_id': out_acc.id,
                                        'debit': 0.0,
                                        'credit': total_wastage_cost,
                                    }),
                                    (0, 0, {
                                        'name': product_id.name,
                                        'account_id': exp_acc.id,
                                        'debit': total_wastage_cost,
                                        'credit': 0.0,
                                    }),
                                ],
                            })
                        acc = self.env['account.move'].create(move_vals)
                        acc.action_post()
                        move_id.write({'account_move_ids': [(6,0,acc.ids)]})

            if assembly.is_disassembly:
                dest_location = assembly.location_id.id
                from_location = self.env["stock.location"].search([("usage", "=", "production")], limit=1).id
                finished = {
                    "name": f"{assembly.product_id.name} - {self.name}",
                    "origin":assembly.name,
                    "product_id": assembly.product_id.id,
                    "product_uom_qty": assembly.quantity - sum(self.wastage_line_ids.mapped('line_quantity')),
                    "product_uom": assembly.uom_id.id,
                    "location_id": dest_location,
                    "location_dest_id": from_location,
                    # "picking_type_id": picking_type,
                    "assembly_id": assembly.id,
                    "state": "draft",
                }
            else:
                dest_location = assembly.location_id.id
                from_location = self.env["stock.location"].search([("usage", "=", "production")], limit=1).id
                finished = {
                    "name": transfer_name,
                    "product_id": assembly.product_id.id,
                    "product_uom_qty": assembly.quantity - sum(self.wastage_line_ids.mapped('line_quantity')),
                    "product_uom": assembly.uom_id.id,
                    "location_id": dest_location,
                    "location_dest_id": from_location,
                    "assembly_id": assembly.id,
                    "state": "draft",
                }

            assembly.action_create_wastage_finished_stock_move()
            # bi_product_id.with_context(disable_auto_svl=True).standard_price = new_product_cost
            finished_move_id = self.env["stock.move"].sudo().create(finished)
            finished_move_id._action_confirm()
            finished_move_id._action_assign()
            for move_line_id in finished_move_id.move_line_ids:
                move_line_id.write(
                    {
                        "quantity": finished_move_id.product_uom_qty,
                        "location_id": dest_location,
                        "lot_id":assembly.lot_id.id,
                    }
                )
            # finished_move_id._onchange_move_line_ids()
            finished_move_id.picked = True
            finished_move_id.with_context(is_meat=True,kit_id=self.id,is_finished=True,
                                          new_raw_product_cost=new_product_cost, effective_product_qty=
                                          assembly.quantity - sum(self.wastage_line_ids.mapped('line_quantity'))
                                          )._action_done()
            assembly.is_done = True
            assembly.state = "done"

            # cost update on main product
            # bi_product_id = assembly.product_id
            # total_available_product_qty = assembly.available_quantity
            # total_product_value = total_available_product_qty * bi_product_id.standard_price
            # total_wastage_qty = assembly.wastage_line_ids and \
            #                     sum(assembly.wastage_line_ids.mapped('line_quantity')) or 0.0
            # new_available_qty = total_available_product_qty - total_wastage_qty
            # new_product_cost = total_product_value / new_available_qty
            # bi_product_id.with_context(disable_auto_svl=True).standard_price = new_product_cost
            # for kp_line_id in assembly.kit_line_ids.filtered(lambda kit_line_id: kit_line_id.line_quantity > 0):
            #     kpl_standard_price = kp_line_id.product_id.standard_price
            #     lpt_available_qty = kp_line_id.product_id.qty_available
            #     new_product_line_cost = kpl_standard_price if kpl_standard_price > 0 else new_product_cost if \
            #         new_product_cost > 0 else 0
            #     line_product_qty = kp_line_id.line_quantity
            #     lpt_qty_bfr_done = lpt_available_qty - line_product_qty if lpt_available_qty > 0 else 0
            #     total_product_valuation = lpt_qty_bfr_done * new_product_line_cost
            #     new_product_line_valuation = line_product_qty * new_product_cost
            #     new_line_product_price = (total_product_valuation + new_product_line_valuation) / lpt_available_qty
            #     kp_line_id.product_id.with_context(disable_auto_svl=True).standard_price = new_line_product_price

    def _compute_assembly_count(self):
        for rec in self:
            assembly_count = self.env["stock.move"].search_count([("assembly_id", "=", rec.id)])
            rec.assembly_count = assembly_count

    def view_assembly_moves(self):
        assembly_ids = self.env["stock.move"].search([("assembly_id", "=", self.id)])
        if len(assembly_ids) > 0:
            return {
                "name": _("Moves"),
                "type": "ir.actions.act_window",
                "res_model": "stock.move",
                "view_mode": "tree,form",
                "domain": [("id", "in", assembly_ids.ids)],
                "target": "current",
            }

    def _compute_journal_count(self):
        for rec in self:
            journal_count = self.env["account.move"].search_count([("assembly_id", "=", rec.id)])
            rec.journal_count = journal_count

    def view_journal_entry(self):
        journal_ids = self.env["account.move"].search([("assembly_id", "=", self.id)])
        if len(journal_ids) > 0:
            return {
                "name": _("Entries"),
                "type": "ir.actions.act_window",
                "res_model": "account.move",
                "view_mode": "tree,form",
                "domain": [("id", "in", journal_ids.ids)],
                "target": "current",
            }

    @api.model_create_multi
    def create(self, vals):
        res = super(KitAssembly, self).create(vals)
        for rec in res:
            rec.state = "draft"
            master_qty = round(rec.quantity,2)
            sum_line_qty = 0
            sum_of_wastage = 0
            if rec.kit_line_ids:
                sum_line_qty = round(sum(rec.kit_line_ids.mapped("line_quantity")),3)
            if rec.wastage_line_ids:
                sum_of_wastage = round(sum(rec.wastage_line_ids.mapped("line_quantity")),3)
            total_sum = round(sum_line_qty + sum_of_wastage,2)
            if total_sum != master_qty:
                raise UserError(_("The total quantity should be equal to the product quantity."))
            sequence = self.env['ir.sequence'].next_by_code('kit.assembly') or _('New')
            rec.name = sequence
        return res

    def write(self, vals):
        res = super(KitAssembly, self).write(vals)
        if self.id:
            if 'quantity' in vals or 'kit_line_ids' in vals or 'wastage_line_ids' in vals:
                master_qty = round(self.quantity,2)
                sum_line_qty = 0
                sum_of_wastage = 0
                if self.kit_line_ids:
                    sum_line_qty = round(sum(self.kit_line_ids.mapped("line_quantity")),3)
                if self.wastage_line_ids:
                    sum_of_wastage = round(sum(self.wastage_line_ids.mapped("line_quantity")),3)
                total_sum = round(sum_line_qty + sum_of_wastage,2)
                if total_sum != master_qty:
                    raise UserError(_("The total quantity should be equal to the product quantity."))
        return res

    @api.onchange("bom_id")
    def _onchange_bom_id(self):
        new_lines = []
        if self.bom_id:
            if self.kit_line_ids:
                self.kit_line_ids = False
            for each in self.bom_id.bom_line_ids:
                new_lines.append(
                    (
                        0,
                        0,
                        {
                            "product_id": each.product_id.id,
                            "line_quantity": each.product_qty,
                            # "line_uom_id": each.product_uom_id.id,
                            "kit_assembly_id": self.id,
                            # "is_no_track": each.is_no_track,
                        },
                    )
                )
            vals = {
                "quantity": self.bom_id.product_qty,
                "kit_line_ids": new_lines,
            }
            self.sudo().write(vals)
            self.kit_line_ids._onchange_uom_product_id()

    @api.depends("product_id")
    @api.depends_context('default_is_disassembly')
    def _compute_domain_lot_ids_binary(self):
        for rec in self:
            rec.lot_ids = False
            rec.lot_ids_binary = "[('id','in',[])]"
            if rec.product_id:
                lots =self.env['stock.lot'].search([('product_id', '=', rec.product_id.id),('product_qty', '>', 0)])
                if lots:
                    rec.lot_ids = [(6,0,lots.ids)]
                    rec.lot_ids_binary = "[('id','in',%s)]"%lots.ids
                else:
                    rec.lot_ids_binary = "[('id','in',[])]"





class KitAssemblyLine(models.Model):
    _name = "kit.assembly.lines"
    _description = "Kit Assembly Lines"

    kit_assembly_id = fields.Many2one("kit.assembly", string="Kit Assembly")
    product_id = fields.Many2one("product.product", string="Product")
    line_quantity = fields.Float("Quantity",digits='Product Unit of Measure')
    line_uom_id = fields.Many2one("uom.uom", string="UoM")
    unit_cost = fields.Float("Total Cost", compute="_compute_unit_cost")
    serial_ids = fields.One2many("kit.serial", "kit_serial_line_id", string="Serial")
    is_no_track = fields.Boolean("is_no_track", default=False, copy=False)
    product_sku = fields.Char('SKU', related='product_id.default_code')
    single_product_cost = fields.Float(string="Unit Cost",compute="_compute_single_product_cost")
    arabic_name = fields.Char(related='product_id.product_tmpl_id.arabic_name', string='Arabic Name')


    def action_show_serial(self):
        self.ensure_one()
        view = self.env.ref("bi_kit_assembly.serial_line_tracking_view_form")
        return {
            "name": _("Tracking"),
            "type": "ir.actions.act_window",
            "view_mode": "form",
            "res_model": "kit.assembly.lines",
            "views": [(view.id, "form")],
            "view_id": view.id,
            "target": "new",
            "res_id": self.id,
        }

    @api.onchange("product_id")
    def _onchange_uom_product_id(self):
        for line in self:
            if line.product_id:
                if line.product_id.uom_id:
                    line.line_uom_id = line.product_id.uom_id.id
            # if line.product_id.tracking == "none":
            #     line.is_no_track = True
            # else:
            #     line.is_no_track = False

    # @api.onchange("serial_ids", "line_quantity")
    # def _onchange_serial_ids(self):
    #     for each in self:
    #         if each.product_id.tracking == "serial":
    #             if each.line_quantity < len(each.mapped("serial_ids")):
    #                 raise UserError(_("Serial Number Exceeded"))
    # @api.constrains("line_quantity")
    # def _check_line_quantity(self):
    #     for each in self:
    #         master_qty = each.kit_assembly_id.quantity
    #         sum_line_qty = sum(each.kit_assembly_id.kit_line_ids.mapped("line_quantity"))
    #         sum_of_wastage = sum(each.kit_assembly_id.wastage_line_ids.mapped("line_quantity"))
    #         total_sum = sum_line_qty + sum_of_wastage
    #         if total_sum != master_qty:
    #             raise UserError(_("Check Quantity"))

    def _compute_single_product_cost(self):
        for rec in self:
            if not rec.product_id.is_wastage:
                if rec.line_quantity and self.kit_assembly_id.quantity:
                    master_qty = self.kit_assembly_id.quantity
                    master_price = self.kit_assembly_id.product_id.standard_price
                    total_cost = master_qty*master_price
                    # cost_per_unit = total_cost/master_qty
                    if self.kit_assembly_id.wastage_line_ids:
                        total_wastage_qty = sum(self.kit_assembly_id.wastage_line_ids.mapped("line_quantity"))
                        if total_wastage_qty:
                            total_qty = master_qty - total_wastage_qty
                            rec.single_product_cost = total_cost/total_qty
                        else:
                            total_qty = sum(self.kit_assembly_id.kit_line_ids.mapped("line_quantity"))
                            rec.single_product_cost = total_cost/total_qty
                        # with_wastage_total_cost = total_qty * self.kit_assembly_id.product_id.standard_price
                        # with_wastage_cost_per_unit = with_wastage_total_cost/total_qty
                        # total = with_wastage_cost_per_unit * rec.line_quantity
                        # rec.single_product_cost = total/rec.line_quantity
                    else:
                        total_qty_without_waste = sum(self.kit_assembly_id.kit_line_ids.mapped("line_quantity"))
                        rec.single_product_cost = total_cost/total_qty_without_waste
                        # rec.single_product_cost = total/rec.line_quantity
                        # total = cost_per_unit * rec.line_quantity
                        # rec.single_product_cost = total/rec.line_quantity
                else:
                    rec.single_product_cost = 0.0
            else:
                rec.single_product_cost = rec.product_id.standard_price


    def _compute_unit_cost(self):
        for rec in self:
            if rec.line_quantity and self.kit_assembly_id.quantity:
                rec.unit_cost = rec.single_product_cost*rec.line_quantity
                # master_qty = self.kit_assembly_id.quantity
                # master_price = self.kit_assembly_id.product_id.standard_price
                # total_cost = master_qty*master_price
                # cost_per_unit = total_cost/master_qty
                # if self.kit_assembly_id.wastage_line_ids:
                # # if self.kit_assembly_id.wastage:
                #     total_wastage_qty = sum(self.kit_assembly_id.wastage_line_ids.mapped("line_quantity"))
                #     total_qty = master_qty - total_wastage_qty
                #     with_wastage_total_cost = total_qty * self.kit_assembly_id.product_id.standard_price
                #     with_wastage_cost_per_unit = with_wastage_total_cost/total_qty
                #     rec.unit_cost = with_wastage_cost_per_unit * rec.line_quantity
                # else:
                #     rec.unit_cost =  cost_per_unit * rec.line_quantity
            else:
                rec.unit_cost = 0.0

    class ProductKitSerial(models.Model):
        _name = "kit.serial"
        _description = "Kit Serial ID"

        kit_serial_line_id = fields.Many2one("kit.assembly.lines", string="")
        serial_quantity = fields.Integer("Quantity",digits='Product Unit of Measure')
        serial_id = fields.Many2one("stock.lot", string="Serial number", required=True)
        is_lot = fields.Boolean("is_lot_track", default=False, copy=False, compute="_compute_is_lot")

        def _compute_is_lot(self):
            for line in self:
                if line.kit_serial_line_id.product_id.tracking == "lot":
                    line.is_lot = True
                else:
                    line.is_lot = False

        @api.onchange("serial_id")
        def _onchange_serial_id(self):
            serial_ids = self.kit_serial_line_id.serial_ids.mapped("serial_id").ids
            for each in self:
                if each.kit_serial_line_id.product_id.tracking == "lot":
                    total_actual_qty = each.kit_serial_line_id.line_quantity
                    serial_qty = sum(self.mapped("serial_quantity"))
                    if total_actual_qty < serial_qty:
                        raise UserError(_("Quantity Exceeded"))
                    lot_qty = each.kit_serial_line_id.product_id.with_context(
                        {
                            "to_date": datetime.datetime.now(),
                            "lot_id": each.id,
                            "location_id": self.kit_serial_line_id.kit_assembly_id.location_id.id,
                        }
                    ).qty_available
                    if each.serial_quantity > lot_qty:
                        raise UserError(
                            _(
                                f"Quantity {each.serial_quantity} for {each.kit_serial_line_id.product_id.name}"
                                f" is greater than the available quantity in given lots."
                            )
                        )
            return {
                "domain": {
                    "serial_id": [
                        ("product_id", "=", self.kit_serial_line_id.product_id.id),
                        ("id", "not in", serial_ids),
                    ]
                }
            }


    class WastageLine(models.Model):
        _name = 'wastage.line'
        _description = "Wastage Products"

        assembly_id = fields.Many2one('kit.assembly')
        product_id = fields.Many2one("product.product", string="Product")
        arabic_name = fields.Char(related='product_id.product_tmpl_id.arabic_name', string='Arabic Name')
        line_quantity = fields.Float("Quantity",digits='Product Unit of Measure')
        line_uom_id = fields.Many2one("uom.uom", string="UoM")
        product_sku = fields.Char('SKU', related='product_id.default_code')
