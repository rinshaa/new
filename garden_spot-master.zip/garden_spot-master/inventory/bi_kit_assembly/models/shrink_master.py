from odoo import _, fields, models
from odoo.exceptions import UserError



class ShrinkMaster(models.Model):
    _name = "shrink.master"
    _description = "Shrinkage Products"
    _rec_name = "product_id"
    _inherit = ["mail.thread", "mail.activity.mixin"]

    product_id = fields.Many2one("product.product", string="Product")
    arabic_name = fields.Char(related='product_id.product_tmpl_id.arabic_name', string='Arabic Name')
    shrink_qty = fields.Float(string="Shrink Quantity")
    lot_id = fields.Many2one("stock.lot",string="Lot No")
    state = fields.Selection(
        selection=[
            ("draft", "Draft"),
            ("approved", "Approved"),
        ],
        string="Status",
        tracking=True,
        default="draft",
    )

    # @api.onchange("product_id")
    # def _onchange_product_id(self):
    #     lot_id = self.env["stock.lot"].search([('product_id','=',self.product_id.id)])
    #     return {'domain':{'lot_id':[('id','in',lot_id.ids)]}}

    def action_create_scrap_order(self):
        if self.shrink_qty > self.product_id.qty_available:
            raise UserError(_("The quantity of shrinkage cannot exceed the quantity on hand."))
        scrap_order = self.env["stock.scrap"].create({
            'product_id': self.product_id.id,
            'scrap_qty': self.shrink_qty,
            'product_uom_id':self.product_id.uom_id.id,
            'lot_id':self.lot_id.id,
        })
        scrap_order.action_validate()
        self.write({'state':'approved'})
