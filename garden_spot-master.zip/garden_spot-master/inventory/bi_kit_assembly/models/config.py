from odoo import fields, models


class ResConfig(models.TransientModel):
    _inherit = "res.config.settings"

    journal_id = fields.Many2one(
        "account.journal", config_parameter="bi_kit_assembly.journal_id", string="Journal")
    location_id = fields.Many2one(
            "stock.location", config_parameter="bi_kit_assembly.location_id", string="Wastage Location")
