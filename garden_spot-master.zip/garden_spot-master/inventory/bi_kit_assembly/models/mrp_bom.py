from odoo import models,fields

class MrpBOM(models.Model):
    _inherit="mrp.bom"

    arabic_name = fields.Char(related='product_tmpl_id.arabic_name', string='Arabic Name')


class MrpBOMLine(models.Model):
    _inherit="mrp.bom.line"

    arabic_name = fields.Char(related='product_id.product_tmpl_id.arabic_name', string='Arabic Name')
