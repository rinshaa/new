from odoo import fields, models


class AccountJournal(models.Model):
    _inherit = "account.move"

    assembly_id = fields.Many2one("kit.assembly", string="Assembly")
