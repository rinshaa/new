from odoo import models,_
from odoo.exceptions import UserError




class StockMove(models.Model):
    _inherit = "stock.move"

    def _get_in_svl_vals(self, forced_quantity):
        res = super(StockMove, self)._get_in_svl_vals(forced_quantity)
        context_dict = self._context
        for each in res:
            # if 'kit_id' in self._context:
            #     product_id = self.env['product.product'].browse(each['product_id'])
            #     meat_process_id = self.env['kit.assembly'].browse(self._context['kit_id'])
            #     kit_line_ids = meat_process_id.mapped('kit_line_ids').filtered(
            #         lambda l: l.product_id == product_id)
            #     unit_cost = kit_line_ids.mapped("single_product_cost")[0]
            #     each['unit_cost'] = unit_cost
            #     each['value'] = unit_cost * kit_line_ids.line_quantity
            if 'kit_id' in context_dict and 'is_meat' in context_dict and 'bi_new_product_price' in context_dict and \
                    'line_new_product_qty' in context_dict:
                # product_id = self.env['product.product'].browse(each['product_id'])
                # meat_process_id = self.env['kit.assembly'].browse(self._context['kit_id'])
                # kit_line_ids = meat_process_id.mapped('kit_line_ids').filtered(
                #     lambda l: l.product_id == product_id)
                # unit_cost = kit_line_ids.mapped("single_product_cost")[0]
                # each['unit_cost'] = unit_cost
                new_product_price = context_dict.get('bi_new_product_price')
                each['unit_cost'] = new_product_price
                new_product_line_qty = context_dict.get('line_new_product_qty')
                each['value'] = new_product_price * new_product_line_qty
        return res

    def _create_out_svl(self, forced_quantity=None):
        res = super(StockMove, self)._create_out_svl(forced_quantity=None)
        for each in res:
            if 'is_finished' in self._context:
                meat_process_id = self.env['kit.assembly'].browse(self._context['kit_id'])
                st_price = meat_process_id.product_id.standard_price
                if 'new_raw_product_cost' in self._context:
                    st_price = self._context['new_raw_product_cost']
                product_qty_effective = meat_process_id.quantity
                if 'effective_product_qty' in self._context:
                    product_qty_effective = self._context['effective_product_qty']
                unit_cost = product_qty_effective * st_price
                each['unit_cost'] = st_price
                each['value'] = unit_cost * -1
            if 'is_finished_wastage_move' in self._context:
                each['unit_cost'] = 0.0
                each['value'] = 0.0
        return res

    def _get_accounting_data_for_valuation(self):
        res = super(StockMove,self)._get_accounting_data_for_valuation()
        if 'is_meat' in self._context :
            config_journal_id = self.env['ir.config_parameter'].sudo().get_param('bi_kit_assembly.journal_id')
            if not config_journal_id:
                raise UserError(_('Check Journal'))
            res_list = list(res)
            res_list[0] = int(config_journal_id)
            res = tuple(res_list)
        return res

    # def product_price_update_before_done(self, forced_qty=None):
    #     res = super(StockMove,self).product_price_update_before_done(forced_qty=None)
    #     x = self._context
    #     return res
    # def _get_price_unit(self):
    #     price_unit = super()._get_price_unit()
    #     if 'is_meat' in self._context:
    #         for each in self.env['kit.assembly'].browse(self._context['kit_id']).kit_line_ids:
    #             if each.product_id == self.product_id:
    #                 price_unit = each.single_product_cost
    #     return price_unit
