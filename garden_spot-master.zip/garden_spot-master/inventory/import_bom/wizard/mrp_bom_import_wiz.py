import base64
import xlrd
from odoo import fields,models,_
from odoo.exceptions import UserError


class MrpBomImportWiz(models.TransientModel):
   _name = "mrp.bom.import.wiz"

   atachment_id = fields.Binary(sttring="Upload Document")

   #function is used to get template
   def action_export(self):
        data = {
            "ids": self.ids,
            "model": self._name,
        }
        return self.env.ref("import_bom.action_export_file").report_action(self, data=data, config=False)

   #method is used for importing data
   def action_import(self):
       if self.atachment_id:
            wb = xlrd.open_workbook(file_contents=base64.decodestring(self.atachment_id))
            val_list = []
            excel_heading = []
            for sheet in wb.sheets():
                for row in range(0, sheet.nrows):
                    for col in range(0, sheet.ncols):
                        if row==0:
                            heading = sheet.cell(row, col).value
                            if heading in ["Product", "Quantity"]:
                                excel_heading.append(heading)
                            else:
                                raise UserError(_("Incorrect Excel format"))
                        else:
                            if excel_heading[col] == "Product":
                                long_desc = sheet.cell(row, col).value
                                product_id = self.env["product.template"].search([("name", "=", long_desc)], limit=1)
                                if not product_id:
                                    raise UserError(_("Product not found!!!"))
                            elif excel_heading[col] == "Quantity":
                                quantity = sheet.cell(row, col).value
                    if row != 0:
                        val_list.append(
                            (
                                0,
                                0,
                                {
                                    "product_id": product_id.id,
                                    "product_qty": quantity,
                                },
                            )
                        )
            mrp = self.env["mrp.bom"].browse(self._context["active_id"])
            mrp.write({"bom_line_ids":val_list})
