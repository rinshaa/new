{
    "name": "import_bom",
    "description": """
        This module is used for Import Bill Of Material
    """,
    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "support": "sales@bassaminfotech.com",
    "license": "OPL-1",
    "category": "",
    "version": "17.0.0.1",
    "depends": ["mrp","report_xlsx"],
    "data": [
        'security/ir.model.access.csv',
        'views/mrp_bom.xml',
        'reports/export_action.xml',
        'wizard/mrp_bom_import_wiz.xml',
    ],
}
