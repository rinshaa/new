from odoo import models

class MrpBom(models.Model):
    _inherit = 'mrp.bom'

    def action_show_imp_wizard(self):
        return {
            'name': 'Import BOM Wizard',
            'type': 'ir.actions.act_window',
            'res_model': 'mrp.bom.import.wiz',
            'view_mode': 'form',
            'view_type': 'form',
            'target': 'new',
        }
