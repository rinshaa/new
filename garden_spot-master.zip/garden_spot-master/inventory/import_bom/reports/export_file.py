from odoo import models


class MobileNumberExpenseImport(models.AbstractModel):
    _name = "report.import_bom.export_report_xlsx"
    _inherit = "report.report_xlsx.abstract"

    def generate_xlsx_report(self, workbook, data, lines):
        sheet = workbook.add_worksheet('Export Template')

        merge_format_2 = workbook.add_format({
                                        'bold': 1,
                                        'align': 'center',
                                        'fg_color':'#808080',
                                        'font_size':11,
                                        })
        sheet.set_column('A:A',15)
        sheet.set_column('B:B',15)

        sheet.write('A1','Product',merge_format_2)
        sheet.write('B1','Quantity',merge_format_2)
