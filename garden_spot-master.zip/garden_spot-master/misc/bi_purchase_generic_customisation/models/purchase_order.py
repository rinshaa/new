from odoo import models, fields, api
from datetime import date


class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'


    is_alert = fields.Boolean('Is Alert', default=False)
    order_date = fields.Date('Order Date')


    @api.onchange('partner_ref')
    def _onchange_reference_duplication(self):
        for record in self:
            if record.partner_ref:
                duplicate_orders = self.env['purchase.order'].search([
                        ('partner_ref', '=', record.partner_ref)])     
                if duplicate_orders:
                    record.is_alert = True
                else:
                    record.is_alert = False

