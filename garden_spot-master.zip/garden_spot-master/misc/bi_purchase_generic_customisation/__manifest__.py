{
    "name": "BI Purchase Customisation",
    "summary": """
       Customisation In  Purchase Order
    """,
    "description": """
       Customisation In Purchase Order
    """,
    "author": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "support": "sales@bassaminfotech.com",
    "license": "OPL-1",
    "category": "Purchase",
    "version": "17.0.0.0.1",
    "depends": ["purchase"],
    "data": [
        "views/purchase_order_view.xml",
    ],
}
