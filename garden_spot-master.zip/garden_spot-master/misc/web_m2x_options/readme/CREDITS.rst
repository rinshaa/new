The migration of this module from 15.0 to 16.0 was financially supported by Camptocamp
