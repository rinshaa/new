{
    "name": "PRODUCT PRICELIST PRINT LABEL",
    "version": "17.1",
    "summary": """ PRODUCT PRICELIST PRINT LABEL""",
    "description": """PRODUCT PRICELIST PRINT LABEL""",
    "author": "Bassam Infotech LLP",
    "company": "Bassam Infotech LLP",
    "maintainer": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "category": "Tools",
    "depends": ["base","stock","product"],
    "data": [
            "views/pricelist_list.xml"
    ],
    "images": [],
    "license": "OPL-1",
    "installable": True,
    "application": False,
}
