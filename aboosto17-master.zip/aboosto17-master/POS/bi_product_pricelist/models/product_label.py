# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from collections import defaultdict
from odoo import fields, models,api
from odoo.tools import float_compare, float_is_zero


class ProductLabelLayout(models.TransientModel):
    _inherit = 'product.label.layout'

    product_pricelist_id = fields.Binary(string="Pricelist Domain",compute="_compute_product_pricelist_id")

    @api.depends("custom_quantity")
    def _compute_product_pricelist_id(self):
        pricelist_list = []
        for rec in self:
            pricelist_list = self.env['product.pricelist'].search([]).mapped("item_ids").filtered(lambda l:l.product_tmpl_id.id==rec.product_tmpl_ids._origin.id).mapped("pricelist_id").ids
            rec.product_pricelist_id = "[('id','in',%s)]"%pricelist_list