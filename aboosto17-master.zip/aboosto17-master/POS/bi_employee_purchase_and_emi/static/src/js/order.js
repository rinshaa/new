/** @odoo-module */

import { Order } from "@point_of_sale/app/store/models";
import { patch } from "@web/core/utils/patch";
import { ErrorPopup } from "@point_of_sale/app/errors/popups/error_popup";
import { _t } from "@web/core/l10n/translation";

patch(Order.prototype, {
    async pay() {
        if (this.is_button_clicked) {
            this.env.services.popup.add(ErrorPopup, {
                title: _t("Limit Exceeds "),
                body: _t("The Purchase Limit of selected employee is exceeded"),
            });
            return;
        }
        return super.pay(...arguments);
    },
});
