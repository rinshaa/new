/** @odoo-module */

import { _t } from "@web/core/l10n/translation";
import { ProductScreen } from "@point_of_sale/app/screens/product_screen/product_screen";
import { useService } from "@web/core/utils/hooks";
import { ErrorPopup } from "@point_of_sale/app/errors/popups/error_popup";
import { Component } from "@odoo/owl";
import { usePos } from "@point_of_sale/app/store/pos_hook";

export class EmployeeDiscount extends Component {
    static template = "bi_employee_purchase_and_emi.EmployeeDiscount";

    setup() {
        this.pos = usePos();
        this.popup = useService("popup");
        this.orm = useService("orm");
    }

    async click() {
            const pc = this.pos.config.discount_percentage;
            
            const order = this.pos.get_order();
            const lines = order.get_orderlines();
            const partner = order.get_partner();
            if  (!order.get_partner()){
                await this.popup.add(ErrorPopup, {
                    title: _t("No Customer found"),
                    body: _t(
                        "Please Select A Customer."
                    ),
                });
                return;
            }

            else{
                if (order.get_partner().is_employee){
                    const product = this.pos.db.get_product_by_id(this.pos.config.discount_product_id[0]);
                    if (product === undefined) {
                        await this.popup.add(ErrorPopup, {
                            title: _t("No discount product found"),
                            body: _t(
                                "The discount product seems misconfigured. Make sure it is flagged as 'Can be Sold' and 'Available in Point of Sale'."
                            ),
                        });
                        return;
                    }

                    // Remove existing discounts
                    lines
                        .filter((line) => line.get_product() === product)
                        .forEach((line) => order._unlinkOrderline(line));
                    const linesByTax = order.get_orderlines_grouped_by_tax_ids();
                    for (const [tax_ids, lines] of Object.entries(linesByTax)) {
                        const tax_ids_array = tax_ids
                            .split(",")
                            .filter((id) => id !== "")
                            .map((id) => Number(id));
                        const baseToDiscount = order.calculate_base_amount(
                            tax_ids_array,
                            lines.filter((ll) => ll.isTipRelated())
                        );
                        const discount = (-pc / 100.0) * baseToDiscount;
                        const purchase_limit = order.get_partner().purchase_limit_employee
                        const purchase_emi_approved = order.get_partner().purchase_emi_approved
                        // const discount = (baseToDiscount * -pc )/ 100.0;
                        const limit = baseToDiscount + discount
                                         
                        if (purchase_limit < limit) {
                            order.is_button_clicked = true;
                            await this.popup.add(ErrorPopup, {
                                title: _t("Limit Exceeds"),
                                body: _t("As soon as the employee's purchase limit exceeds, an EMI will be automatically created with a discount applied. Confirm with account manager"),
                            });
                            await this.notification_to_manager('',[order.get_partner(),baseToDiscount,pc]);
                            return;
                        }
                        if (discount < 0) {
                            order.add_product(product, {
                                price: discount,
                                lst_price: discount,
                                tax_ids: tax_ids_array,
                                merge: false,
                                description:
                                    `${pc}%, ` +
                                    (tax_ids_array.length
                                        ? _t(
                                              "Tax: %s",
                                              tax_ids_array
                                                  .map((taxId) => this.pos.taxes_by_id[taxId].amount + "%")
                                                  .join(", ")
                                          )
                                        : _t("No tax")),
                                extras: {
                                    price_type: "automatic",
                                },
                            });
                        }
                    }
                }
                else{
                    await this.popup.add(ErrorPopup, {
                        title: _t("Not an Employee"),
                        body: _t(
                            "Selected customer is not an employee."
                        ),
                    });
                    return;
                }
        }
    
}
async notification_to_manager(activityId,vals) {
    const action = await this.orm.call("employee.emi", "action_send_employee_purchase_notification", [[activityId],[vals]]);
}
}


        

        

ProductScreen.addControlButton({
    component: EmployeeDiscount,
    condition: function () {
        const {discount_product_id } = this.pos.config;
        return  discount_product_id;
    },
});



