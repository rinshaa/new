/** @odoo-module **/
import { Order } from "@point_of_sale/app/store/models";
import { patch } from "@web/core/utils/patch";

patch(Order.prototype, {
    async pay() {
        const employee = this.partner; 
        console.log(employee, "employee"); 
        
        if (employee && employee.is_employee) { 
            this.to_invoice = true; 
        } else {
            this.to_invoice = false; 
        }

        return await super.pay(...arguments);
    },
});

