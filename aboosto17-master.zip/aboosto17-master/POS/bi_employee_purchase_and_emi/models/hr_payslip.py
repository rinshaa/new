from odoo import models, fields, api, _
from datetime import date, timedelta,datetime
from dateutil.relativedelta import relativedelta 
from odoo.exceptions import UserError
import calendar

class HrPayslip(models.Model):
    
    _inherit = "hr.payslip"
    
    
    @api.depends('employee_id', 'contract_id', 'struct_id', 'date_from', 'date_to')          
    def _compute_input_line_ids(self):
        res = super()._compute_input_line_ids()
        for rec in self:
            first_day_of_month = rec.date_from.replace(day=1)
            if first_day_of_month.month == 12:
                next_month_first_day = first_day_of_month.replace(year=first_day_of_month.year + 1, month=1)
            else:
                next_month_first_day = first_day_of_month.replace(month=first_day_of_month.month + 1)
            last_day_of_month = next_month_first_day - timedelta(days=1)
            customer = rec.env['res.partner'].search([('employee_ids','in',rec.employee_id.id)])
            wage = rec.employee_id.contract_id.wage
            invoices = rec.env['account.move'].search([
                ('partner_id','=',customer.id),
                # ('invoice_date', '>=', first_day_of_month),
                # ('invoice_date', '<=', last_day_of_month),
                ('amount_residual','>',0)                                    
                ])
            employee_emi = rec.env['employee.emi'].search([('employee_id','=',rec.employee_id.id),('approve_state','=','approved')])
            if employee_emi:
                for emp in employee_emi:
                    emi_amount = []
                    if emp.employee_purchase_line_ids:
                        for amount in emp.employee_purchase_line_ids:
                            if amount.month:
                                emp_month_str = amount.month.split('-')[0]
                                first_day_of_month_str = calendar.month_name[first_day_of_month.month]
                                if first_day_of_month_str[:3] == emp_month_str and amount.paid == False:
                                    emi_amount = amount.expense
                                    break
                            else:
                                existing_rule = rec.struct_id.rule_ids.filtered(lambda x: x.code == "PED")
                                if existing_rule:
                                    rev_input_type_id = rec.env['hr.payslip.input.type'].search([('code', '=', "PED")], limit=1)
                                    
                                    existing_line = rec.input_line_ids.filtered(lambda line: line.input_type_id == rev_input_type_id)
                                    if existing_line:
                                        existing_line.write({
                                            'amount': 0,
                                            'name': "Purchase Expense Deduction"
                                        })
                                    else:
                                        to_add_vals = {
                                            'amount': 0,
                                            'input_type_id': rev_input_type_id.id,
                                            'name': "Purchase Expense Deduction"
                                        }
                                        rec.update({
                                            'input_line_ids': [(0, 0, to_add_vals)]
                                        })                         
                                existing_rule = rec.struct_id.rule_ids.filtered(lambda x: x.code == "PEEMI")
                                if existing_rule:
                                    rev_input_type_id = rec.env['hr.payslip.input.type'].search([('code', '=', "PEEMI")], limit=1)
                                    existing_line = rec.input_line_ids.filtered(lambda line: line.input_type_id == rev_input_type_id)
                                    if existing_line:
                                        existing_line.write({
                                            'amount': 0,
                                            'name': "Purchase Expense Deduction"
                                        })
                                    else:
                                        to_add_vals = {
                                            'amount': 0,
                                            'input_type_id': rev_input_type_id.id,
                                            'name': "Purchase Expense Deduction"
                                        }
                                        rec.update({
                                            'input_line_ids': [(0, 0, to_add_vals)]
                                        })    
                    if emi_amount:
                        deduction = emi_amount
                        existing_rule = rec.struct_id.rule_ids.filtered(lambda x: x.code == "PEEMI")

                        if existing_rule:
                            rev_input_type_id = rec.env['hr.payslip.input.type'].search([('code', '=', "PEEMI")], limit=1)
                            
                            existing_line = rec.input_line_ids.filtered(lambda line: line.input_type_id == rev_input_type_id)
                            if existing_line:
                                existing_line.write({
                                    'amount': deduction,
                                    'name': "Purchase Expense EMI"
                                })
                            else:
                                to_add_vals = {
                                    'amount': deduction,
                                    'input_type_id': rev_input_type_id.id,
                                    'name': "Purchase Expense EMI"
                                }
                                rec.update({
                                    'input_line_ids': [(0, 0, to_add_vals)]
                                })
                            existing_rule = rec.struct_id.rule_ids.filtered(lambda x: x.code == "PED")
                            if existing_rule:
                                rev_input_type_id = rec.env['hr.payslip.input.type'].search([('code', '=', "PED")], limit=1)
                                existing_line = rec.input_line_ids.filtered(lambda line: line.input_type_id == rev_input_type_id)
                                if existing_line:
                                    existing_line.write({
                                        'amount': 0,
                                        'name': "Purchase Expense Deduction"
                                    })
                                else:
                                    to_add_vals = {
                                        'amount': 0,
                                        'input_type_id': rev_input_type_id.id,
                                        'name': "Purchase Expense Deduction"
                                    }
                                    rec.update({
                                        'input_line_ids': [(0, 0, to_add_vals)]
                                    })

            else:
                total_balance = sum(inv.amount_residual for inv in invoices)
                if total_balance :
                    deduction = total_balance
                    existing_rule = rec.struct_id.rule_ids.filtered(lambda x: x.code == "PED")
                    if existing_rule:
                        rev_input_type_id = rec.env['hr.payslip.input.type'].search([('code', '=', "PED")], limit=1)
                        
                        existing_line = rec.input_line_ids.filtered(lambda line: line.input_type_id == rev_input_type_id)
                        if existing_line:
                            existing_line.write({
                                'amount': deduction,
                                'name': "Purchase Expense Deduction"
                            })
                        else:
                            to_add_vals = {
                                'amount': deduction,
                                'input_type_id': rev_input_type_id.id,
                                'name': "Purchase Expense Deduction"
                            }
                            rec.update({
                                'input_line_ids': [(0, 0, to_add_vals)]
                            })
                        existing_rule = rec.struct_id.rule_ids.filtered(lambda x: x.code == "PEEMI")
                        if existing_rule:
                            rev_input_type_id = rec.env['hr.payslip.input.type'].search([('code', '=', "PEEMI")], limit=1)
                            if rev_input_type_id in rec.input_line_ids.mapped('input_type_id'):
                                existing_line = rec.input_line_ids.filtered(lambda line: line.input_type_id == rev_input_type_id)
                                existing_line.write({
                                    'amount': 0,
                                    'name': "Purchase Expense EMI"
                                })
                            else:
                                to_add_vals = {
                                    'amount': 0,
                                    'input_type_id': rev_input_type_id.id,
                                    'name': "Purchase Expense EMI"
                                }
                                rec.update({
                                    'input_line_ids': [(0, 0, to_add_vals)]
                                })            
                else:
                    existing_rule = rec.struct_id.rule_ids.filtered(lambda x: x.code == "PED")
                    if existing_rule:
                        rev_input_type_id = rec.env['hr.payslip.input.type'].search([('code', '=', "PED")], limit=1)
                        
                        existing_line = rec.input_line_ids.filtered(lambda line: line.input_type_id == rev_input_type_id)
                        if existing_line:
                            existing_line.write({
                                'amount': 0,
                                'name': "Purchase Expense Deduction"
                            })
                        else:
                            to_add_vals = {
                                'amount': 0,
                                'input_type_id': rev_input_type_id.id,
                                'name': "Purchase Expense Deduction"
                            }
                            rec.update({
                                'input_line_ids': [(0, 0, to_add_vals)]
                            })                         
                    existing_rule = rec.struct_id.rule_ids.filtered(lambda x: x.code == "PEEMI")
                    if existing_rule:
                        rev_input_type_id = rec.env['hr.payslip.input.type'].search([('code', '=', "PEEMI")], limit=1)
                        existing_line = rec.input_line_ids.filtered(lambda line: line.input_type_id == rev_input_type_id)
                        if existing_line:
                            existing_line.write({
                                'amount': 0,
                                'name': "Purchase Expense Deduction"
                            })
                        else:
                            to_add_vals = {
                                'amount': 0,
                                'input_type_id': rev_input_type_id.id,
                                'name': "Purchase Expense Deduction"
                            }
                            rec.update({
                                'input_line_ids': [(0, 0, to_add_vals)]
                            })
        return res                   
                                                
    def _action_create_account_move(self):
        res = super(HrPayslip,self)._action_create_account_move()
        if self.move_id:
            self.move_id.action_post()
        return res  
                
                            
    def action_register_payment(self):
        res = super(HrPayslip, self).action_register_payment()
        first_day_of_month = self.date_from.replace(day=1)
        if first_day_of_month.month == 12:
            next_month_first_day = first_day_of_month.replace(year=first_day_of_month.year + 1, month=1)
        else:
            next_month_first_day = first_day_of_month.replace(month=first_day_of_month.month + 1)
        last_day_of_month = next_month_first_day - timedelta(days=1)
        customer = self.env['res.partner'].search([('employee_ids','in',self.employee_id.id)])
        wage = self.employee_id.contract_id.wage
        invoices = self.env['account.move'].search([
            ('partner_id','=',customer.id),
            # ('invoice_date', '>=', first_day_of_month),
            # ('invoice_date', '<=', last_day_of_month),
            ('amount_residual','>',0),                                    
            ])
        employee_emi = self.env['employee.emi'].search([('employee_id','=',self.employee_id.id),('approve_state','=','approved')])
        if employee_emi:
            first_day_of_emi_month = employee_emi.create_date.replace(day=1)
            invoices = self.env['account.move'].search([
                    ('partner_id','=',customer.id),
                    ('invoice_date', '>=', first_day_of_emi_month),
                    ('invoice_date', '<=', last_day_of_month),
                    ('amount_residual','>',0)                                    
                    ])
            if not invoices:
                 raise UserError(_("Invoice against {customer} not found. Please ensure order confirmation from POS.").format(customer=customer.name))
            for emp in employee_emi.employee_purchase_line_ids:
                if emp.month:
                    emp_month_str = emp.month.split('-')[0]
                    first_day_of_month_str = calendar.month_name[first_day_of_month.month]
                if first_day_of_month_str[:3] == emp_month_str:
                    if not emp.paid:
                        emp.paid = True
                        
            
        total_balance = sum(inv.amount_residual for inv in invoices)
        for inv in invoices:
            payment_obj = self.env['account.payment']
            journal_id = self.env["account.journal"].search([('code','=','BNK1')]) 
            payment_method_line_id = self.env["account.payment.method.line"].search([('journal_id','=',journal_id.id)],limit=1)
            partner_id = inv.partner_id
            payment_type  = 'inbound'
            partner_type  = 'customer'
            if employee_emi:
                amount = employee_emi.employee_purchase_line_ids[0].expense
            else:
                amount = inv.amount_residual   
            values = {
                    'journal_id':journal_id.id,
                    'partner_id':partner_id.id,
                    'payment_type':payment_type,
                    'amount':amount,
                    'date':date.today(),
                    'partner_type':partner_type,
                    'payment_method_line_id':payment_method_line_id.id,
                            }
            payment_id = payment_obj.create(values)
            payment_id.action_post()
            inv.payment_id = payment_id.id
            inv.action_reconcile()      
        return res                    
                    
                    
                            

  
    
   
       
        
        
        
    
    
