from odoo import models, fields, api, _
from odoo.exceptions import UserError
from odoo.tools.date_utils import start_of, end_of
from datetime import date, timedelta,datetime
from dateutil.relativedelta import relativedelta 
import calendar

class EmployeePurchase(models.Model):
    _name = 'employee.emi'
    _rec_name = 'employee_id'
    _description = "Employee Emi"
    _inherit = ['mail.thread','mail.activity.mixin']
    
    employee_id = fields.Many2one('hr.employee',string ="Employee")
    account_manager_id = fields.Many2one('res.users',string = "Approved Manager")
    approve_state = fields.Selection([('to_be_approved', 'To be approved'), ('approved', 'Approved'),('closed','Closed')],default = "to_be_approved")
    request_date = fields.Date(string = "Date EMI Requested")
    expense = fields.Float(string = "Expense")
    month = fields.Integer(string="Set EMI Month's")
    employee_purchase_line_ids = fields.One2many('employee.emi.line','employee_purchase_id',string = "Line connection")
    activity_user_id = fields.Many2one('res.users', string='Responsible')
    emi_closed = fields.Boolean(string = "EMI Closed")
    active = fields.Boolean(default=True)

    
    def action_send_employee_purchase_notification(self,value):
        current_date = fields.Date.today()
        first_day = start_of(current_date, "month")
        last_day = end_of(current_date, "month")
        product_amount = value[0][1]
        discount_amount = value[0][2]
        user = self.env.user
        if user.company_id:
            tax = user.company_id.account_sale_tax_id
        else:
            tax = 0
        order_amount_with_discount = product_amount - (discount_amount * product_amount)/100
        order_amount_disc_and_tax = order_amount_with_discount + (product_amount * tax.amount) / 100
        customer_specific_id = value[0][0]['id']
        customer_id = self.env['res.partner'].sudo().search([('id','=',customer_specific_id)])
        employee_id = self.env['hr.employee'].sudo().search([('work_contact_id','=',customer_id.id)])
        invoices = self.env['account.move'].sudo().search([
                ('partner_id', '=', customer_id.id),
                # ('invoice_date', '>=', first_day),
                # ('invoice_date', '<=', last_day),
                ('amount_residual','>',0) 
            ])
        total_balance = sum(inv.amount_residual for inv in invoices)
        if employee_id.contract_ids.state =='open' and employee_id.contract_ids.active:
            account_manager_group = self.env.ref(
            'bi_employee_purchase_and_emi.account_manager')
            if employee_id and product_amount:
                users = self.env['res.users'].search([('groups_id','in',account_manager_group.id)])
                activity_type_id = self.env.ref('mail.mail_activity_data_todo').id
                employee_emi = self.search([('employee_id','=',employee_id.id),('approve_state','!=','closed'),('approve_state','=','to_be_approved')])
                if not employee_emi:
                    employee_emi = (
                            self.env["employee.emi"].sudo().create(
                                {
                                    "employee_id": employee_id.id,
                                    "approve_state":"to_be_approved",
                                    "request_date":fields.Date.today(),
                                    "expense": order_amount_disc_and_tax + total_balance

                                }
                            )
                        )

                    self.employee_purchase_line_ids = self.env["employee.emi.line"].sudo().create(
                            {
                                "employee_purchase_id": employee_emi.id,
                                "month": '',
                                "expense":'',
                                "paid":'',
                            }
                        )
                for user in users:
                    activity_vals_list = []
                if user.partner_id.email:
                    existing_activity = self.env['mail.activity'].sudo().search([
                        ('activity_type_id', '=', activity_type_id),
                        ('res_id', '=', employee_emi.id),
                        ('user_id', '=', user.id),
                    ], limit=1)
                    if not existing_activity:
                        activity_vals = {
                            'activity_type_id': activity_type_id,
                            'user_id': user.id,
                            'res_id': employee_emi.id,
                            'res_model_id': self.env.ref('bi_employee_purchase_and_emi.model_employee_emi').sudo().id,
                            'note': f'New employee EMI For: {employee_id.name} - Is Requested',
                        }
                        activity_vals_list.append(activity_vals)
                        self.env['mail.activity'].sudo().create(activity_vals_list)

                        
                                      
                        
                        
    def approve_emi(self):
        if self.month:
            if not self.approve_state == 'approved':
                self.approve_state = 'approved'
                customer_id = self.env['res.partner'].search([('employee_ids','in',self.employee_id.id)])
                wage = self.employee_id.contract_id.wage
                limit = wage/2
                expense = self.expense
                if expense > limit:
                    limit_of_employee = expense
                else:
                    limit_of_employee = limit 
                if not self.account_manager_id:
                    self.account_manager_id = self.env.user.id     
                if customer_id:
                    customer_id.purchase_limit_employee = limit_of_employee
                    customer_id.purchase_emi_approved = limit_of_employee
                emi_existing = self.search([('employee_id','=',self.employee_id.id),('id', '!=', self.id),('approve_state','=','approved')])
                if emi_existing:        
                    raise UserError(_("An unpaid EMI is Running For This employee"))
            else:
                raise UserError(_("Approved EMI cant make changes"))
        else:
            raise UserError(_("Please Select month to approve EMI"))       
        
    #schedule action to close emi    
    def employee_emi_close(self):
        employee_emi = self.env["employee.emi"].search([])
      
        for record in employee_emi:
            customer_id = self.env['res.partner'].search([('employee_ids','in',record.employee_id.id)])
            all_paid = all(line.paid for line in record.employee_purchase_line_ids)
            if all_paid:
                record.approve_state = 'closed'
                # record.active = False
                customer_id.purchase_emi_approved = 0   
                employee_id = self.env['hr.employee'].search([('work_contact_id','=',customer_id.id)])    
                customer_id.purchase_limit_employee = (employee_id.contract_id.wage)/2  
              
    @api.onchange('month')
    def split_expense(self):
        if self.month and self.expense:
            month_number = self.month
            split_amount = self.expense / month_number
            lines = []
            old_date = datetime.now()
            current_date = old_date + relativedelta(months=1)            
            self.employee_purchase_line_ids = [(5,)]
            
            month_name = calendar.month_abbr[current_date.month]
            year = current_date.year
            lines.append((0, 0, {
                'employee_purchase_id': self.id,
                'month': f"{month_name}-{year}",
                'expense': split_amount,
            }))
            
            for _ in range(1, month_number):
                current_date += relativedelta(months=1)
                if current_date.year == 9999 and current_date.month > 5:
                    break
                month_name = calendar.month_abbr[current_date.month]
                year = current_date.year
                lines.append((0, 0, {
                    'employee_purchase_id': self.id,
                    'month': f"{month_name}-{year}",
                    'expense': split_amount,
                }))
                
            self.employee_purchase_line_ids = lines

        
                        
                                    
                    
    
class EmployeePurchaseLine(models.Model):
    _name = 'employee.emi.line'
    _description = "Employee Emi Line"
    
    employee_purchase_id = fields.Many2one('employee.emi',string = "Form connection")
    month = fields.Char(string = "Month")
    expense = fields.Float(string = "Expense")
    paid = fields.Boolean(string = "Paid",readonly=True)
    
            
            
    
        