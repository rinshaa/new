from odoo import models, fields, api
from datetime import date, timedelta,datetime
from odoo.tools.date_utils import start_of, end_of
from dateutil.relativedelta import relativedelta  

class ResPartner(models.Model):
    
    _inherit = "res.partner"
    
    is_employee = fields.Boolean(string = "Employee ")
    
    purchase_limit_employee = fields.Float(string = "Purchase Limit current month")
    purchase_emi_approved = fields.Float(string = "EMI approved Amount")
    
    
    def employee_purchase_limit(self):
        customer = self.env['res.partner'].search([])
        current_date = fields.Date.today()
        first_day = start_of(current_date, "month")
        last_day = end_of(current_date, "month")

        for record in customer:
            if record.employee_ids.contract_ids.state =='open' and record.employee_ids.contract_ids.active:
                allowed = (record.employee_ids.contract_ids.wage)/2
                emi_existing = self.env["employee.emi"].search([('employee_id','=',record.employee_ids.id),('approve_state','=','approved')])
                invoices = self.env['account.move'].search([
                    ('partner_id','=',record.id),
                    # ('invoice_date', '>=', first_day),
                    # ('invoice_date', '<=', last_day),
                    ('amount_residual','>',0)                                     
                    ])
                total_balance = sum(inv.amount_residual for inv in invoices)
                if total_balance < allowed and not emi_existing:
                    record.purchase_limit_employee = allowed - total_balance
                else:
                    record.purchase_limit_employee = 0
                        
    
    def is_employee_check(self):
        customer = self.env['res.partner'].search([])
        for record in customer:
            employee = self.env['hr.employee'].search([('work_contact_id','=',record.id),('contract_ids.state','=','open'),('contract_ids.active','=',True)])
            if employee:
                record.is_employee = True
            else:
                record.is_employee = False    