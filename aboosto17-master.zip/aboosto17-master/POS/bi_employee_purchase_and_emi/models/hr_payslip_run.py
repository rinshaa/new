from odoo import models,fields


class HrPayslipRun(models.Model):
    
    _inherit = "hr.payslip.run"
    
    
    def action_validate(self):
        res= super(HrPayslipRun, self).action_validate()
        for rec in self.mapped('slip_ids'):
            rec.action_register_payment()
        return res