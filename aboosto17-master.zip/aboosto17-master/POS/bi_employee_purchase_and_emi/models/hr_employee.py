from odoo import models, fields, api
from odoo.exceptions import UserError 

class HrEmployee(models.Model):
    
    _inherit = "hr.employee"
    
    
    def write(self, vals):
        res = super(HrEmployee, self).write(vals)
        if self.contract_ids.state =='open' and self.contract_ids.active:
            customer = self.env['res.partner'].search([('employee_ids','in',self.id)])
            allowed = (self.contract_ids.wage)/2
            if customer:
                customer.is_employee = True
            else:
                customer.is_employee = False
            if not customer.purchase_limit_employee:
                customer.purchase_limit_employee = allowed
        return res 
    
    
    
class HrEmployeeBase(models.AbstractModel):
    _inherit = "hr.employee.base"   
    
    def _create_work_contacts(self):
        if any(employee.work_contact_id for employee in self):
            raise UserError(_('Some employee already have a work contact'))
        work_contacts = self.env['res.partner'].create([{
            'email': employee.work_email,
            'mobile': employee.mobile_phone,
            'name': employee.name,
            'image_1920': employee.image_1920,
            'company_id': employee.company_id.id,
            'customer_rank':1
        } for employee in self])
        for employee, work_contact in zip(self, work_contacts):
            employee.work_contact_id = work_contact    
    
    

