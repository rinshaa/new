from odoo import models, fields, api
from odoo.tools.translate import _
from itertools import groupby


class PosSession(models.Model):
    _inherit = "pos.session"
    
    def _loader_params_res_partner(self):
        result = super()._loader_params_res_partner()
        result["search_params"]["fields"].append("is_employee")
        result["search_params"]["fields"].append("purchase_limit_employee")
        result["search_params"]["fields"].append("purchase_emi_approved")
        return result

    
    