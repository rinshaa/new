from odoo import models, fields, api
from datetime import date, timedelta, datetime
from odoo.tools.date_utils import start_of, end_of


class AccountMove(models.Model):
    _inherit = "account.move"

    def create(self,vals_list):
        res = super(AccountMove, self).create(vals_list)
        for move in res:
            move.employee_purchase_limit()
        return res

    def employee_purchase_limit(self):
        customer = self.partner_id
        current_date = fields.Date.today()
        first_day = start_of(current_date, "month")
        last_day = end_of(current_date, "month")

        # for record in customer:
        if customer.employee_ids.contract_ids.state == 'open' and customer.employee_ids.contract_ids.active:
            allowed = (customer.employee_ids.contract_ids.wage) / 2
            invoices = self.env['account.move'].search([
                ('partner_id', '=', customer.id),
                # ('invoice_date', '>=', first_day),
                # ('invoice_date', '<=', last_day),
                ('amount_residual','>',0) 
            ])
            total_balance = sum(inv.amount_residual for inv in invoices)
            if total_balance < allowed:
                customer.purchase_limit_employee = allowed - total_balance
            else:
                customer.purchase_limit_employee = 0   
                
    def action_reconcile(self):
        for each_line in self:
            line_id = self.env['account.move.line'].search([('move_name','=',each_line.payment_id.name),('amount_residual','<',0)],limit=1)
            for each_invoice in each_line:
                if line_id.amount_residual < 0:
                    each_invoice.js_assign_outstanding_line(line_id.id)    