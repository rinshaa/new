from . import pos_config
from . import hr_employee
from . import res_partner
from . import pos_session
from . import hr_payslip
from . import employee_emi
from . import account_move
from . import hr_payslip_run