from odoo import models, fields, api, _
from odoo.exceptions import ValidationError,UserError 

class PosConfig(models.Model):
    _inherit="pos.config"
    
    employee_discount_percentage = fields.Boolean(string = "Employee Discount Percentage")
    
    discount_percentage = fields.Float(string = "Discount Percentage ")
    
    
    @api.onchange('discount_percentage')
    def _check_discount_percentage(self):
        for record in self:
            if record.discount_percentage and record.discount_percentage < 1 or record.discount_percentage > 85:
                raise UserError(_("Discount percentage must be between 1 to 85."))
