from odoo import fields, models, _
from odoo.exceptions import UserError


class PosSession(models.Model):
    _inherit = "pos.session"

    closing_balance_rec_count = fields.Integer(string="Closing Balance Count",
                                               compute="_compute_closing_balance_rec_count")
    cash_register_balance_end_real_new = fields.Monetary(
        string="Old Ending Balance",
        readonly=True)
    is_wiz_closed = fields.Boolean(string="Taken To Bank")

    e_wallet_balance = fields.Monetary(
        string="e-Wallet Balance",
        readonly=True)
    custom_default_payment_method_id = fields.Many2one('pos.payment.method')

    def _compute_closing_balance_rec_count(self):
        for rec in self:
            closing_balance_rec_count = self.env['closing.balance.master'].sudo().search_count([
                ('pos_session_id', '=', rec.id)
            ])
            if closing_balance_rec_count:
                rec.closing_balance_rec_count = closing_balance_rec_count
            else:
                rec.closing_balance_rec_count = 0

    def action_open_closing_balance_wiz(self):
        self.cash_register_balance_end_real_new = self.cash_register_balance_end_real
        self.cash_register_balance_end_real = 0
        move_id = self.generate_entry()
        lst = {"pos_session_id": self.id,
               "company_id": self.company_id.id,
               "total_amount": self.cash_register_balance_end_real_new + self.e_wallet_balance,
               "account_move_id": move_id.id
               }
        closing_balance_master_obj = self.env["closing.balance.master"]
        closing_balance_master_obj.create(lst)

    def generate_entry(self):
        # cash_payment_method_id = self.payment_method_ids.filtered(lambda l: l.is_cash and l.amount > 0)
        payment_methods = self.env['pos.payment'].search([('session_id', '=', self.id)])
        if payment_methods:
            cash_payment_method_id = payment_methods.filtered(lambda l: l.payment_method_id.is_cash)

        debit_account = cash_payment_method_id.payment_method_id.journal_id.petty_cash_account_id
        credit_account = cash_payment_method_id.payment_method_id.journal_id.default_account_id
        if debit_account:
            main_journal = self.env['account.journal'].search([('default_account_id', '=', debit_account[0].id)])

        if not debit_account:
            raise UserError("Please set the Petty Cash Account for the Cash Journal")

        line_ids = []

        # For Tax Journal Entry
        default_account_sale_tax_id = self.env.company.account_sale_tax_id
        if default_account_sale_tax_id:
            tax_account_id = self.env.company.account_sale_tax_id.invoice_repartition_line_ids.filtered(
                lambda line: line.repartition_type == 'tax').account_id
            tax_rate = default_account_sale_tax_id.amount if self.env.company.account_sale_tax_id.amount_type == 'percent' else 1

            tax_line_ids = []
            total_tax_amount = self.env['account.move'].search([('ref', '=', self.name)]).line_ids.filtered(
                lambda line: line.account_id.id == tax_account_id.id and line.credit != 0.0).credit
            total_discount_tax_amount = self.env['account.move'].search([('ref', '=', self.name)]).line_ids.filtered(
                lambda line: line.account_id.id == tax_account_id.id and line.debit != 0.0).debit
            # total_tax_amount_after_discount = round(total_tax_amount - total_discount_tax_amount,2)
            total_tax_amount_after_discount = sum(cash_payment_method_id.mapped('tax_amount'))

            tax_line_value = (0, 0, {
                'name': tax_account_id.name,
                'debit': total_tax_amount_after_discount,
                'account_id': tax_account_id.id,
                'date': fields.Date.today(),
            })
            tax_line_ids.append(tax_line_value)
            #

        closing_balance_without_tax_amount = 0.0
        closing_balance_tax_amount = 0.0

        for each_payment in cash_payment_method_id:
            matching_account = [item for item in line_ids if item[2][
                'account_id'] == each_payment.payment_method_id.journal_id.default_account_id.id]
            if matching_account:
                if default_account_sale_tax_id:
                    # matching_account[0][2]['credit'] += each_payment.amount - (
                    #             (each_payment.amount / (1 + (tax_rate / 100))) * (tax_rate / 100))
                    # closing_balance_without_tax_amount += each_payment.amount - (
                    #         (each_payment.amount / (1 + (tax_rate / 100))) * (tax_rate / 100))
                    matching_account[0][2]['credit'] += each_payment.amount - each_payment.tax_amount
                    closing_balance_without_tax_amount += each_payment.amount - each_payment.tax_amount
                else:
                    matching_account[0][2]['credit'] += each_payment.amount
                    closing_balance_without_tax_amount += each_payment.amount
            else:
                if default_account_sale_tax_id:
                    line_value = (0, 0, {
                        'name': each_payment.payment_method_id.journal_id.default_account_id.name,
                        # 'credit': each_payment.amount,
                        # 'credit': round(each_payment.amount - ((each_payment.amount / (1 + (tax_rate / 100))) * (tax_rate / 100)),3),
                        'credit': each_payment.amount - each_payment.tax_amount,
                        'account_id': each_payment.payment_method_id.journal_id.default_account_id.id,
                        'date': fields.Date.today(),
                    })
                    line_ids.append(line_value)
                    closing_balance_without_tax_amount += each_payment.amount - each_payment.tax_amount
                    closing_balance_tax_amount += each_payment.tax_amount
                else:
                    line_value = (0, 0, {
                        'name': each_payment.payment_method_id.journal_id.default_account_id.name,
                        'credit': each_payment.amount,
                        'account_id': each_payment.payment_method_id.journal_id.default_account_id.id,
                        'date': fields.Date.today(),
                    })
                    line_ids.append(line_value)
                    closing_balance_without_tax_amount += each_payment.amount
            # For Tax Journal Entry
            if default_account_sale_tax_id:
                matching_tax_account = [item for item in tax_line_ids if item[2][
                    'account_id'] == each_payment.payment_method_id.journal_id.default_account_id.id]
                if matching_tax_account:
                    # matching_tax_account[0][2]['credit'] += (each_payment.amount / (1 + (tax_rate / 100))) * (
                    #         tax_rate / 100)
                    matching_tax_account[0][2]['credit'] += round(each_payment.tax_amount,2)
                else:
                    tax_line_value = (0, 0, {
                        'name': '/',
                        'credit': each_payment.tax_amount,
                        # used the reverse calculation to find the untaxed amount and its tax amount using the tax rate.
                        'account_id': each_payment.payment_method_id.journal_id.default_account_id.id,
                        'date': fields.Date.today(),
                    })
                    tax_line_ids.append(tax_line_value)
                #
        if default_account_sale_tax_id:
            line_value = (0, 0, {
                'name': 'PoS %s Closing Balance Line' % (self.name),
                # 'debit': closing_balance_without_tax_amount + (self.cash_register_balance_start - (self.cash_register_balance_start / (1 + (tax_rate / 100))) * (tax_rate / 100)),  #
                'debit': round(closing_balance_without_tax_amount + (self.cash_register_balance_start - (
                            self.cash_register_balance_start / (1 + (tax_rate / 100))) * (tax_rate / 100)),3),  #
                # 'debit': round(closing_balance_without_tax_amount + (self.cash_register_balance_start - (
                #             self.cash_register_balance_start / (1 + (tax_rate / 100))) * (tax_rate / 100)),3),
                'account_id': debit_account.id,
            })
            line_ids.append(line_value)

            #
            line_value = (0, 0, {
                'name': '/',
                'credit': round(self.cash_register_balance_start - (self.cash_register_balance_start / (1 + (tax_rate / 100))) * (
                            tax_rate / 100),2),
                'account_id': self.custom_default_payment_method_id.journal_id.default_account_id.id,
                'date': fields.Date.today(),
            })
            line_ids.append(line_value)
            #
        else:
            line_value = (0, 0, {
                'name': 'PoS %s Closing Balance Line' % (self.name),
                # 'debit': closing_balance_without_tax_amount + (self.cash_register_balance_start - (self.cash_register_balance_start / (1 + (tax_rate / 100))) * (tax_rate / 100)),  #
                'debit': round(closing_balance_without_tax_amount + self.cash_register_balance_start,2),
                'account_id': debit_account.id,
            })
            line_ids.append(line_value)

            #
            line_value = (0, 0, {
                'name': '/',
                'credit': round(self.cash_register_balance_start,2),
                'account_id': self.custom_default_payment_method_id.journal_id.default_account_id.id,
                'date': fields.Date.today(),
            })
            line_ids.append(line_value)
            #

        move = {
            'name': '',
            'journal_id': main_journal.id,
            'date': fields.Date.today(),
            'ref': 'PoS Closing Balance Entry',
            'line_ids': line_ids,
            'pos_session_id': self.id
        }

        if default_account_sale_tax_id:
            tax_move = {
                'name': '',
                'journal_id': self.env['account.journal'].search([('code', '=', 'MISC')]).id,
                'date': fields.Date.today(),
                'ref': 'Tax Entry',
                'line_ids': tax_line_ids,
                'pos_session_id': self.id
            }
            # For Tax Journal Entry
            tax_move_id = self.env['account.move'].create(tax_move)
            tax_move_id.action_post()

        if line_ids:
            move.update({'line_ids': line_ids})
            move.update({'pos_session_id': self.id})
            move_id = self.env['account.move'].create(move)
            move_id.action_post()
            return move_id

    def action_view_closing_balance(self):
        result = {
            "type": "ir.actions.act_window",
            "res_model": "closing.balance.master",
            "domain": [('pos_session_id', '=', self.id)],
            "name": _("Closing Balance"),
            'view_mode': 'tree,form',
        }
        return result

    # def post_closing_cash_details(self, counted_cash):
    #     res = super(PosSession, self).post_closing_cash_details(counted_cash)
    #     amount = 0
    #     x = 0
    #     for payment in self.payment_method_ids:
    #         if payment.is_cash:
    #             x += 1
    #             if x >= 2:
    #                 for order in self.order_ids:
    #                     if order.payment_ids.payment_method_id == payment:
    #                         for each_payment in order.payment_ids:
    #                             amount += each_payment.amount
    #
    #     # self.ensure_one()
    #     # check_closing_session = self._cannot_close_session()
    #     # if check_closing_session:
    #     #     return check_closing_session
    #
    #     # if not self.cash_journal_id:
    #     #     # The user is blocked anyway, this user error is mostly for developers that try to call this function
    #     #     raise UserError(_("There is no cash register in this session."))
    #
    #     # self.cash_register_balance_end_real = counted_cash + amount
    #     # self.cash_register_total_entry_encoding = amount
    #
    #     # return {'successful': True}
    #     return res

    def post_closing_cash_details(self, counted_cash):
        res = super(PosSession, self).post_closing_cash_details(counted_cash[0])
        self.e_wallet_balance = counted_cash[1]
        self.custom_default_payment_method_id = counted_cash[2]
        return res
