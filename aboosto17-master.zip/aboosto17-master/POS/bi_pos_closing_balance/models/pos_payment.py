from odoo import fields,models


class PosPaymentMethod(models.Model):
    _inherit = 'pos.payment.method'

    is_cash = fields.Boolean(string="Is Cash")


   
class PosPayment(models.Model):
    _inherit = 'pos.payment'

    tax_amount = fields.Float(string="Tax Amount")

    
class PosOrder(models.Model):
    _inherit = "pos.order"
    
    def add_payment(self, data):
        """Create a new payment for the order"""
        self.ensure_one()
        data['tax_amount'] = self.amount_tax
        self.env['pos.payment'].create(data)
        self.amount_paid = sum(self.payment_ids.mapped('amount'))
