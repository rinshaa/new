from odoo import fields,models, api, _

class AccountMove(models.Model):
    _inherit = "account.move"

    pos_session_id = fields.Many2one(
        "pos.session",
        string="PoS Session",
    )