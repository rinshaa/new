from odoo import fields, models


class AccountJournal(models.Model):
    _inherit = "account.journal"

    petty_cash_account_id = fields.Many2one('account.account', 'Petty Cash Account')
