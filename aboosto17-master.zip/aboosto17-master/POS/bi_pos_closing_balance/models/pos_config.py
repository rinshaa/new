from odoo import fields, models, _
from odoo.exceptions import UserError


class PosConfig(models.Model):
    _inherit = "pos.config"

    opening_balance = fields.Float('Minimum Balance')

    # def open_ui(self): # Temporarily commented
    #     latest_session_id = self.session_ids.sorted(key=lambda x: (x.id), reverse=True)[0]
    #     print("latest_session_id___", latest_session_id)
    #     if latest_session_id.cash_register_balance_end_real:
    #         raise UserError(_("You have to update the previous session closing balance."))
    #     return super().open_ui()