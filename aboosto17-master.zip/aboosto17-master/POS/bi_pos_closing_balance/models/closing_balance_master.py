from odoo import fields,models, api, _

class ClosingBalanceMaster(models.Model):
    _name = "closing.balance.master"
    _description = "Closing Balance"
    _inherit = ["mail.thread", "mail.activity.mixin"]

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', _("New")) == _("New"):
                vals['name'] = self.env['ir.sequence'].next_by_code(
                    'closing.balance.master') or _("New")
        return super().create(vals_list)
    
    
    pos_session_id = fields.Many2one(
        "pos.session",
        string="PoS Session",
    )
    name = fields.Char(
        string="Name",
    )
    total_amount = fields.Float('Total Amount')
    company_id = fields.Many2one(
        "res.company",
        string="Company",
        required=True,
    )
    account_move_id = fields.Many2one(
        "account.move",
        string="Journal Entry",
    )


    