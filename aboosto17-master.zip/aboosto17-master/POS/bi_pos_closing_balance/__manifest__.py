{
    'name': " PoS CLOSING BALANCE",
    'depends': ['base', 'point_of_sale'],
    "version": "17.0.1.0",
    "summary": """ Pos CLOSING BALANCE""",
    "description": """Pos CLOSING BALANCE""",
    "author": "Bassam Infotech LLP",
    "company": "Bassam Infotech LLP",
    "maintainer": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "license": "OPL-1",
    "data": [
        "data/ir_sequence.xml",
        "security/ir.model.access.csv",
        "views/closing_balance_master.xml",
        "views/pos_payment.xml",
        "views/pos_session.xml",
        "views/pos_config.xml",
        "views/account_move.xml",
        "views/account_journal.xml",
    ],
    'assets': {
        'point_of_sale._assets_pos': [
            'bi_pos_closing_balance/static/src/js/closing_popup.js'
        ],
    },
}
