from odoo import models


class PosSession(models.Model):
    _inherit = 'pos.session'

    def _process_pos_ui_product_product(self, products):
        for product in products:
            pro_id = product["id"]
            product_id = self.env['product.product'].browse(pro_id)
            product['is_bundle'] = product_id.is_bundle

        return super()._process_pos_ui_product_product(products)