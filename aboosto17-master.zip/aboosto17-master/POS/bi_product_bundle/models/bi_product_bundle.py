from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError
from odoo.tools import float_is_zero, float_compare
from itertools import groupby

class ProductTemplate(models.Model):
    _inherit = 'product.template'

    bundle_product_ids = fields.One2many(
        comodel_name='product.bundle',
        inverse_name='bundle_id',
        string="Bundle Line",copy=True, auto_join=True)
    is_bundle = fields.Boolean('Is Bundled ?')
    # amount_total = fields.Monetary(
    #     string='Total', store=True, readonly=True, compute='_amount_all')

    # @api.depends('bundle_product_ids.price_subtotal')
    # def _amount_all(self):
    #     amount_total = 0.0
    #     for order in self:
    #         if order.bundle_product_ids:
    #             for line in order.bundle_product_ids:
    #                 amount_total += line.price_subtotal
    #             order.amount_total = amount_total

    # def compute_bundle_price(self):
    #     list_price = 0.0
    #     if self.bundle_product_ids:
    #         for bundle_product in self.bundle_product_ids:
    #             list_price += bundle_product.price_subtotal
    #     self.list_price = list_price

    def compute_bundle_cost_price(self):
        standard_price = 0.0
        if self.bundle_product_ids:
            for bundle_product in self.bundle_product_ids:
                standard_price += (bundle_product.cost_price *
                                   bundle_product.qty)
        self.standard_price = standard_price


class Product(models.Model):
    _inherit = 'product.product'

    # def compute_bundle_price(self):
    #     lst_price = 0.0
    #     if self.bundle_product_ids:
    #         for bundle_product in self.bundle_product_ids:
    #             lst_price += bundle_product.price_subtotal
    #     self.lst_price = lst_price

    def compute_bundle_cost_price(self):
        standard_price = 0.0
        if self.bundle_product_ids:
            for bundle_product in self.bundle_product_ids:
                standard_price += (bundle_product.cost_price *
                                   bundle_product.qty)
        self.standard_price = standard_price


class ProductBundle(models.Model):
    _name = 'product.bundle'
    _description = 'Product Bundle'

    def _get_default_product_uom_id(self):
        return self.env['uom.uom'].search([], limit=1, order='id').id

    bundle_id = fields.Many2one('product.template', 'Bundle ID')
    product_id = fields.Many2one(
        'product.product', 'Product', required=True)
    qty = fields.Float("Quantity ")
    uom = fields.Many2one(
        'uom.uom', 'Product Unit of Measure',
        default=_get_default_product_uom_id,
        required=True,
        help="Unit of Measure (Unit of Measure) is the unit of measurement for the inventory control", domain="[('category_id', '=', product_uom_category_id)]")
    product_uom_category_id = fields.Many2one(related='product_id.uom_id.category_id')
    price_unit = fields.Float('Unit Price',compute ="_compute_cost_and_price")
    cost_price = fields.Float('Cost', compute ="_compute_cost_and_price")
    price_subtotal = fields.Float('Sub Total', readonly=True, store=True)
    quant = fields.Float("Quantity", compute ="_compute_quant")

    @api.onchange('product_id')
    def _onchange_product_id(self):
        if self.product_id:
            self.uom = self.product_id.uom_id.id
            self.qty = 1.0
            self.price_unit = self.product_id.list_price
            self.cost_price = self.product_id.standard_price

    @api.depends('uom','product_id','qty')
    def _compute_cost_and_price(self):
        for each in self:
            each.price_unit = each.product_id.list_price / each.uom.factor
            each.cost_price = each.product_id.standard_price / each.uom.factor

    @api.depends('uom','product_id','qty')
    def _compute_quant(self):
        for rec in self:
            rec.quant = rec.qty / rec.uom.factor

    @api.onchange('qty', 'price_unit')
    def get_price_subtotal(self):
        for rec in self:
            rec.price_subtotal = rec.price_unit * rec.qty

class StockPicking(models.Model):
    _inherit='stock.picking'

    # def custome_validate_button(self,src_loc_id):
    #     for each_line in self.move_ids:
    #         if each_line.product_id.is_bundle == True:

    #             prod_bundle = self.env['product.product'].sudo().search([('id','=',each_line.product_id.id),])  
    #             src_location = src_loc_id
    #             destination_location = self.env['stock.location'].sudo().search([("usage", "=", "customer"),], limit=1)
    #             for each in self:
    #                     operation_type_id = self.env['stock.picking.type'].sudo().search([('code', '=', 'outgoing'),('sequence_code','=','OUT'),('company_id','=',each.company_id.id)], limit=1)
    #                     move_ids = [(0, 0, {
    #                         'name': product.product_id.name,
    #                         'product_id': product.product_id.id,
    #                         'product_uom': product.product_id.uom_id.id,
    #                         'quantity': product.qty * each_line.quantity,
    #                         'location_id': src_location,
    #                         'location_dest_id': destination_location.id,
    #                     }) for product in prod_bundle.bundle_product_ids]

    #                     pick = {
    #                         "origin": each.name,
    #                         "picking_type_id": operation_type_id.id,
    #                         "location_id": src_location,
    #                         "location_dest_id": destination_location.id,
    #                         "scheduled_date": each.date,
    #                         "company_id": each.company_id.id,
    #                         'move_ids_without_package': move_ids  
    #                     }
    #                     picking = self.env["stock.picking"].sudo().create(pick)
    #                     picking.sudo().action_confirm()
    #                     picking.sudo().button_validate()
    #     self.button_validate()


    def _create_move_from_pos_order_lines(self, lines):
        res = super(StockPicking, self)._create_move_from_pos_order_lines(lines)
        src_loc_id = lines.order_id.picking_type_id.default_location_src_id.id

        for each_line in self.move_ids:
            if each_line.product_id.is_bundle == True:

                prod_bundle = self.env['product.product'].sudo().search([('id','=',each_line.product_id.id),])  
                src_location = src_loc_id
                destination_location = self.env['stock.location'].sudo().search([("usage", "=", "customer"),], limit=1)
                for each in self:
                        operation_type_id = self.env['stock.picking.type'].sudo().search([('code', '=', 'outgoing'),('sequence_code','=','OUT'),('company_id','=',each.company_id.id)], limit=1)
                        move_ids = [(0, 0, {
                            'name': product.product_id.name,
                            'product_id': product.product_id.id,
                            'product_uom': product.product_id.uom_id.id,
                            'quantity': product.quant * each_line.quantity,
                            'location_id': src_location,
                            'location_dest_id': destination_location.id,
                        }) for product in prod_bundle.bundle_product_ids]

                        pick = {
                            "origin": each.name,
                            "picking_type_id": operation_type_id.id,
                            "location_id": src_location,
                            "location_dest_id": destination_location.id,
                            "scheduled_date": each.date,
                            "company_id": each.company_id.id,
                            'move_ids_without_package': move_ids  
                        }
                        picking = self.env["stock.picking"].sudo().create(pick)
                        picking.sudo().action_confirm()
                        picking.sudo().button_validate()
        self.button_validate()
        return res
    

class ProductTemplate(models.Model):
    _inherit = 'product.template'

    @api.model
    def get_views(self, views, options=None):
        res = super().get_views(views, options=options)
        product_bun = self.env['product.product'].search([('is_bundle','=',True)])
        for each in product_bun:
            stock_quant = self.env['stock.quant'].search([('product_id','=',each.id)])
            for each_quant in stock_quant:
                each_quant.quantity =0 
        return res
    
