// /** @odoo-module **/

// import { patch } from "@web/core/utils/patch";
// import { _t } from "@web/core/l10n/translation";
// import { Order } from "@point_of_sale/app/store/models";
// import { Orderline } from "@point_of_sale/app/store/models";
// import { ErrorPopup } from "@point_of_sale/app/errors/popups/error_popup";

// patch(Order.prototype, {
//     async add_product(product, options) {
//         if (options.quantity >= 0){
//             if (product.qty_available <= 0 && product.type === 'product' && product.is_bundle === false) {
//                 this.pos.env.services.popup.add(ErrorPopup, {
//                     title: _t("Error"),
//                     body: _t("This product is out of stock"),
//                 });
//                 return;
//             }
//         }
//         if (product.is_bundle === true){
//             const bundles = await this.env.services.orm.searchRead('product.bundle',[['bundle_id','=',product.product_tmpl_id]]);
//             for (const bund of bundles) {
//                 console.log("2222222222222222222",bund)
//                 const picking_type = this.pos.config.picking_type_id;
//                 const pic = await this.env.services.orm.searchRead('stock.picking.type',[['id','=',picking_type[0]]]);
//                 const stock = await this.env.services.orm.searchRead('stock.quant',[['product_id','=',bund.product_id[0]],['location_id','=',pic[0].default_location_src_id[0]]]);
//                 if(stock[0]){
//                     console.log("11111111111111",bund.quant)

//                     if (stock[0].available_quantity < bund.quant) {
//                         this.pos.env.services.popup.add(ErrorPopup, {
//                         title: _t("Error"),
//                         body: _t("This product is out of stock"),
//                         });
//                     return;
//                     } 
//                 }
//                 else{
//                     this.pos.env.services.popup.add(ErrorPopup, {
//                     title: _t("Error"),
//                     body: _t("This product is out of stock"),
//                     });
//                 return;
//                 }
//                 }
//             }
        
//         if (
//             this.pos.doNotAllowRefundAndSales() &&
//             this._isRefundOrder() &&
//             (!options.quantity || options.quantity > 0)
//         ) {
//             this.pos.env.services.popup.add(ErrorPopup, {
//                 title: _t("Refund and Sales not allowed"),
//                 body: _t("It is not allowed to mix refunds and sales"),
//             });
//             return;
//         }
//         if (this._printed) {
//             // when adding product with a barcode while being in receipt screen
//             this.pos.removeOrder(this);
//             return await this.pos.add_new_order().add_product(product, options);
//         }
//         this.assert_editable();
//         options = options || {};
//         const quantity = options.quantity ? options.quantity : 1;
//         const line = new Orderline(
//             { env: this.env },
//             { pos: this.pos, order: this, product: product, quantity: quantity }
//         );
//         this.fix_tax_included_price(line);

//         this.set_orderline_options(line, options);
//         line.set_full_product_name();
//         var to_merge_orderline;
//         for (var i = 0; i < this.orderlines.length; i++) {
//             if (this.orderlines.at(i).can_be_merged_with(line) && options.merge !== false) {
//                 to_merge_orderline = this.orderlines.at(i);
//             }
//         }
//         if (to_merge_orderline) {
//             to_merge_orderline.merge(line);
//             this.select_orderline(to_merge_orderline);
//         } else {
//             this.add_orderline(line);
//             this.select_orderline(this.get_last_orderline());
//         }

//         if (options.draftPackLotLines) {
//             this.selected_orderline.setPackLotLines({
//                 ...options.draftPackLotLines,
//                 setQuantity: options.quantity === undefined,
//             });
//         }

//         if (options.comboLines?.length) {
//             await this.addComboLines(line, options);
//             // Make sure the combo parent is selected.
//             this.select_orderline(line);
//         }
//         this.hasJustAddedProduct = true;
//         clearTimeout(this.productReminderTimeout);
//         this.productReminderTimeout = setTimeout(() => {
//             this.hasJustAddedProduct = false;
//         }, 3000);
//         return line;
//     }
// });


