{
    'name': 'BI Product Bundle',
    'summary': ''' BI Product Bundle ''',
    'description': '''BI Product Bundle''',
    'author': 'Bassam Infotech LLP',
    'company': 'Bassam Infotech LLP',
    'maintainer': 'Bassam Infotech LLP',
    'website': 'https://bassaminfotech.com',
    'category': 'stock',
    'depends': ['stock','point_of_sale'],
    'version': '17.0.0.2',
    'data': [
        'views/bi_product_bundle.xml',
        'security/ir.model.access.csv',
        'views/stock_picking.xml',
    ],
    # 'assets': {
    #     'point_of_sale._assets_pos': [
    #        'bi_product_bundle/static/src/xml/bi_product_stock.xml',
    #        'bi_product_bundle/static/src/js/product.js',
    #     ],  
    # },
    'images': [],
    'license': 'OPL-1',
    'installable': True,
    'application': False,
}
