from odoo import api, fields, models
from lxml import etree
from datetime import date,datetime

class PosOrder(models.Model):
    _inherit = "pos.order"

    def search_fetch(self, domain, field_names, offset=0, limit=None, order=None):
        if not self.env.user.has_group("bi_crm_customization.group_sales_manager_crm") and not self.env.user.has_group("bi_crm_customization.group_md_crm"):
            domain += [('user_id', '=', self.env.user.id), ('date_order', '>=', datetime.today().strftime('%Y-%m-%d 00:00:00'))]
        return super(PosOrder, self).search_fetch(domain, field_names, offset, limit, order)
