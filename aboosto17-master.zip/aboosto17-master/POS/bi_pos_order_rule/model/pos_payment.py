from odoo import api, fields, models
from datetime import date,datetime

class PosPayment(models.Model):
    _inherit = "pos.payment"

    def search_fetch(self, domain, field_names, offset=0, limit=None, order=None):
        if not self.env.user.has_group("bi_crm_customization.group_sales_manager_crm") and not self.env.user.has_group("bi_crm_customization.group_md_crm"):
            domain += [('create_uid', '=', self.env.user.id), ('payment_date', '>=', datetime.today().strftime('%Y-%m-%d 00:00:00'))]
        return super(PosPayment, self).search_fetch(domain, field_names, offset, limit, order)