from odoo import api, fields, models
from datetime import date,datetime

class PosSession(models.Model):
    _inherit = "pos.session"

    def search_fetch(self, domain, field_names, offset=0, limit=None, order=None):
        if not self.env.user.has_group("bi_crm_customization.group_sales_manager_crm") and not self.env.user.has_group("bi_crm_customization.group_md_crm"):
            domain += [('user_id', '=', self.env.user.id), ('start_at', '>=', datetime.today().strftime('%Y-%m-%d 00:00:00'))]
        return super(PosSession, self).search_fetch(domain, field_names, offset, limit, order)