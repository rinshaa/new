{
    "name": "BI POS ORDER RULE",
    "version": "17.1",
    "summary": """ POS ORDER RULE""",
    "description": """POS ORDER RULE""",
    "author": "Bassam Infotech LLP",
    "company": "Bassam Infotech LLP",
    "maintainer": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "category": "Tools",
    "depends": ["base","stock","point_of_sale","bi_crm_customization"],
    "data": [
        "security/pos_order_rule.xml",
        "views/pos_order.xml",
        "views/pos_payment.xml"  
    ],
    "images": [],
    "license": "OPL-1",
    "installable": True,
    "application": False,
}
