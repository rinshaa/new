{
    "name": "BI POS Receipt Custom",
    "version": "17.0.0.2",
    "summary": """ POS Custom Receipt""",
    "description": """POS Custom Receipt""",
    "author": "Bassam Infotech LLP",
    "company": "Bassam Infotech LLP",
    "maintainer": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "category": "Tools",
    "depends": ["point_of_sale","pos_loyalty"],
    "images": [],
    "license": "OPL-1",
    "installable": True,
    "application": False,
    'assets': {
        'point_of_sale._assets_pos': [
            'bi_pos_receipt_custom/static/src/**/*',
            'bi_pos_receipt_custom/static/src/xml/order_receipt.xml'
        ],
    },
}
