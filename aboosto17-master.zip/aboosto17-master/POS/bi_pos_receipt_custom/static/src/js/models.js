/** @odoo-module */

import { patch } from "@web/core/utils/patch";
import { Orderline } from "@point_of_sale/app/store/models";
import { PaymentScreen } from "@point_of_sale/app/screens/payment_screen/payment_screen";

patch(Orderline.prototype, {
    async setup() {
        await super.setup(...arguments);
    },
    getDisplayData() {
        return {
            productName: this.get_full_product_name(),
//            price: this.getPriceString(),
            price: this.env.utils.formatCurrency(this.get_price_without_tax(), this.currency),
//            custom_price_without_tax: this.env.utils.formatCurrency(this.get_price_without_tax(), this.currency),
            unitPrice: this.env.utils.formatCurrency(this.get_all_prices(1).priceWithoutTax),
//
            qty: this.get_quantity_str(),
            unit: this.get_unit().name,
//            unitPrice: this.env.utils.formatCurrency(this.get_unit_display_price()),
            oldUnitPrice: this.env.utils.formatCurrency(this.get_old_unit_display_price()),
            discount: this.get_discount_str(),
            customerNote: this.get_customer_note(),
            internalNote: this.getNote(),
            comboParent: this.comboParent?.get_full_product_name(),
            pack_lot_lines: this.get_lot_lines(),
            price_without_discount: this.env.utils.formatCurrency(
                this.getUnitDisplayPriceBeforeDiscount()
            ),
            attributes: this.attribute_value_ids
                ? this.findAttribute(this.attribute_value_ids, this.custom_attribute_value_ids)
                : [],
        };
    }
});

patch(PaymentScreen.prototype, {
    async _postPushOrderResolve(order, server_ids) {
        // Compile data for our function
        const { program_by_id, reward_by_id, couponCache } = this.pos;
        const rewardLines = order._get_reward_lines();
        const partner = order.get_partner();
        let couponData = Object.values(order.couponPointChanges).reduce((agg, pe) => {
            agg[pe.coupon_id] = Object.assign({}, pe, {
                points: pe.points - order._getPointsCorrection(program_by_id[pe.program_id]),
            });
            const program = program_by_id[pe.program_id];
            if (program.is_nominative && partner) {
                agg[pe.coupon_id].partner_id = partner.id;
            }
            agg[pe.coupon_id].date_to = program.date_to;
            return agg;
        }, {});
        for (const line of rewardLines) {
            const reward = reward_by_id[line.reward_id];
            if (!couponData[line.coupon_id]) {
                couponData[line.coupon_id] = {
                    points: 0,
                    program_id: reward.program_id.id,
                    date_to: reward.program_id.date_to,
                    coupon_id: line.coupon_id,
                    barcode: false,
                };
            }
            if (!couponData[line.coupon_id].line_codes) {
                couponData[line.coupon_id].line_codes = [];
            }
            if (!couponData[line.coupon_id].line_codes.includes(line.reward_identifier_code)) {
                !couponData[line.coupon_id].line_codes.push(line.reward_identifier_code);
            }
            couponData[line.coupon_id].points -= line.points_cost;
        }
        // We actually do not care about coupons for 'current' programs that did not claim any reward, they will be lost if not validated
        couponData = Object.fromEntries(
            Object.entries(couponData).filter(([key, value]) => {
                const program = program_by_id[value.program_id];
                if (program.applies_on === "current") {
                    return value.line_codes && value.line_codes.length;
                }
                return true;
            })
        );
        if (Object.keys(couponData || []).length > 0) {
            const payload = await this.orm.call("pos.order", "confirm_coupon_programs_value", [
                server_ids,
                couponData,
            ]);
            if (payload.coupon_updates) {
                for (const couponUpdate of payload.coupon_updates) {
                    let dbCoupon = couponCache[couponUpdate.old_id];
                    if (dbCoupon) {
                        dbCoupon.id = couponUpdate.id;
                        dbCoupon.balance = couponUpdate.points;
                        dbCoupon.code = couponUpdate.code;
                    } else {
                        dbCoupon = new PosLoyaltyCard(
                            couponUpdate.code,
                            couponUpdate.id,
                            couponUpdate.program_id,
                            couponUpdate.partner_id,
                            couponUpdate.points
                        );
                    }
                    delete couponCache[couponUpdate.old_id];
                    couponCache[couponUpdate.id] = dbCoupon;
                }
            }
            // Update the usage count since it is checked based on local data
            if (payload.program_updates) {
                for (const programUpdate of payload.program_updates) {
                    const program = program_by_id[programUpdate.program_id];
                    if (program) {
                        program.total_order_count = programUpdate.usages;
                    }
                }
            }
            if (payload.coupon_report) {
                for (const [actionId, active_ids] of Object.entries(payload.coupon_report)) {
                    await this.report.doAction(actionId, active_ids);
                }
                order.has_pdf_gift_card = Object.keys(payload.coupon_report).length > 0;
            }
            order.new_coupon_info = payload.new_coupon_info;
            order.coupon_code = payload.coupon_code
        }
        return super._postPushOrderResolve(order, server_ids);
    },
});
