{
    "name": "BI POS Enhancements",
    "version": "17.0.0.1",
    "summary": """ POS Enhancements""",
    "description": """POS Enhancements""",
    "author": "Bassam Infotech LLP",
    "company": "Bassam Infotech LLP",
    "maintainer": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "category": "Point of Sale",
    "depends": ["point_of_sale"],
    "data": [
    ],
    "images": [],
    "license": "OPL-1",
    "installable": True,
    "application": False,
    'assets': {
        'point_of_sale._assets_pos': [
            'bi_pos_enhancements/static/src/**/*',
        ],
    },
}
