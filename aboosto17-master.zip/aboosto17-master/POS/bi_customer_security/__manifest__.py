{
    'name': " Pos Customer Security",
    'version': '17.3',
    'depends': ['base', 'point_of_sale'],
    "summary": """ Pos Customer Security""",
    "description": """Pos Customer Security""",
    "author": "Bassam Infotech LLP",
    "company": "Bassam Infotech LLP",
    "maintainer": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "license": "OPL-1",
    'data': [
    ],
    'assets': {
        'point_of_sale._assets_pos': [
            'bi_customer_security/static/src/js/load_file.js',
            'bi_customer_security/static/src/js/partner_details.js',
            'bi_customer_security/static/src/xml/customer_sec.xml',
        ],
    },
}
