/** @odoo-module */

import { PartnerDetailsEdit } from "@point_of_sale/app/screens/partner_list/partner_editor/partner_editor";
import { patch } from "@web/core/utils/patch";
import { _t } from "@web/core/l10n/translation";
import { useState } from "@odoo/owl";

patch(PartnerDetailsEdit.prototype, {
        setup() {
            super.setup(...arguments);
            const partner = this.props.partner;
            this.changes = useState({
            customer_rank: partner.customer_rank || 1,
            })

        },
});