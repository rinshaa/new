{
    "name": "POS Customer Multiple Pricelist",
    "version": "17.0.0.1",
    "summary": """ POS Customer Multiple Pricelist """,
    "description": """POS Customer Multiple Pricelist""",
    "author": "Bassam Infotech LLP",
    "company": "Bassam Infotech LLP",
    "maintainer": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "category": "Point of Sale",
    "depends": ["point_of_sale","web","bi_crm_customization","pos_discount", "base"],
    "data": [
        "views/pricelist_list.xml",
        "views/res_partner_view.xml"
    ],
    'assets': {
        'point_of_sale._assets_pos': [
            'bi_pos_customer_multiple_pricelist/static/src/js/pricelist_button/pricelist_button.js',
            'bi_pos_customer_multiple_pricelist/static/src/js/product_screen/product_screen.js'
        ],
    },
    "images": [],
    "license": "OPL-1",
    "installable": True,
    "application": False,
}
