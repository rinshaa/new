/** @odoo-module */

import { patch } from "@web/core/utils/patch";
import { ProductScreen } from "@point_of_sale/app/screens/product_screen/product_screen";
import { _t } from "@web/core/l10n/translation";

patch(ProductScreen.prototype, {
    getNumpadButtons() {
        this.env.services.user.hasGroup("bi_crm_customization.group_sales_manager_crm")
        .then((value) => {
            this.IsSaleManager = value
        })
        this.env.services.user.hasGroup("bi_crm_customization.group_md_crm")
        .then((value) => {
            this.IsMd = value       
        })
        console.log(this, "security")
        // console.log(this.IsMd,"salesperson")
        return [
            { value: "1" },
            { value: "2" },
            { value: "3" },
            { value: "quantity", text: _t("Qty"), disabled: (!this.IsMd && !this.IsSaleManager) },
            { value: "4" },
            { value: "5" },
            { value: "6" },
            { value: "discount", text: _t("% Disc"), disabled: !this.pos.config.manual_discount || (!this.IsMd && !this.IsSaleManager)},
            { value: "7" },
            { value: "8" },
            { value: "9" },
            { value: "price", text: _t("Price"), disabled: !this.pos.cashierHasPriceControlRights() || (!this.IsMd && !this.IsSaleManager)},
            { value: "-", text: "+/-" },
            { value: "0" },
            { value: this.env.services.localization.decimalPoint },
            // Unicode: https://www.compart.com/en/unicode/U+232B
            { value: "Backspace", text: "⌫" },
        ].map((button) => ({
            ...button,
            class: this.pos.numpadMode === button.value ? "active border-primary" : "",
        }));
    }

});




 