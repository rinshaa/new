/** @odoo-module */

    import { SetPricelistButton } from "@point_of_sale/app/screens/product_screen/control_buttons/pricelist_button/pricelist_button";
    import { patch } from "@web/core/utils/patch";
    import { _t } from "@web/core/l10n/translation";
    import { SelectionPopup } from "@point_of_sale/app/utils/input_popups/selection_popup";


    patch(SetPricelistButton.prototype, {
        async click() {
        //        const result = super.click(...arguments);
        //        console.log("result____", result)
        const selectionList = this.pos.pricelists.map((pricelist) => ({
            id: pricelist.id,
            label: pricelist.name,
            date_start: pricelist.date_start,
            isSelected: this.currentOrder.pricelist && pricelist.id === this.currentOrder.pricelist.id,
            item: pricelist,
        }));
        const order = this.pos.get_order()
        const partner = order.get_partner()

        if (partner !== null) {
            console.log()
            const partner_pricelists = partner.pricelist_ids
            const idSet = new Set(partner_pricelists);
            const filteredData = selectionList.filter(obj => idSet.has(obj.id) && obj.item.is_available_today === true);
            filteredData.push({
            id: null,
            label: _t("Default Price"),
            isSelected: !this.currentOrder.pricelist,
            item: null,
            });

            if (!this.pos.default_pricelist) {
                selectionList.push({
                  id: null,
                  label: _t("Default Price"),
                  isSelected: !this.currentOrder.pricelist,
                  item: null,
                });
            }

            const { confirmed, payload: selectedPricelist } = await this.popup.add(SelectionPopup, {
                title: _t("Select the pricelist"),
                //            list: selectionList,
                list: filteredData,
            });

            if (confirmed) {
            this.currentOrder.set_pricelist(selectedPricelist);
            }
        }
        else {
          return result = super.click(...arguments);
        }
        }

    });


