from odoo import fields, models,api
from odoo.tools import float_compare, float_is_zero


class ResPartner(models.Model):
    _inherit = 'res.partner'

    pricelist_ids = fields.Many2many('product.pricelist', string='Pricelists')

    @api.depends('country_id')
    @api.depends_context('company')
    def _compute_product_pricelist(self):
        res = super()._compute_product_pricelist()
        for partner in self:
            if partner.pricelist_ids:
                partner.property_product_pricelist = partner.pricelist_ids.ids[0]
            else:
                partner.property_product_pricelist = False
        return res
    
    # commented on 25/09/24 - new company created this code blocks
    # @api.model
    # def default_get(self, fields_list):
    #     defaults = super(ResPartner,self).default_get(fields_list)
    #     defaults['company_id'] = self.env.company.id
    #     return defaults
