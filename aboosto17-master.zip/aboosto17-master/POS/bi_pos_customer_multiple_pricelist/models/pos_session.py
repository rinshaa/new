from odoo import api, fields, models, _, Command


class PosSession(models.Model):
    _inherit = 'pos.session'

    def _loader_params_res_partner(self):
        res = super(PosSession, self)._loader_params_res_partner()
        res['search_params']['fields'].append('pricelist_ids')
        return res

    def _loader_params_product_pricelist(self):
        res = super(PosSession, self)._loader_params_product_pricelist()
        # res['search_params']['fields'].append('date_start')
        # res['search_params']['fields'].append('date_end')
        res['search_params']['fields'].append('is_available_today')
        return res
