from odoo import fields, models,api


class ResCompany(models.Model):
    _inherit = 'res.company'

    @api.model_create_multi
    def create(self, vals_list):
        new_company = super(ResCompany, self).create(vals_list)
        if not new_company:
            raise ValueError("Failed to create the company.")
        partner_model = self.env['res.partner'].with_company(new_company)
        partner_vals = {
            'name': new_company.name,
            'company_id': new_company.id,
        }
        partner_model.create(partner_vals)
        return new_company