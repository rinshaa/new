from collections import defaultdict
from odoo import fields, models, api
from datetime import datetime


class ProductPricelist(models.Model):
    _inherit = 'product.pricelist'

    date_start = fields.Date(
        string="Start Date",
        help="Starting datetime for the pricelist item validation\n"
             "The displayed value depends on the timezone set in your preferences.")
    date_end = fields.Date(
        string="End Date",
        help="Ending datetime for the pricelist item validation\n"
             "The displayed value depends on the timezone set in your preferences.")

    is_available_today = fields.Boolean(string='Is Available Today', compute='_compute_is_available_today')

    @api.depends('date_start', 'date_end')
    def _compute_is_available_today(self):
        for rec in self:
            if rec.date_start and rec.date_end and rec.date_start <= datetime.today().date() and rec.date_end >= datetime.today().date():
                rec.is_available_today = True
            elif not rec.date_start and not rec.date_end:
                rec.is_available_today = True
            else:
                rec.is_available_today = False
