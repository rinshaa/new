from . import product_pricelist
from . import res_partner
from . import pos_session
from . import res_company
