/** @odoo-module */

import { ProductCard } from "@point_of_sale/app/generic_components/product_card/product_card";
import { patch } from "@web/core/utils/patch";
import { onWillStart } from "@odoo/owl";

patch(ProductCard.prototype, {
    setup() {
        super.setup();
        onWillStart(async () => {
            this.hasGroupAnalyticManager = await this.env.services.user.hasGroup("bi_crm_customization.group_sales_manager_crm");
            this.hasGroupAnalyticBillingAdministrator = await this.env.services.user.hasGroup("account.group_account_manager")
        });
    }


}) 