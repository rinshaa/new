Version 16.0.0.1 : (06/04/2023)
   -- When we create pos order at that time get an error "product is not iterable" fixed that issue.

Version 16.0.0.2 : (26/07/2023)
Improvements:
1)Set the Stock position to your liking.
2)​Customize POS stock presentation with your company colors or your preference
3)​Low Product stock can see in POS Screen
4)Users can total the number of items of pos order


Version 16.0.0.3 : (03/08/23)
Improvements:
-Remove outgoing qty and incoming qty from Stock Type selection field and remove functionality related to it which is available on the pos configuration screen

=> 16.0.0.4 : Improved an index as per latest improvements.

Version 16.0.0.5 : (28/08/23)
   -While click on product that time double quantity was add in cart so solved that issue.

Version 16.0.0.6 : (29/08/23)
   -Solved issue while click on the pay button.

Version 16.0.0.7 : (01/09/23)
   -Solved Issue while open pos restaurant.
