{
    "name": "POS Stock in Odoo",
    "version": "17.0.0.4",
    "depends": ['base', 'stock', 'point_of_sale',"bi_crm_customization"],
    # "depends": ['base', 'stock', 'point_of_sale',"bi_crm_customization", "bi_product_bundle"],
    'summary': 'Display POS Stock Quantity on POS screen stock Product stock in POS product stock Quantity POS Order stock POS Mobile POS Inventory management pos stocks pos item stock point of sale stock POS Product Warehouse Quantity pos product qty pos product Quantity',
    "author": "Bassam Infotech LLP",
    "company": "Bassam Infotech LLP",
    "maintainer": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "category": "Point of Sale",
    "data": [
    ],
    'assets': {
        'point_of_sale._assets_pos': [
           'bi_pos_stock/static/src/xml/bi_pos_stock.xml',
           'bi_pos_stock/static/src/xml/bi_product_stock.xml',
           'bi_pos_stock/static/src/xml/bi_pos_heading.xml',
           'bi_pos_stock/static/src/js/pos_loading.js',
           'bi_pos_stock/static/src/js/product.js',
           'bi_pos_stock/static/src/js/ProductCard.js',


        ],
    },

    "auto_install": False,
    "installable": True,
    'license': 'OPL-1',
}
