from odoo import models


class PosSession(models.Model):
    _inherit = 'pos.session'

    def _process_pos_ui_product_product(self, products):
        for product in products:
            location = self.config_id.picking_type_id.default_location_src_id
            pro_id = product["id"]
            product_id = self.env['product.product'].browse(pro_id)
            quantity = product_id.with_context({"location": location.id}).sudo().free_qty
            product['qty_available'] = quantity 


        return super()._process_pos_ui_product_product(products)