from odoo import fields, models


class AccountJournal(models.Model):
    _inherit = 'account.journal'

    def get_account_journal_ids(self):
        account_journal_ids = self.env['account.journal'].search([])
        if self.env.user.pos_config_ids:
            account_journal_ids = self.env.user.pos_config_ids.journal_id + self.env.user.pos_config_ids.payment_method_ids.journal_id
        return account_journal_ids

    def write(self, values):
        res = super().write(values)
        self.env['ir.rule'].clear_caches()
        return res
