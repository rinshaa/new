# -*- coding: utf-8 -*-

from collections import defaultdict
from odoo import fields, models, api


class PosSession(models.Model):
    _inherit = 'pos.session'

    def try_cash_in_out(self, _type, amount, reason, extras):
        if _type == 'out':
            context = self.env.context.copy()
            # context.update({'from_pos_cash_out': True})
            context.update({'expense_account_account': extras.get('expense_account_account')})
            self.env.context = context
        return super().try_cash_in_out(_type, amount, reason, extras)

    def _pos_ui_models_to_load(self):
        result = super()._pos_ui_models_to_load()
        new_model = 'account.account'
        if new_model not in result:
            result.append(new_model)
        return result

    def _loader_params_account_account(self):
        return {
            'search_params': {
                'domain': [('account_type', '=', 'expense')],
                'fields': [
                    'name', 'code', 'account_type',
                ],
            },
        }

    def _get_pos_ui_account_account(self, params):
        return self.env['account.account'].search_read(**params['search_params'])
