# -*- coding: utf-8 -*-

from collections import defaultdict
from odoo import fields, models,api


class AccountBankStatementLine(models.Model):
    _inherit = 'account.bank.statement.line'

    def _prepare_move_line_default_vals(self, counterpart_account_id=None):
        context = self.env.context.copy()
        # if context.get('from_pos_cash_out') and self.journal_id.pos_expense_account_id:
        #     counterpart_account_id = self.journal_id.pos_expense_account_id.id
        if context.get('expense_account_account'):
            counterpart_account_id = self.env['account.account'].browse(int(context.get('expense_account_account'))).id
        return super()._prepare_move_line_default_vals(counterpart_account_id)
