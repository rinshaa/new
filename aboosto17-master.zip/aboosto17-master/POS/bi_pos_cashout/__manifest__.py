{
    "name": "BI POS Cash out",
    "version": "17.0.0.1",
    "summary": """ POS Cash out entry customised""",
    "description": """POS Cash out entry customised""",
    "author": "Bassam Infotech LLP",
    "company": "Bassam Infotech LLP",
    "maintainer": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "category": "Tools",
    "depends": ["account", "point_of_sale","base"],
    "data": [
    ],
    "images": [],
    "license": "OPL-1",
    "installable": True,
    "application": False,
    'assets': {
        'point_of_sale._assets_pos': [
            'bi_pos_cashout/static/src/**/*',
        ],
    },
}
