from odoo import fields,models,api


class LoyaltyReward(models.Model):
    _inherit = 'loyalty.reward'

    def get_reward_percentage(self,product_id):
        if self.reward_type == 'discount' and self.discount_applicability == 'all_product':
            reward_percentage = self.discount
            return reward_percentage
        if self.reward_type == 'discount' and self.discount_applicability == 'specific':
            product_list = self.discount_product_ids.ids
            if product_id in product_list:
                reward_percentage = self.discount
                return reward_percentage
            else:
                return False
        else:
            return False

            
