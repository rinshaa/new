{
    "name": "POS Refund Discount",
    "version": "17.0.1.0.0",
    "summary": """ POS Refund Discount""",
    "description": """POS Refund Discount""",
    "author": "Bassam Infotech LLP",
    "company": "Bassam Infotech LLP",
    "maintainer": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "category": "Tools",
    "depends": ["loyalty", 'point_of_sale', 'pos_loyalty'],
    "data": [
    ],

    'assets': {
        'point_of_sale._assets_pos': [
            'bi_pos_refund_discount/static/src/js/ticket_screen.js',
        ],
    },
    
    "images": [],
    "license": "OPL-1",
    "installable": True,
    "application": False,
}
