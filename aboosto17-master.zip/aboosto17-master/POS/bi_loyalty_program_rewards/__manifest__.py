
{
    "name": "Custom Loyalty Program Rewards",
    "version": "17.0.0.7",
    "summary": """ Custom Loyalty Program Rewards""",
    "description": """Custom Loyalty Program Rewards""",
    "author": "Bassam Infotech LLP",
    "company": "Bassam Infotech LLP",
    "maintainer": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "category": "Tools",
    "depends": ["base","loyalty",'point_of_sale','pos_loyalty','product'],
    "data": [
            # "security/ir.model.access.csv",
            "views/loyalty_program.xml",
            "views/loyalty_reward.xml",
    ],

    'assets': {
        'point_of_sale._assets_pos':[
            'bi_loyalty_program_rewards/static/src/js/loyalty.js'
        ],
    },
    
    "images": [],
    "license": "OPL-1",
    "installable": True,
    "application": False,
}
