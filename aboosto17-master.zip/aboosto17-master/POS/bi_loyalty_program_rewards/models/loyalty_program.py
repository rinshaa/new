from odoo import fields,models,api


class LoyaltyReward(models.Model):
    _inherit = 'loyalty.reward'
    _description = 'Loyalty Reward'

    discount_applicability = fields.Selection(
        selection_add=[
            ("all_product", "All Products"),
        ]
    )
    all_product = fields.Char(string="All Discounted Products")
    
    @api.onchange('discount_applicability')
    def onchange_discount_applicability(self):
        for reward in self:
            if reward.reward_type == 'discount':
                if reward.discount_applicability == 'all_product':
                    product_available = self.env['product.product'].search([('company_id','=', self.env.company.id)])
                    # domain = reward._get_discount_product_domain()
                    reward.discount_product_ids = [(6, 0, product_available.ids)]
                    reward.all_product = "All Products"
                else:
                    reward.discount_product_ids =  False


class ProductProduct(models.Model):
    _inherit = 'product.product'

    @api.model_create_multi
    def create(self, vals_list):
        product = super(ProductProduct, self).create(vals_list)
        loyalty_rewards = self.env['loyalty.reward'].search([('discount_applicability', '=', 'all_product')])
        for products in product:
            for reward in loyalty_rewards:
                if products.company_id == reward.company_id:
                    reward.discount_product_ids = [(4, products.id)]
        return product
    
    
        