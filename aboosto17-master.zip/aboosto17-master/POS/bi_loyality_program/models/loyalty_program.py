from odoo import models, fields, api
from datetime import date, timedelta,datetime
from odoo.tools.date_utils import start_of, end_of
from odoo.exceptions import ValidationError  

class LoyaltyProgram(models.Model):
    
    _inherit = "loyalty.program"
    
    
    loyalty_line_ids = fields.One2many('loyalty.program.dates','loyalty_program_id',string = "Relation")
    
    coupon_expire_date = fields.Char(string = "Set Coupon Expire", required=True )
    
    
    @api.constrains('coupon_expire_date')
    def _check_coupon_expire_date(self):
        for record in self:
            if not record.coupon_expire_date.isdigit():
                raise ValidationError("Coupon expiry date should contain only numbers.")
    
    
    def change_date(self):
        program = self.env['loyalty.program'].search([])
        current_date = fields.Date.today()
        for rec in program:
            for line in rec.loyalty_line_ids:
                if line.date_end and line.date_start:
                    if line.date_start <= current_date and current_date <= line.date_end:
                        date_start = line.date_start
                        date_end = line.date_end
                        if not rec.date_from and not rec.date_to:
                            rec.date_from = date_start
                            rec.date_to = date_end
                            break
                        elif (rec.date_from != date_start or rec.date_to != date_end) and rec.date_to < current_date:
                            rec.date_from = None
                            rec.date_to = None
                            rec.date_from = date_start
                            rec.date_to = date_end
                            break
                    else:
                        rec.date_from = None
                        rec.date_to = None
                    if rec.date_from == False and rec.date_to == False:        
                        rec.date_from =  line.date_start
                    rec.date_to = line.date_end        
        
                            
                