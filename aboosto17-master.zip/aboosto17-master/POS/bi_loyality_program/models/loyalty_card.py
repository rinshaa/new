from odoo import models, fields, api 
from datetime import date, timedelta,datetime
from dateutil.relativedelta import relativedelta 

class LoyaltyCard(models.Model):
    _inherit = "loyalty.card"
    

    
    """ Override of the create method to automatically set a default value for the card number if not provided by the user"""
    @api.model_create_multi
    def create(self,vals_list):
        res = super(LoyaltyCard,self).create(vals_list)
        for record in res:
            program = self.env['loyalty.program'].search([('id','=',record.program_id.id)])
            coupon_expiry_date = int(program.coupon_expire_date)
            current_date = fields.Date.today()
            expiration_date = current_date + relativedelta(days=coupon_expiry_date)
            record.expiration_date = expiration_date
        
        return res
        
        