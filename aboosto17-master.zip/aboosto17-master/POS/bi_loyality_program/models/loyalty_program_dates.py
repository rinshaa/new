from odoo import models, fields 
from datetime import date, timedelta,datetime

class LoyaltyProgramDates(models.Model):
    
    _name = "loyalty.program.dates"
    _description ="Loyalty Program Dates"
    
    program_name = fields.Char(string = "Program Name")
    
    date_start = fields.Date(string = "Start-Date")
    
    date_end = fields.Date(string = "End-Date")
    
    loyalty_program_id = fields.Many2one('loyalty.program',string = "Relation-loyalty")