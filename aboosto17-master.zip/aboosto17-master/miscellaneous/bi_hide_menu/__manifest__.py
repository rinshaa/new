{
    'name': " hide menu ",
    'depends': ['crm','point_of_sale','stock','sale_management','purchase','account_accountant'],
    "version": "17.3",
    "summary": """ hide menu reporting and configuration""",
    "description": """Hide Menu""",
    "author": "Bassam Infotech LLP",
    "company": "Bassam Infotech LLP",
    "maintainer": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "license": "OPL-1",
    "data": [
        'security/security.xml',
        'views/hide_menu.xml'

    ],
}
