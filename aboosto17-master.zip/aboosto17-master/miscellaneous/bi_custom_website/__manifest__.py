{
    'name': 'Custom Website Module',
    'version': '17.0.3.0.1',
    'category': 'Website',
    'summary': 'Customizations for the Odoo Website',
    'description': 'This module adds customizations to the Odoo website.',
    "author": "Bassam Infotech LLP",
    "company": "Bassam Infotech LLP",
    "maintainer": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    'depends': ['base','website','product','website_sale'],
    'data': [
        "data/custom_menu.xml",
        "views/product_category.xml",
        # "views/templates.xml"
    ],
    'license': 'OPL-1',
    'installable': True,
    'auto_install': False,
    'application': False,
}