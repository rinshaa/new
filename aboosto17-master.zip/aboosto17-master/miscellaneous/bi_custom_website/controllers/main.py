from odoo import http
from odoo.http import request


class ProductFilterController(http.Controller):

    @http.route(['/brand', '/brand/<model("product.brand"):brand>'], type='http', auth="public", website=True)
    def brand_filter(self, brand=None, **kwargs):
        company_id = request.env.company.id
        Product = request.env['product.template'].sudo()
        Brands = request.env['product.brand'].sudo()
        brand_product_count = {b.id: Product.search_count([('brand_id', '=', b.id)])  for b in Brands}
        domain = [('is_published', '=', True)]
        # domain = []

        if brand:
            domain.append(('brand_id', '=', brand.id))
        domain.append(('company_id', '=', company_id))

        brands = Brands.sudo().search([], limit=100)
        if domain:
            products = Product.sudo().search(domain, limit=100)
        else:
            products = Product.sudo().search([('company_id','=', company_id)], limit=100)


        return request.render("bi_custom_website.template_brand_filter", {
            'products': products,
            'brands': brands,
            'brand': brand,
            'brand_product_count': brand_product_count,
        })


    @http.route(['/category', '/category/<model("product.category"):category>'], type='http', auth="public",
                website=True)
    def category_filter(self, category=None, **kwargs):
        company_id = request.env.company.id
        Product = request.env['product.template'].sudo()
        Categories = request.env['product.category'].sudo()
        domain = [('is_published', '=', True)]
        # domain = []

        if category:
            domain.append(('categ_id', '=', category.id))
        domain.append(('company_id', '=', company_id))

        categories = Categories.sudo().search([('is_default', '=', False)], limit=100)
        if domain:
            products = Product.sudo().search(domain, limit=100)
        else:
            products = Product.sudo().search([('company_id','=', company_id)], limit=100)
            
        category_product_count = {c.id: Product.search_count([('categ_id', '=', c.id)]) for c in categories}

        return request.render("bi_custom_website.template_category_filter", {
            'products': products,
            'categories': categories,
            'category': category,
            'category_product_count': category_product_count,
        })