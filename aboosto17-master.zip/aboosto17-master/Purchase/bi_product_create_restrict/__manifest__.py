{
    "name": "Product Create Restrict",
    "summary": """ The purpose of this module is to restrict the product creation only for a particular user group. """,
    "description": """Product Create Restriction""",
    "author": "Bassam Infotech LLP",
    "company": "Bassam Infotech LLP",
    "maintainer": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "category": "Purchase",
    "depends": ["purchase","product","account","stock"],
    "version": "17.0.0.0",
    "data": [
        "security/security.xml",
    ],
    "images": [],
    "license": "OPL-1",
    "installable": True,
    "application": False,
}