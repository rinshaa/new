from odoo import models, api
from lxml import etree


class ProductTemplate(models.Model):
    _inherit = "product.template"
    
    @api.model
    def get_views(self, views, options=None):
        res = super().get_views(views, options)
        views_type = ['form', 'kanban', 'list']
        for type in views_type:
            arch = res['views'].get(type, {}).get('arch')
            if type == 'list':
                type='tree'
            if arch:
                if self.user_has_groups('bi_product_create_restrict.group_product_create_access'):
                    tree = etree.fromstring(arch)
                    for node in tree.xpath('//'+type):
                        node.set('create', 'true')
                        node.set('edit', 'true')
                    arch = etree.tostring(tree, encoding='unicode')
                    if type == 'tree':
                        type='list'
                else:
                    tree = etree.fromstring(arch)
                    for node in tree.xpath('//'+type):
                        node.set('create', 'false')
                        node.set('edit', 'false')
                    arch = etree.tostring(tree, encoding='unicode')
                    if type == 'tree':
                        type='list'
                res['views'][type]['arch'] = arch
        return res