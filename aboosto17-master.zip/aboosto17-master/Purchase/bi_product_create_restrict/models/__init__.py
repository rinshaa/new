from . import product_template
from . import purchase_order
from . import stock_picking
from . import account_move