from odoo import models, api
from lxml import etree


class PurchaseOrder(models.Model):
    _inherit = "purchase.order"

    @api.model
    def get_views(self, views, options=None):
        res = super().get_views(views, options=options)
        if "form" in res["views"]:
            arch = res["views"]["form"]["arch"]
            doc = etree.fromstring(arch)
            if not self.user_has_groups('bi_product_create_restrict.group_product_create_access'):
                for node in doc.xpath("//sheet/notebook/page/field/tree/field"):
                    if node.attrib["name"] in ["product_id"]:
                        node.attrib["options"] = '{"no_create": true, "no_edit": true}'
                        arch = etree.tostring(doc, encoding="unicode")
                res["views"]["form"]["arch"] = arch
            
        return res