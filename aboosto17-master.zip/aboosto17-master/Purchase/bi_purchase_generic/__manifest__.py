{
    "name": "Purchase Generic Customisation",
    "summary": """ Purchase Generic Customisation""",
    "description": """Purchase Customisation""",
    "author": "Bassam Infotech LLP",
    "company": "Bassam Infotech LLP",
    "maintainer": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "category": "Purchase",
    "depends": ["purchase"],
    "version": "17.0",
    "data": [
        "views/purchase_order.xml",

    ],
    "images": [],
    "license": "OPL-1",
    "installable": True,
    "application": False,
}
