from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError
from datetime import date


class CompanyExpense(models.Model):
    _name = "company.expense"
    _description = "Inter-Company Expense"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _rec_name = "name"

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("name", _("New")) == _("New"):
                if "company_id" in vals:
                    vals["name"] = self.env["ir.sequence"].with_context(force_company=vals["company_id"]).next_by_code(
                        "company.expense.seq.code"
                    ) or _("New")
                else:
                    vals["name"] = self.env["ir.sequence"].next_by_code("company.expense.seq.code") or _("New")
        result = super(CompanyExpense, self).create(vals_list)
        return result

    @api.constrains("request_from_company_id", "request_to_company_id")
    def _check_request_company(self):
        for vals in self:
            if vals.request_from_company_id.id == vals.request_to_company_id.id:
                raise ValidationError(_('You cannot select same company in "Requested From" and "Requested To" .'))

    name = fields.Char("Name", default="New", copy=False, index=True)
    request_from_company_id = fields.Many2one("res.company", "Request From", tracking=True)
    request_to_company_id = fields.Many2one("res.company", "Request To", tracking=True)
    remarks = fields.Char(string="Remarks", tracking=True)
    state = fields.Selection(
        [
            ("draft", "Draft"),
            ("submitted", "Request Submitted"),
            ("approved", "Approved"),
            ("payment_sent", "Payment Sent"),
            ("payment_received", "Payment Received"),
            ("reject", "Reject"),
            ("cancel", "Cancelled"),
        ],
        string="Status",
        index=True,
        default="draft",
        store=True,
        tracking=True,
        help=" * Draft: not confirmed yet and will not be scheduled until confirmed\n"
        " * Cancelled: has been cancelled, can't be confirmed anymore",
    )
    request_date = fields.Datetime(string="Date", required=True, tracking=True, default=fields.Datetime.now)
    approved_by_id = fields.Many2one("res.users", string="Approved User", tracking=True)
    requested_by_id = fields.Many2one(
        "res.users", string="Requested By", copy=False, default=lambda self: self.env.user, tracking=True
    )
    request_expense_amount = fields.Float(string="Requested Expense Amount", tracking=True)
    approved_expense_amount = fields.Float(string="Approved Expense Amount", tracking=True)
    currency_id = fields.Many2one(
        "res.currency",
        "Expense Amount Currency",
        related="request_to_company_id.currency_id",
        readonly=False,
        tracking=True,
    )
    reject_reason = fields.Char(string="Reject Reason", tracking=True)
    request_date = fields.Datetime(string="Date", required=True, tracking=True, default=fields.Datetime.now)
    rejected_by_id = fields.Many2one("res.users", string="Rejected By", copy=False, tracking=True)
    account_move_id = fields.Many2one("account.move", string="Account Move")
    # request_from_company_account
    credit_account_id = fields.Many2one("account.account", string="Credit Account")
    # request_to_company_account
    debit_account_id = fields.Many2one("account.account", string="Debit Account")
    journal_id = fields.Many2one("account.journal", string="Journal")
    account_move_count = fields.Integer("Related Journal Entry Count", compute="_compute_account_move_count")

    account_payment_send_id = fields.Many2one("account.payment", string="Account Payment")
    account_payment_received_id = fields.Many2one("account.payment", string="Account Payment")
    send_journal_id = fields.Many2one("account.journal", string="Sending Journal")
    receive_journal_id = fields.Many2one("account.journal", string="Receiving Journal")
    send_destination_journal_id = fields.Many2one("account.journal", string="Sending Destination Journal")
    receive_destination_journal_id = fields.Many2one("account.journal", string="Receiving Destination Journal")

    account_payment_sent_count = fields.Integer("Sent Payment Count", compute="_compute_account_payment_count")
    account_payment_received_count = fields.Integer("Received Payment Count", compute="_compute_account_payment_count")

    payment_sent_by_id = fields.Many2one("res.users", string="Payment Sent By", tracking=True)
    payment_received_by_id = fields.Many2one("res.users", string="Payment Received By", tracking=True)

    def _compute_account_payment_count(self):
        account_payment_sent_obj = (
            self.env["account.payment"]
            .sudo()
            .search_count([("company_expense_id", "=", self.id), ("company_id", "=", self.request_to_company_id.id)])
        )
        account_payment_received_obj = (
            self.env["account.payment"]
            .sudo()
            .search_count([("company_expense_id", "=", self.id), ("company_id", "=", self.request_from_company_id.id)])
        )
        self.account_payment_sent_count = account_payment_sent_obj
        self.account_payment_received_count = account_payment_received_obj

    def view_account_payment_sent(self):
        return {
            "name": "Payment Sent",
            "type": "ir.actions.act_window",
            "res_model": "account.payment",
            "view_mode": "list,form",
            "domain": [("company_expense_id", "=", self.id), ("company_id", "=", self.request_to_company_id.id)],
        }

    def view_account_payment_received(self):
        return {
            "name": "Payment Received",
            "type": "ir.actions.act_window",
            "res_model": "account.payment",
            "view_mode": "list,form",
            "domain": [("company_expense_id", "=", self.id), ("company_id", "=", self.request_from_company_id.id)],
        }

    def _compute_account_move_count(self):
        account_move_obj = self.env["account.move"].sudo().search_count([("company_expense_id", "=", self.id)])
        self.account_move_count = account_move_obj

    def view_account_move(self):
        return {
            "name": "Journal Entry",
            "type": "ir.actions.act_window",
            "res_model": "account.move",
            "view_mode": "list,form",
            "domain": [("company_expense_id", "=", self.id)],
        }

    def unlink(self):
        for transfer in self:
            if transfer.state not in ("draft", "cancel"):
                raise UserError(_("Cannot delete requests which are already confirmed."))
        return super(CompanyExpense, self).unlink()

    def button_submit_request(self):
        if self.request_from_company_id.id != self.env.user.company_id.id:
            raise UserError(_("You don't have a permission to Submit a Request.Please contact an Administrator."))
        if self.request_expense_amount <= 0:
            raise UserError(_("Please enter the Requested Expense Amount before proceeding."))
        self.write({"state": "submitted"})

    def button_cancel_request(self):
        self.write({"state": "cancel"})

    def button_reject_request(self):
        ctx = dict(
            **self.env.context,
            default_company_expense_id=self.id,
        )
        return {
            "name": _("Expense Reject"),
            "type": "ir.actions.act_window",
            "view_mode": "form",
            "res_model": "company.expense.reject.wizard",
            "view_id": self.env.ref("bi_company_expense.company_expense_reject_wizard_view").id,
            "target": "new",
            "context": ctx,
        }

    # def button_approve_request(self):
    #     if self.approved_expense_amount <= 0:
    #         raise UserError(_("Please enter the Approved Expense Amount before proceeding."))
    #     if self.approved_expense_amount > self.request_expense_amount:
    #         raise UserError(_("Approved Expense Amount cannot be greater than the Request Expense Amount"))
    #     current_user = self.env.user
    #     timenow = date.today()
    #     for expense in self:
    #         amount = expense.approved_expense_amount
    #         converted_amount = expense.currency_id._convert(
    #                     amount,
    #                     expense.request_from_company_id.currency_id,
    #                     expense.request_from_company_id,
    #                     expense.request_date or fields.Date.today(),
    #                 )

    #         expense_name = expense.name
    #         reference = expense.name
    #         journal_id = expense.journal_id.id
    #         debit_account_id = expense.debit_account_id.id
    #         credit_account_id = expense.credit_account_id.id
    #         debit_vals = {
    #             'name': expense_name,
    #             'account_id': debit_account_id,
    #             'journal_id': journal_id,
    #             'date': timenow,
    #             'amount_currency':amount,
    #             'debit': converted_amount > 0.0 and converted_amount or 0.0,
    #             'credit': converted_amount < 0.0 and -converted_amount or 0.0,
    #             'company_expense_id': expense.id,
    #             'currency_id': expense.currency_id.id
    #         }
    #         credit_vals = {
    #             'name': expense_name,
    #             'account_id': credit_account_id,
    #             'journal_id': journal_id,
    #             'date': timenow,
    #             'amount_currency':-amount,
    #             'debit': converted_amount < 0.0 and -converted_amount or 0.0,
    #             'credit': converted_amount > 0.0 and converted_amount or 0.0,
    #             'company_expense_id': expense.id,
    #             'currency_id': expense.currency_id.id
    #         }
    #         vals = {
    #             'name': 'Expense' + '-' + expense_name,
    #             'narration': expense_name,
    #             'ref': reference,
    #             'journal_id': journal_id,
    #             'date': timenow,
    #             'company_expense_id': expense.id,
    #             'currency_id': expense.currency_id.id,
    #             'company_id': expense.request_to_company_id.id,
    #             'line_ids': [(0, 0, debit_vals), (0, 0, credit_vals)]
    #         }
    #         move = self.env['account.move'].sudo().create(vals)
    #         move.action_post()
    #     self.write({"state": "approved","approved_by_id": current_user.id, 'account_move_id': move.id })

    def button_send_payment_request(self):
        if self.request_to_company_id.id != self.env.user.company_id.id:
            raise UserError(_("You don't have a permission to Send Payment.Please contact an Administrator."))
        if self.approved_expense_amount <= 0:
            raise UserError(_("Please enter the Approved Expense Amount before proceeding."))
        if self.approved_expense_amount > self.request_expense_amount:
            raise UserError(_("Approved Expense Amount cannot be greater than the Request Expense Amount"))
        if not self.send_journal_id:
            raise UserError(_("Please select the appropriate journals before proceeding under 'Request To' details."))
        if not self.send_destination_journal_id:
            raise UserError(_("Please select the appropriate journals before proceeding under 'Request To' details."))
        timenow = date.today()
        current_user = self.env.user

        for expense in self:
            amount = expense.approved_expense_amount
            reference = expense.name
            journal_id = expense.send_journal_id.id
            destination_journal_id = expense.send_destination_journal_id.id
            vals = {
                "is_internal_transfer": True,
                "payment_type": "outbound",
                "amount": amount,
                "journal_id": journal_id,
                "currency_id": expense.currency_id.id,
                "ref": reference,
                "destination_journal_id": destination_journal_id,
                "date": timenow,
                "company_expense_id": expense.id,
            }
            send_payment = self.env["account.payment"].sudo().create(vals)
            send_payment.action_post()
        self.write(
            {"state": "payment_sent", "account_payment_send_id": send_payment.id, "payment_sent_by_id": current_user.id}
        )

    def button_receive_payment_request(self):
        if self.request_from_company_id.id != self.env.user.company_id.id:
            raise UserError(_("You don't have a permission to Receive Payment.Please contact an Administrator."))
        timenow = date.today()
        current_user = self.env.user
        for expense in self:
            amount = expense.approved_expense_amount
            reference = expense.name
            journal_id = expense.receive_journal_id.id
            destination_journal_id = expense.receive_destination_journal_id.id
            vals = {
                "is_internal_transfer": True,
                "payment_type": "inbound",
                "amount": amount,
                "currency_id": expense.currency_id.id,
                "ref": reference,
                "journal_id": journal_id,
                "destination_journal_id": destination_journal_id,
                "date": timenow,
                "company_expense_id": expense.id,
            }
            receive_payment = self.env["account.payment"].sudo().create(vals)
            receive_payment.action_post()
        self.write(
            {
                "state": "payment_received",
                "account_payment_received_id": receive_payment.id,
                "payment_received_by_id": current_user.id,
            }
        )
