from odoo import fields, models


class AccountMove(models.Model):
    _inherit = "account.move"

    company_expense_id = fields.Many2one("company.expense", string="Inter-Company Expense")


class AccountMoveLine(models.Model):
    _inherit = "account.move.line"

    company_expense_id = fields.Many2one("company.expense", string="Inter-Company Expense")


class AccountPayment(models.Model):
    _inherit = "account.payment"

    company_expense_id = fields.Many2one("company.expense", string="Inter-Company Expense")
