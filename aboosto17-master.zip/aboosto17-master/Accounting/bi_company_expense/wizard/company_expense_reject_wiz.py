from odoo import fields, models, _
from odoo.exceptions import UserError


class CompanyExpenseRejectWizard(models.TransientModel):
    _name = "company.expense.reject.wizard"
    _description = "Company Expense Reject Wizard"

    company_expense_id = fields.Many2one("company.expense", string="Company Expense")
    reject_reason = fields.Text(string="Reason")

    def action_reject_expense(self):
        for vals in self:
            if not vals.reject_reason:
                raise UserError(_("Please enter the reason"))
            current_user = self.env.user
            current_employee = current_user.employee_id
            if current_employee:
                vals.company_expense_id.write(
                    {"reject_reason": vals.reject_reason, "rejected_by_id": current_user.id, "state": "reject"}
                )
