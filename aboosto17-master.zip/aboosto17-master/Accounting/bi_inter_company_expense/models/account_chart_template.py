# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import models, _
from odoo.addons.account.models.chart_template import template


class AccountChartTemplate(models.AbstractModel):
    _inherit = "account.chart.template"

    @template('generic_coa')
    def _get_generic_coa_template_data(self):
        """Return the data necessary for the chart template.

        :return: all the values that are not stored but are used to instancieate
                 the chart of accounts. Common keys are:
                 * property_*
                 * code_digits
        :rtype: dict
        """
        return {
            'name': _("United States of America (Generic)"),
            'country': None,
            'property_account_receivable_id': 'receivable',
            'property_account_payable_id': 'payable',
            'property_account_expense_categ_id': 'expense',
            'property_account_income_categ_id': 'income',
            'property_stock_account_input_categ_id': 'stock_in',
            'property_stock_account_output_categ_id': 'stock_out',
            'property_stock_valuation_account_id': 'stock_valuation',
            # 'property_stock_account_production_cost_id': 'cost_of_production',
        }