from odoo import models, api, fields, _
from datetime import timedelta
from datetime import datetime
from lxml import etree
from odoo.exceptions import ValidationError,UserError


class InterCompanyTransfer(models.Model):
    
    _name = 'inter.company.expense'
    _description = 'Inter Company Transfer'
    _rec_name = 'sequence_number'

    state = fields.Selection(selection=[
       ('draft', 'Draft'),
       ('done', 'Done'),
    ], string='Status', required=True, readonly=True, copy=False,
    tracking=True, default='draft')

    partner_id = fields.Many2one(
        'res.partner', 
        string='Partner', 
        domain="[('company_id', '=', company_id)]" 
    )
    destination_company = fields.Many2one('res.company',string="Destination", required=True)
    company_domain = fields.Binary(compute="_compute_company_domain")

    payment_type_send = fields.Selection([
        ('send', 'SEND'),
    ], default='send', string='Payment Type', required=True)
    payment_type_receive = fields.Selection([
        ('receive', 'RECEIVE'),
    ], default='receive', string='Payment Type', required=True)

    amount = fields.Float(string='Amount', required=True )
    currency_id = fields.Many2one('res.currency', required=True, default=lambda self: self.env.company.currency_id)
    
    date = fields.Date(string='Date', required=True, default=datetime. today())
    remarks = fields.Char(string="Remarks")
    journal_id = fields.Many2one("account.journal", string="Journal" )
    coa_id = fields.Many2one("account.account", string="Sender Account")
    coa_id_receive = fields.Many2one("account.account",string="Receiving Account")    
    company_id = fields.Many2one(
        comodel_name='res.company',
        required=True,
        readonly=True,
        default=lambda self: self.env.company,
    )
    state = fields.Selection([('draft', 'Draft'), ('done', 'Done')], default='draft')
    is_user_destination_company = fields.Boolean(
        compute='_compute_is_user_destination_company',
        string="Is User in Destination Company")
    source_acc_ids = fields.Many2one("account.account", string="I/C Control Account")
    destination_acc_ids = fields.Many2one("account.account", string="I/C Control Account")                    
                           
    receive_button_disable = fields.Boolean(string="Receive Button Disable")
    sequence_number = fields.Char("Reference", default=lambda self: _('ICT'),
       copy=False, readonly=True, tracking=True)
    destination_partner_id = fields.Many2one("res.partner", string="Destination Partner",
                                              domain="[('is_company', '=', True)]")
    
    def _valid_field_parameter(self, field, name):
            return name in ['tracking'] or super()._valid_field_parameter(field, name)

    @api.onchange("destination_company")
    def _destination_company(self):
        if self.destination_company:
            return {
                "domain": {
                    "coa_id_receive": [
                        ("company_id", "=", self.destination_company.id),
                        ("account_type", "=", "asset_cash"),
                    ]
                }
            }
        else:
            return {"domain": {"coa_id_receive": []}}

    @api.onchange("destination_company")
    def _destination_account(self):
        if self.destination_company:
            return {
                "domain": {
                    "destination_acc_ids": [
                        ("company_id", "=", self.destination_company.id),
                    ]
                }
            }
        else:
            return {"domain": {"destination_acc_ids": []}}

    @api.depends('company_id')
    def _compute_company_domain(self):
        for each in self:
            each.company_domain = False
            company_id = each.company_id
            partner_ids = self.env['res.partner'].search([('company_id','=',company_id.id)])
            if company_id:
                each.company_domain = partner_ids.ids
            else:
                each.company_domain = False

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            vals['sequence_number'] = self.env['ir.sequence'].next_by_code('inter.company.expense') or ('')

        if not vals.get('journal_id'):
            miscellaneous_journal = self.env['account.journal'].search([('code', '=', 'MISC')], limit=1)
            if miscellaneous_journal:
                vals['journal_id'] = miscellaneous_journal.id

        result = super(InterCompanyTransfer, self).create(vals_list)
        return result
    
    def action_view_account_move(self):
        result = {
            "type": "ir.actions.act_window",
            "res_model": "account.move",
            "domain": [('inter_expense_id', '=', self.id)],
            "name": _("Journal Entry"),
            'view_mode': 'tree,form',
        }
        return result

    def action_confirm(self):
        # destination_partner = self.destination_partner_id
        if self.destination_company.parent_id :
            destination_control_acc_id = self.env["account.account"].sudo().search([("is_control_account", "=", True), 
                                                                    ("company_id", "=" , self.destination_company.parent_id.id)],limit=1)
        else:
            destination_control_acc_id = self.env["account.account"].sudo().search([("is_control_account", "=", True), 
                                                                    ("company_id", "=" , self.destination_company.sudo().id)],limit=1)
        
        if self.company_id.parent_id :
            source_control_acc_ids = self.env["account.account"].search([("is_control_account", "=", True), 
                                                                 ("company_id", "=" , self.env.company.parent_id.id)],limit=1)
        else:
            source_control_acc_ids = self.env["account.account"].search([("is_control_account", "=", True), 
                                                                 ("company_id", "=" , self.env.company.id)],limit=1)

        # if self.company_id.parent_id :
        #     source_400200_acc_ids = self.env["account.account"].search([
        #                                     ("code", "=", 203010), 
        #                                     ("company_id", "=", self.company_id.parent_id.id)
        #                                 ],limit=1)
        # else:
        #     source_400200_acc_ids = self.env["account.account"].search([
        #                                     ("code", "=", 203010), 
        #                                     ("company_id", "=", self.company_id.id)
        #                                 ],limit=1)
            
        # if self.destination_company.parent_id :
        #     destination_400200_acc_ids = self.env["account.account"].sudo().search([
        #                                     ("code", "=", 201003), 
        #                                     ("company_id", "=", self.destination_company.parent_id.id),
        #                                 ],limit=1) 
        # else:
        #     destination_400200_acc_ids = self.env["account.account"].sudo().search([
        #                                     ("code", "=", 201003), 
        #                                     ("company_id", "=", self.destination_company.sudo().id),
        #                                 ],limit=1) 
            

        # if self.destination_company.parent_id :
        #     destination_bank_cash_acc_ids = self.env["account.account"].sudo().search([("company_id", "=", self.destination_company.parent_id.id),
        #                                                                 ("account_type", "=", "asset_cash")],limit=1)
        # else:
        #     destination_bank_cash_acc_ids = self.env["account.account"].sudo().search([("company_id", "=", self.destination_company.sudo().id),
        #                                                                 ("account_type", "=", "asset_cash")],limit=1)

        # if not self.coa_id_receive:
        #     raise ValidationError(_("Missing cash account for the destination partner company."))
        if not destination_control_acc_id:
            raise ValidationError(_("Missing control account for the destination partner company."))

        for record in self:
            # default_account_id = record.journal_id.sudo().default_account_id.id
            partner_id = self.env['res.partner'].sudo().search([('name','=',record.company_id.name)],limit=1)
            dest_partner_id = self.env['res.partner'].sudo().search([('name','=',self.destination_company.sudo().name)],limit=1)
            if not partner_id or not dest_partner_id:
                raise ValidationError(_("Partner is required."))
            if not record.coa_id or not source_control_acc_ids:
                raise ValidationError(_("Missing required account(s) for the journal entry."))

            # 1st entry creation
            source_entry_vals = {
                'date': record.date,
                'journal_id': record.journal_id.id,
                'company_id': record.company_id.id,
                'partner_id' : dest_partner_id.id,
                'line_ids': [
                    
                    (0, 0, {
                        'account_id': record.coa_id.id,
                        'name': _("Inter Company Transfer"),
                        'currency_id' : record.currency_id.id,
                        'credit': record.amount,
                        'debit': 0,
                        'company_id': record.company_id.id,
                        'partner_id' : dest_partner_id.id,
                        'move_type': 'entry',
                    }),
                    (0, 0, {
                        'account_id': source_control_acc_ids.id,
                        'name': _("Inter Company Transfer"),
                        'currency_id' : record.currency_id.id,
                        'debit': record.amount,
                        'credit': 0,
                        'company_id': record.company_id.id,
                        'partner_id' : dest_partner_id.id,
                        'move_type': 'entry',
                    }),
                ]
            }
            source_entry = self.env['account.move'].sudo().create(source_entry_vals)
            source_entry.inter_expense_id = self.id
            source_entry.action_post()

            # 2nd entry creation
            source_entry_vals1 = {
                'date': record.date,
                'journal_id': record.journal_id.id,
                'company_id': record.company_id.id,
                'partner_id' : dest_partner_id.id,
                'line_ids': [
                    
                    (0, 0, {
                        'account_id': source_control_acc_ids.id,
                        'name': _("Inter Company Transfer"),
                        'currency_id' : record.currency_id.id,
                        'credit': record.amount,
                        'debit': 0,
                        'company_id': record.company_id.id,
                        'partner_id' : dest_partner_id.id,
                        'move_type': 'entry',
                    }),
                    (0, 0, {
                        'account_id': record.source_acc_ids.id,
                        'name': _("Inter Company Transfer"),
                        'currency_id' : record.currency_id.id,
                        'debit': record.amount,
                        'credit': 0,
                        'company_id': record.company_id.id,
                        'partner_id' : dest_partner_id.id,
                        'move_type': 'entry',
                    }),
                ]
            }
            source_entry = self.env['account.move'].sudo().create(source_entry_vals1)
            source_entry.inter_expense_id = self.id
            source_entry.action_post()
        self.state = 'done'

    def action_receive(self):
        if self.destination_company.parent_id :
            destination_control_acc_id = self.env["account.account"].sudo().search([("is_control_account", "=", True), 
                                                                    ("company_id", "=" , self.destination_company.parent_id.id)],limit=1)
        else:
            destination_control_acc_id = self.env["account.account"].sudo().search([("is_control_account", "=", True), 
                                                                    ("company_id", "=" , self.destination_company.sudo().id)],limit=1)        
        for record in self:
            partner_id = self.env['res.partner'].sudo().search([('name','=',record.company_id.name)],limit=1)
            dest_partner_id = self.env['res.partner'].sudo().search([('name','=',self.destination_company.sudo().name)],limit=1)
            if self.destination_company.parent_id :
                dest_journal_id = self.env['account.journal'].sudo().search([('is_inter_company','=',True),("company_id", "=" , self.destination_company.parent_id.id)],limit=1)
            else:
                dest_journal_id = self.env['account.journal'].sudo().search([('is_inter_company','=',True),("company_id", "=" , self.destination_company.id)],limit=1)

            if not dest_journal_id:
                raise UserError(_("There is no journal found!!!"))
            
            amt = record.currency_id._convert(record.amount, self.destination_company.sudo().currency_id,self.destination_company.sudo() ,record.date)
            # 3rd entry creation - posted
            source_entry_vals2 = {
                'date': record.date,
                'journal_id': dest_journal_id.id,
                'company_id': self.destination_company.sudo().id,
                'partner_id' : partner_id.id,
                'line_ids': [
                    (0, 0, {
                        'account_id': destination_control_acc_id.id,
                        'name': _("Inter Company Transfer"),
                        'currency_id' : self.destination_company.sudo().currency_id.id,
                        'credit': amt,
                        'debit': 0,
                        'company_id': self.destination_company.sudo().id,
                        'partner_id' : partner_id.id,
                        'move_type': 'entry',
                    }),
                    (0, 0, { 
                        'account_id': record.coa_id_receive.id,
                        'name': _("Inter Company Transfer"),
                        'currency_id' : self.destination_company.sudo().currency_id.id,
                        'debit': amt,
                        'credit': 0,
                        'company_id': self.destination_company.sudo().id,
                        'partner_id' : partner_id.id,
                        'move_type': 'entry',
                    }),
                ]
            }
            source_entry = self.env['account.move'].sudo().create(source_entry_vals2)
            source_entry.inter_expense_id = self.id
            source_entry.action_post()

            # 4th entry creation 
            source_entry_vals3 = {
                'date': record.date,
                'journal_id': dest_journal_id.id,
                'company_id': self.destination_company.sudo().id,
                'partner_id' : partner_id.id,
                'line_ids': [
                    
                    (0, 0, {
                        'account_id': self.destination_acc_ids.id,
                        'name': _("Inter Company Transfer"),
                        'currency_id' : self.destination_company.sudo().currency_id.id,
                        'credit': amt,
                        'debit': 0,
                        'company_id': self.destination_company.sudo().id,
                        'partner_id' : partner_id.id,
                        'move_type': 'entry',
                    }),
                    (0, 0, {
                        'account_id': destination_control_acc_id.id,
                        'name': _("Inter Company Transfer"),
                        'currency_id' : self.destination_company.sudo().currency_id.id,
                        'debit': amt,
                        'credit': 0,
                        'company_id': self.destination_company.sudo().id,
                        'partner_id' : partner_id.id,
                        'move_type': 'entry',
                    }),
                ]
            }
            source_entry = self.env['account.move'].sudo().create(source_entry_vals3)
            source_entry.inter_expense_id = self.id
            source_entry.action_post()
        self.receive_button_disable = True 

    def search_fetch(self, domain, field_names, offset=0, limit=None, order=None):
        company_id = self.env.company.name
        domain += ['|',('company_id', '=', company_id),('destination_company', '=', company_id)]
        return super(InterCompanyTransfer, self).search_fetch(domain, field_names, offset, limit, order)

    @api.depends('destination_company')
    def _compute_is_user_destination_company(self):
        for record in self:
            record.is_user_destination_company = (
                self.env.company == record.destination_company
            )


    def unlink(self):
        for each in self:
            if each.state in ("done"):
                raise UserError(_("Cannot delete the transaction having account move!!!!"))
        return super(InterCompanyTransfer, self).unlink()
    
    # @api.model
    # def get_views(self, views, options=None):
    #     res = super().get_views(views, options=options)
    #     if "form" in res["views"]:
    #         arch = res["views"]["form"]["arch"]
    #         doc = etree.fromstring(arch)
    #         for node in doc.xpath("//header/button"):
    #             if node.attrib["string"] in ["Send"] and self.env.company.id == self.company_id.id:
    #                 node.attrib["invisible"] = 0
    #                 arch = etree.tostring(doc, encoding="unicode")
    #         res["views"]["form"]["arch"] = arch
    #     return res    







