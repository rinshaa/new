from odoo import models, fields


class AccountMove(models.Model):
    _inherit = 'account.move'

    inter_expense_id = fields.Many2one('inter.company.expense', string='Inter company expense' )