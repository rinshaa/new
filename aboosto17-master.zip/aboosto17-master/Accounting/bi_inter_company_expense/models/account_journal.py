from odoo import models,fields,api


class AccountJournal(models.Model):
    _inherit = "account.journal"

    is_inter_company = fields.Boolean(string="Is Inter Company", copy=False)
