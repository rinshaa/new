from odoo import models, fields

class AccountMove(models.Model):
    _inherit = 'account.account'

    is_control_account = fields.Boolean(string='Is Control Account')
