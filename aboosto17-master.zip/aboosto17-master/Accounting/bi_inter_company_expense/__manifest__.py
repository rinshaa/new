{
    "name": "Inter Company Expense",
    "version": "17.0.1.1",
    "summary": """ Inter Company Expense""",
    "description": """Inter Company Expense""",
    "author": "Bassam Infotech LLP",
    "company": "Bassam Infotech LLP",
    "maintainer": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "category": "Accounting",
    "depends": ["base", "account"],
    "data": [
        "security/ir.model.access.csv",
        "views/inter_company_expense.xml",
        "views/account_account.xml",
        "views/account_move.xml",
        "views/account_journal.xml"
    ],
    "images": [],
    "license": "OPL-1",
    "installable": True,
    "application": False,
}


