from odoo import models,api,fields
from datetime import datetime,timedelta

class ProductPurchase(models.AbstractModel):
    _name = "report.bi_product_purchase_report.report_product_purchase"
    _description = "Product Purchase Report"
    
    
    @api.model
    def _get_report_values(self, docids, data=None):
        date_from = data["form"]["date_from"]
        date_to = data["form"]["date_to"]
        interval = data["form"]["interval"]
        month = data["form"]["month"]

        product_list = []
        replenishment_list = []

        for product in self.env['product.product'].search([('detailed_type', '=', 'product')]):
            product_data = {
                'name': product.name,
                'quantity': product.qty_available,
                'cost': product.standard_price,
                'last_purchase_date': '',
                'last_purchase_details': ''
            }

            last_purchase = self.env['purchase.order.line'].search([('product_id', '=', product.id),
                                                                    ('order_id.date_order', '>=', date_from),
                                                                    ('order_id.date_order', '<=', date_to),
                                                                    ('order_id.state', '=', 'purchase')],limit=1)
            
            if last_purchase:
                product_data['last_purchase_date'] = last_purchase.date_order
                product_data['last_purchase_details'] = {
                    'order': last_purchase.order_id.name,
                    'quantity': last_purchase.product_qty,
                    'unit_price': last_purchase.price_unit,
                    'total_amount': last_purchase.price_subtotal,
                    'vendor_name': last_purchase.partner_id.name,
                }
            product_list.append(product_data)
            
            product_stock = self.env['stock.warehouse.orderpoint'].search([('product_id', '=', product.id)])
            # Fetch RFQ details within the specified date range
            rfq_details = self.env['purchase.order'].search([
                    ('state', '=', 'draft'),
                    ('date_order', '>=', date_from),
                    ('date_order', '<=', date_to),
                    ('order_line.product_id', '=', product.id)
                ], limit=1)
            
            if product.qty_available < product_stock.product_min_qty and rfq_details:
                # Add product to replenishment list
                replenishment_data = {
                    'name': product_stock.product_id.name,
                    'min_qty': product_stock.product_min_qty,
                    'vendor_name': '',
                    'quantity': '',   
                    'unit_price': '',  
                    'total_cost': '',
                    'order_deadline': '',
                }

                if rfq_details:
                    order_line = rfq_details.order_line.filtered(lambda x: x.product_id.id == product.id)
                    replenishment_data['vendor_name'] = rfq_details.partner_id.name
                    replenishment_data['quantity'] = order_line.product_qty
                    replenishment_data['unit_price'] = order_line.price_unit
                    replenishment_data['total_cost'] = order_line.price_subtotal
                    replenishment_data['order_deadline'] = rfq_details.date_planned

                replenishment_list.append(replenishment_data)

        return {
            'product_list': product_list,
            'replenishment_list': replenishment_list, 
            'report_type': interval,
            'selected_month': month  
        }

      