from odoo import models,fields,api
from datetime import date,datetime,timedelta
import calendar

class ProductPurchaseWiz(models.TransientModel):
    _name = "product.purchase.wiz"
    _description = "Product Purchase Report Wizard"

    date_from = fields.Date(string="From", required=True)
    date_to = fields.Date(string="To", required=True)

    interval = fields.Selection([('monthly', 'Monthly'), 
                                 ('current_financial_year', 'Current Financial Year'),
                                 ('last_financial_year', 'Last Financial Year')],string="Interval", default=False)


    month = fields.Selection([
        ('01', 'January'),
        ('02', 'February'),
        ('03', 'March'),
        ('04', 'April'),
        ('05', 'May'),
        ('06', 'June'),
        ('07', 'July'),
        ('08', 'August'),
        ('09', 'September'),
        ('10', 'October'),
        ('11', 'November'),
        ('12', 'December'),
    ], string='Month')

    @api.onchange('month')
    def _onchange_month(self):
        if self.month:
            year = fields.Date.today().year
            month = int(self.month)
            start_date = datetime(year, month, 1).strftime('%Y-%m-%d')
            _, last_day = calendar.monthrange(year, month)
            end_date = datetime(year, month, last_day).strftime('%Y-%m-%d')
            self.date_from = start_date
            self.date_to = end_date

    @api.onchange('interval')
    def _onchange_interval(self):
        if self.interval == 'current_financial_year':
            today = fields.Date.today()
            start_date = datetime(today.year, 1, 1) 
            end_date = datetime(today.year, 12, 31) 
            self.date_from = start_date.strftime('%Y-%m-%d')
            self.date_to = end_date.strftime('%Y-%m-%d')
        elif self.interval == 'last_financial_year':
            today = fields.Date.today()
            start_date = datetime(today.year - 1, 1, 1) 
            end_date = datetime(today.year - 1, 12, 31)
            self.date_from = start_date.strftime('%Y-%m-%d')
            self.date_to = end_date.strftime('%Y-%m-%d')

    def action_product_purchase(self):
        interval_value = dict(self._fields['interval'].selection).get(self.interval)
        month_value = dict(self._fields['month'].selection).get(self.month)
        data = {          
                'ids'   : self.ids,            
                'model' : self._name,            
                'form'  : { 
                            'date_from': self.date_from,
                            'date_to'  : self.date_to,
                            'interval': interval_value,
                            'month': month_value,
                          }         
                }       
        return self.env.ref('bi_product_purchase_report.action_product_purchase_report_html').report_action(self, data=data, config=False)
