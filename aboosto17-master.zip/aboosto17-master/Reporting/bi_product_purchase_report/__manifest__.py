{
    'name': 'BI Product Purchase Report',
    'summary': ''' BI Product Purchase Report ''',
    'description': '''BI Product Purchase Report''',
    'author': 'Bassam Infotech LLP',
    'company': 'Bassam Infotech LLP',
    'maintainer': 'Bassam Infotech LLP',
    'website': 'https://bassaminfotech.com',
    'category': 'stock',
    'depends': ['base','stock','product'],
    'version': '17.0.0.1',
    'data': [
        "security/ir.model.access.csv",
        "wizard/product_purch_wiz.xml",
        "report/report_paperformat.xml",
        "report/report_header.xml",
        "report/report_product_purchase.xml",
        "report/report.xml",
        "views/stock_picking.xml",
        
        
    ],
    'images': [],
    'license': 'OPL-1',
    'installable': True,
    'application': False,
}