from odoo import fields,models

class PurchaseExcelWizard(models.TransientModel):
    _name= "pos.profitable.report.wiz"
    _description = "Pos Profitable Report Wizard"
    

    date_from = fields.Date(string="Date From")
    date_to = fields.Date(string="Date To")

    def action_print_excel(self):
        data={
               "model": self._name,
                "form": {
                        "date_from": self.date_from,
                        "date_to": self.date_to, 
                        }
            }
        return self.env.ref('bi_profitable_report.report_pos_profitable_xlsx_id').report_action(self, data=data)