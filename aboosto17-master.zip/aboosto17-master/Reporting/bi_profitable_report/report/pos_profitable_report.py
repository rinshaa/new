from odoo import models,_
from datetime import datetime
from odoo.exceptions import UserError, ValidationError


class PartnerXlsx(models.AbstractModel):
    _name = 'report.bi_profitable_report.excel_take'
    _description = "Report Bi-Profitable Report"
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, lines):
        sheet = workbook.add_worksheet("Profitable Report")
        bold = workbook.add_format({'bold': True, 'align':'center', 'border': True})
        center_align = workbook.add_format({'align': 'center'})
        left_align = workbook.add_format({'align': 'left'})

        sheet.merge_range('A1:G1', 'POS ORDER', bold)
        sheet.write('A2', 'Serial No', bold)
        sheet.write('B2', 'Session', bold)
        sheet.write('C2', 'Order Ref', bold)
        sheet.write('D2', 'Customer', bold)
        sheet.write('E2', 'Total Cost', bold)
        sheet.write('F2', 'Total Sale price', bold)
        sheet.write('G2', 'Margin', bold)
        
        sheet.set_column('A:A', 15, center_align)
        sheet.set_column('B:B', 30, left_align)
        sheet.set_column('C:C', 20, center_align)
        sheet.set_column('D:D', 20, center_align)
        sheet.set_column('E:E', 20, center_align)
        sheet.set_column('F:F', 20, center_align)
        sheet.set_column('G:G', 20, center_align)
        date_from = data['form']['date_from']
        date_to = data['form']['date_to']

        if date_from > date_to:
            raise ValidationError(_(
                "Entered period is wrong...."))
        domain=[]
        if date_from:
            domain.append(('date_order', '>=', date_from))
        if date_to:
            domain.append(('date_order', '<=', date_to))

        pos_order_ids = self.env['pos.order'].search(domain)

        if pos_order_ids:
            serial_number = 0
            row = 3
            for rec in pos_order_ids:
                serial_number += 1
                sheet.write('A%s' %row, serial_number)
                sheet.write('B%s' % row, rec.session_id.name)
                sheet.write('C%s' %row, rec.name)
                sheet.write('D%s' %row, rec.partner_id.name)
                sheet.write('F%s' %row, rec.amount_total)
                sheet.write('G%s' %row, rec.margin)
                
                total_cost = sum(rec.lines.mapped('total_cost'))
                sheet.write('E%s' %row, total_cost)
                row += 1
   