from odoo import models, fields 


class HrContract(models.Model):
    _inherit = "hr.contract"
    
    social_allowance = fields.Monetary(string="Social Allowance")
    food_allowance = fields.Monetary(string="Food Allowance")
    petrol_allowances = fields.Monetary(string="Petrol Allowance (Staff)")