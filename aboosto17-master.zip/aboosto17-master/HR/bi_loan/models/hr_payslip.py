from odoo import models,fields,api


class HrPayslip(models.Model):
    _inherit = "hr.payslip"
    
    
    def action_payslip_done(self):
        res = super().action_payslip_done()
        for record in self:
            advance_salary_id = self.env['request.loan'].search([('employee_id','=',record.employee_id.id),('state','=','approved')],limit=1)
            payment_amt = advance_salary_id.installment_line_ids.filtered(lambda l:l.payment_date>=record.date_from and l.payment_date<=record.date_to)
            if payment_amt:
                payment_amt.is_paid = True
        return res
    
    @api.depends('employee_id', 'contract_id', 'struct_id', 'date_from', 'date_to')          
    def _compute_input_line_ids(self):
        res = super()._compute_input_line_ids()
                    
        to_add_vals = []
        
        for slip in self:
            current_month = slip.date_from.month
            current_year = slip.date_from.year
            
            if not slip.employee_id or not slip.date_from or not slip.date_to:
                continue
            
            loan_records = self.env['request.loan'].search([
            ('employee_id', '=', self.employee_id.id),
            ('state', '=', 'paid'),
            ('company_id', '=', self.env.company.id)
                ], limit=1)
            
            if slip.struct_id:
                loan_type = self.env.ref('bi_loan.loan_s_rl')
                lines_to_remove = slip.input_line_ids.filtered(lambda x: x.input_type_id == loan_type)
                to_remove_vals = [(3, line.id, False) for line in lines_to_remove]
                
                if loan_records:
                    for loan in loan_records:
                        for installment in loan.installment_line_ids:
                            if installment.payment_date.month == current_month and installment.payment_date.year == current_year and not installment.is_paid:
                                to_add_vals = [(0, 0, {
                                    'amount': installment.amount,
                                    'name': 'Loan Deduction',
                                    'input_type_id': self.env.ref('bi_loan.loan_s_rl').id
                                })]
                input_line_vals = to_remove_vals + to_add_vals
                slip.update({'input_line_ids': input_line_vals})
        return res
        
            
    
    