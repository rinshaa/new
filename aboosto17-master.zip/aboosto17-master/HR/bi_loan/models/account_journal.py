from odoo import models,fields,api


class AccountJournal(models.Model):
    _inherit = "account.journal"

    is_miscellaneous = fields.Boolean(string="Is Miscellaneous Operations", copy=False)
