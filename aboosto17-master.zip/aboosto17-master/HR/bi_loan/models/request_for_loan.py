from odoo import models, fields, api, _
from dateutil.relativedelta import relativedelta
from odoo.exceptions import ValidationError
from datetime import datetime
from odoo.exceptions import UserError


class RequestForLoan(models.Model):
    _name = "request.loan"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _description = "Request For Loan"
    _rec_name = "name"

    name = fields.Char(
        string="Name",
        default=lambda self: _("New"),
    )
    company_id = fields.Many2one(
        string='Company',
        comodel_name='res.company',
        required=True,
        readonly=True,
        default=lambda self: self.env.company.id
    )
    employee_id = fields.Many2one("hr.employee", string="Employee", required=True)
    department_id = fields.Many2one("hr.department", string="Department")
    approved_amount = fields.Float(string="Approve Amount")
    requested_amount = fields.Float(string="Requested Amount")
    payment_start_date = fields.Date(string="Payment Start Date")
    approved_date = fields.Date(string="Approved Date")
    requested_date = fields.Date(string="Requested Date", default=lambda self: fields.Date.context_today(self))
    job_position_id = fields.Many2one("hr.job", string="Job Position")
    no_of_installments = fields.Integer(string="No Of Installments")
    installment_line_ids = fields.One2many("installment.line", "request_loan_id")
    currency_id = fields.Many2one("res.currency", string="Currency")
    total_amount = fields.Monetary(string="Total Amount", currency_field="currency_id", compute="_compute_total_amount")
    total_paid_amount = fields.Monetary(
        string="Total Paid Amount", currency_field="currency_id", compute="_compute_total_amount"
    )
    balance_amount = fields.Monetary(
        string="Balance Amount", currency_field="currency_id", compute="_compute_total_amount"
    )
    # entry_id = fields.Many2one('account.move',string="Loan Approve Entry")
    loan_payment_entry_id = fields.Many2one('account.move',string="Loan Payment Entry")

    state = fields.Selection(
        [
            ("draft", "Draft"),
            ("verify", "Verified"),
            ("approved", "Approved"),
            ('closed',"Closed"),
            ("refuse", "Refused"),
            ("paid", "Paid"),
        ],
        string="Status",
        index=True,
        default="draft",
        store=True,
        tracking=True,
    )
    is_closed = fields.Boolean(default=False , compute="_compute_is_closed")
    # credit_account_id = fields.Many2one('account.account',string="Credit Account")
    # debit_account_id = fields.Many2one('account.account',string="Debit Account")
    # journal_id = fields.Many2one('account.journal',string="Journal",default=lambda self:self.env['account.journal'].search([('is_miscellaneous','=',True)]))

    def action_verify(self):
        self.approved_date = fields.Date.context_today(self)
        if self.requested_amount <= 0:
            raise UserError("Please provide the 'Requested Amount'")
        # loan_account = self.env['hr.salary.rule'].search([('code','=','LN100')])
        # if loan_account:
        #     self.credit_account_id = loan_account.credit_account
        #     self.debit_account_id = loan_account.debit_account
        #     self.journal_id = loan_account.account_journal
        self.write({"state": "verify"})

    def _compute_is_closed(self):
        for rec in self:
            is_paid = len(rec.installment_line_ids.filtered(lambda l:l.is_paid==True))
            total_lines = len(rec.installment_line_ids)
            if is_paid == total_lines and is_paid!=0:
                self.is_closed = True
                self.write({"state": "closed"})
            else:
                self.is_closed = False
                

    def action_approve(self):
        self.write({"state": "approved"})
        if self.approved_amount <= 0:
                    raise UserError("Please provide the 'Approve Amount'")
        # # self.approved_date = fields.Date.context_today(self)
        # amount = self.approved_amount
        # lists = []
        # lists.append(
        #         (
        #             0,
        #             0,
        #             {
        #                 "account_id": self.debit_account_id.id,
        #                 "debit": amount,
        #                 "credit": 0.0,
        #                 "name": "Loan - "+str(self.employee_id.name),
        #             },
        #         )
        #     )
        # lists.append(
        #         (
        #             0,
        #             0,
        #             {
        #                 "account_id": self.credit_account_id.id,
        #                 "debit": 0.0,
        #                 "credit": amount,
        #                 "name": "Loan - "+str(self.employee_id.name),
                    
        #             },
        #         )
        #     )
        # values = {
        #         "date": self.requested_date,
        #         "journal_id": self.journal_id.id,
        #         "move_type": "entry",
        #         "ref": "Loan Approved",
        #         "line_ids": lists,
        #     }
        # account_move_id = self.env["account.move"].sudo().create(values)
        # account_move_id.action_post()
        # if account_move_id:
        #     self.write({"state": "approved"})
        #     self.entry_id = account_move_id.id
            
    def action_refuse(self):
        self.write({"state": "refuse"})

    # def action_set_to_draft(self):
    #     self.write({"state": "draft"})

    def action_loan_register_payment(self):
        return {
            'name': 'ApprovedLoanPayment',
            'view_mode': 'form',
            'res_model': 'loan.payment',
            'type': 'ir.actions.act_window',
            'target': 'new',
            'context': {'default_employee_id': self.employee_id.id,
                        'default_loan_amount' : self.approved_amount,
                        # 'default_loan_journal' : self.journal_id.id,
            }
            } 
        
    def _compute_total_amount(self):
        total_paid_amount = 0
        for rec in self:
            if rec.approved_amount:
                rec.total_amount = rec.approved_amount
                total_paid_amount = sum((rec.installment_line_ids.filtered(lambda l: l.is_paid)).mapped("amount"))
                rec.total_paid_amount = total_paid_amount
                rec.balance_amount = rec.approved_amount - total_paid_amount
            else:
                rec.total_amount = 0
                rec.total_paid_amount = 0
                rec.balance_amount = 0

    def action_compute_installments(self):
        if self.no_of_installments <= 0 :
            raise UserError("Please provide the number of installments...!")
        if self.approved_amount <= 0 :
            raise UserError("Please provide the approved amount...!")
        self.installment_line_ids = False
        installments = []
        amount = 0
        if self.no_of_installments and self.approved_amount:
            amount = self.approved_amount / self.no_of_installments
        for i in range(self.no_of_installments):
            payment_start_date = self.payment_start_date + relativedelta(months=i)
            installments.append(
                (
                    0,
                    0,
                    {
                        "payment_date": payment_start_date,
                        "amount": amount,
                    },
                )
            )
        self.installment_line_ids = installments

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("name", _("New")) == _("New"):
                vals["name"] = self.env["ir.sequence"].next_by_code("request.loan.seq")
        return super().create(vals_list)

    @api.onchange("employee_id")
    def _onchange_employee_id(self):
        for rec in self:
            rec.department_id = rec.employee_id.department_id.id
            rec.job_position_id = rec.employee_id.job_id.id

    def unlink(self):
        for each in self:
            if each.state in ("paid"):
                raise UserError(_("Cannot delete loans as that are already paid."))
        return super(RequestForLoan, self).unlink()
        
class InstallmentLine(models.Model):
    _name = "installment.line"
    _description ="Installment Lines"

    request_loan_id = fields.Many2one("request.loan")
    payment_date = fields.Date(string="Payment Date")
    amount = fields.Float(string="Amount")
    is_paid = fields.Boolean(string="Paid", default=False)
