from . import request_for_loan
from . import hr_payslip
from . import account_journal
# from . import hr_salary_rule_accounting
