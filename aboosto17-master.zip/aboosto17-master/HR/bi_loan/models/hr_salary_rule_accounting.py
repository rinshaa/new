# from odoo import fields, models

# class HrSalaryRule(models.Model):
#     _inherit = 'hr.salary.rule'

#     debit_account = fields.Many2one(
#         'account.account', 'Loan Debit Account')
#     credit_account = fields.Many2one(
#         'account.account', 'Loan Credit Account')
#     account_journal = fields.Many2one(
#         'account.journal', 'Loan Journal')