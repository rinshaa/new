from odoo import models, fields, api
from datetime import date

class ApprovedLoanPayment(models.TransientModel):
    _name = 'loan.payment'
    _description = 'Approved Loan Payment'

    employee_id = fields.Many2one('hr.employee', string="Employee", required=True)
    loan_amount = fields.Float(string="Amount", required=True)
    payment_date = fields.Date(string="Payment Date", default=fields.Date.today)    
    loan_memo = fields.Char(string="Memo")
    # payment_method = fields.Many2one('payment.method', string="Payment Method", domain="[('active', '=', True)]")
    loan_journal = fields.Many2one('account.journal', string="Journal", required=True)
    cr_account = fields.Many2one('account.account',string="Credit Account", required=True)
    de_account = fields.Many2one('account.account',string="Debit Account", required=True)

    def action_create_payment(self):
        move_vals = {
            'journal_id': self.loan_journal.id,
            'date': self.payment_date,
            'ref': self.loan_memo or "Loan Payment",
            'line_ids': [
                (0, 0, {
                    'account_id': self.de_account.id,
                    'name': self.employee_id.id,
                    'debit': self.loan_amount,
                    'credit': 0.0,
                }),
                (0, 0, {
                    'account_id': self.cr_account.id,
                    'name': self.employee_id.id,
                    'debit': 0.0,
                    'credit': self.loan_amount,
                }),
            ],
        }

        move = self.env['account.move'].create(move_vals)
        move.action_post()
        active_id = self.env.context.get('active_id')
        # active_model = self.env.context.get('active_model').browse(active_id)
        request_loan = self.env['request.loan'].search([('id','=', active_id)])
        request_loan.loan_payment_entry_id = move.id
        request_loan.state = 'paid'
        return {
            'type': 'ir.actions.client',
            'tag': 'reload',
        }