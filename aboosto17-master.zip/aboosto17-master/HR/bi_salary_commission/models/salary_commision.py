from odoo import models, api, fields, _
from datetime import datetime


class SalaryCommision(models.Model):
    _name = 'salary.commision'
    _inherit = ['mail.thread']
    _description = 'Salary Commision'
    _rec_name = "sequence_number"

    date = fields.Date(string='Date', default=datetime. today())
    percentage = fields.Float(string='Percentage')
    job_postion_id = fields.Many2one('hr.job', string='Job Position')
    sequence_number = fields.Char("Reference",
       copy=False, tracking=True,
       default=lambda self: _("New"))

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("sequence_number", _("New")) == _("New"):
                vals["sequence_number"] = self.env["ir.sequence"].next_by_code("salary.commision.seq")
        return super().create(vals_list)