from odoo import models, fields, api, _


class HrPayslip(models.Model):
    _inherit = "hr.payslip"

    @api.depends('contract_id', 'struct_id','employee_id','date_from','date_to')
    def _compute_input_line_ids(self):
        res = super()._compute_input_line_ids()
        to_add_vals = []
        # search the salary commission master to get the values of percentage and to which job position applied
        percentage = self.env['salary.commision'].search([],limit=1).percentage
        job_postion = self.env['salary.commision'].search([],limit=1).job_postion_id
        for slip in self:
            if not slip.employee_id or not slip.date_from or not slip.date_to:
                continue
            sal_allow_type = self.env.ref('bi_salary_commission.employee_sca_input_type')
            lines_to_remove = slip.input_line_ids.filtered(lambda x: x.input_type_id == sal_allow_type)
            to_remove_vals = [(3, line.id, False) for line in lines_to_remove]
            if slip.employee_id.job_id.id == job_postion.id and slip.struct_id:
                pos_order_id = self.env['pos.order'].search([('employee_id' , '=',slip.employee_id.id),
                                                            ('date_order', '>=' , slip.date_from),
                                                            ('date_order', '<=', slip.date_to),
                                                            ('company_id', '=', slip.company_id.id)])
                if pos_order_id:
                    sal_allowance = sum(pos_order_id.mapped("amount_total"))
                    commission = (sal_allowance * percentage) / 100
                    
                    to_add_vals = [(0, 0, {
                        'amount': commission,
                        'name': 'Salary Commission Allowance',
                        'input_type_id': self.env.ref('bi_salary_commission.employee_sca_input_type').id
                    })]
            input_line_vals = to_remove_vals + to_add_vals
            slip.update({'input_line_ids': input_line_vals})
        return res           