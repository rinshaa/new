from odoo import models, fields 

class HrContract(models.Model):
    _inherit = "hr.contract"

    salary_commission_allowance = fields.Monetary(string="Salary Commission Allowance")