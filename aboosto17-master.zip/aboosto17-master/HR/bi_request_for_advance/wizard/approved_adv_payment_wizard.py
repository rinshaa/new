from odoo import models, fields, api
from datetime import date

class ApprovedAdvancePayment(models.TransientModel):
    _name = 'advance.payment'
    _description = 'Approved Advance Payment'

    adv_employee_id = fields.Many2one('hr.employee', string="Employee", required=True)
    advance_amount = fields.Float(string="Amount", required=True)
    adv_payment_date = fields.Date(string="Payment Date", default=fields.Date.today)    
    advance_memo = fields.Char(string="Memo")
    # payment_method = fields.Many2one('payment.method', string="Payment Method", domain="[('active', '=', True)]")
    advance_journal = fields.Many2one('account.journal', string="Journal", required=True)
    adv_cr_account = fields.Many2one('account.account',string="Credit Account", required=True)
    adv_de_account = fields.Many2one('account.account',string="Debit Account", required=True)

    def action_create_payment(self):
        move_vals = {
            'journal_id': self.advance_journal.id,
            'date': self.adv_payment_date,
            'ref': self.advance_memo or "Advance Payment",
            'line_ids': [
                (0, 0, {
                    'account_id': self.adv_de_account.id,
                    'name': self.adv_employee_id.id,
                    'debit': self.advance_amount,
                    'credit': 0.0,
                }),
                (0, 0, {
                    'account_id': self.adv_cr_account.id,
                    'name': self.adv_employee_id.id,
                    'debit': 0.0,
                    'credit': self.advance_amount,
                }),
            ],
        }

        move = self.env['account.move'].create(move_vals)
        move.action_post()
        adv_active_id = self.env.context.get('active_id')
        # active_model = self.env.context.get('active_model').browse(active_id)
        request_adv = self.env['request.advance'].search([('id','=', adv_active_id)])
        request_adv.adv_payment_entry_id = move.id
        request_adv.state = 'paid'
        return {
            'type': 'ir.actions.client',
            'tag': 'reload',
        }