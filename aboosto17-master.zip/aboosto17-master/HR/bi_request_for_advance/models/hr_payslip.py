from odoo import models,fields,api
from dateutil.relativedelta import relativedelta
from odoo import Command


class HrPayslip(models.Model):
    _inherit = "hr.payslip"
    
    
    def action_payslip_done(self):
        res = super().action_payslip_done()
        for each in self:
            request_advance_id = self.env['request.advance'].search([('employee_id','=',each.employee_id.id),
                                                                    ('state','=','approved'),
                                                                    ('is_deduct_from_salary','=',False),
                                                                    ('approved_date','>=',each.date_from),
                                                                    ('approved_date','<=',each.date_to),
                                                                    ],limit=1)
            if request_advance_id:
                request_advance_id.is_deduct_from_salary = True
        return res

    @api.depends('employee_id', 'contract_id', 'struct_id', 'date_from', 'date_to')          
    def _compute_input_line_ids(self):
        res = super()._compute_input_line_ids()
        to_add_vals = []
        
        for slip in self:
            if not slip.employee_id or not slip.date_from or not slip.date_to:
                continue
            
            current_month = slip.date_from.month
            current_year = slip.date_from.year
            advance_records = self.env['request.advance'].search([
                ('employee_id', '=', slip.employee_id.id),
                ('state', '=', 'paid'),
                ('company_id', '=', slip.env.company.id)
            ], limit=1)
            
            if slip.struct_id:
                advance_type = self.env.ref('bi_request_for_advance.advance_s_rl')
                lines_to_remove = slip.input_line_ids.filtered(lambda x: x.input_type_id == advance_type)
                to_remove_vals = [(3, line.id, False) for line in lines_to_remove]
                
                if advance_records:
                    for advance in advance_records:
                        if (advance.approved_date + relativedelta(months=1)).month == current_month and advance.approved_date.year == current_year and not advance.is_deduct_from_salary:
                            to_add_vals = [(0, 0, {
                                'amount': advance.approved_amount,
                                'name': 'Advance Deduction',
                                'input_type_id': self.env.ref('bi_request_for_advance.advance_s_rl').id
                            })]
                input_line_vals = to_remove_vals + to_add_vals
                slip.update({'input_line_ids': input_line_vals})
        return res
    