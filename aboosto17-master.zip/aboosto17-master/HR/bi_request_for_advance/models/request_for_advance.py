from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
from odoo.exceptions import UserError


class RequestForAdvance(models.Model):
    _name = "request.advance"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _description = "Request For Advance"
    _rec_name = "name"

    name = fields.Char(
        string="Name",
        default=lambda self: _("New"),
    )
    company_id = fields.Many2one(
    string='Company',
    comodel_name='res.company',
    required=True,
    readonly=True,
    default=lambda self: self.env.company.id
    )
    employee_id = fields.Many2one("hr.employee", string="Employee", required=True)
    department_id = fields.Many2one("hr.department", string="Department")
    approved_amount = fields.Float(string="Approve Amount")
    requested_amount = fields.Float(string="Requested Amount")
    approved_date = fields.Date(string="Approved Date")
    requested_date = fields.Date(string="Requested Date", default=lambda self: fields.Date.context_today(self))
    job_position_id = fields.Many2one("hr.job", string="Job Position")
    currency_id = fields.Many2one("res.currency", string="Currency")
    is_deduct_from_salary = fields.Boolean(string="Deducted From Salary")
    # entry_id = fields.Many2one('account.move',string="Advance Approved Entry")
    adv_payment_entry_id = fields.Many2one('account.move',string="Advance Payment Entry")

    state = fields.Selection(
        [
            ("draft", "Draft"),
            ("verify", "Verified"),
            ("approved", "Approved"),
            ('closed',"Closed"),
            ("refuse", "Refused"),
            ("paid", "Paid"),
        ],
        string="Status",
        index=True,
        default="draft",
        store=True,
        tracking=True,
    )
    # credit_account_id = fields.Many2one('account.account',string="Credit Account")
    # debit_account_id = fields.Many2one('account.account',string="Debit Account")
    # journal_id = fields.Many2one('account.journal',string="Journal",default=lambda self:self.env['account.journal'].search([('is_miscellaneous','=',True)]))

    def action_verify(self):
        self.approved_date = fields.Date.context_today(self)
        if self.requested_amount <= 0:
            raise UserError("Please provide the 'Requested Amount'")
        # adv_account = self.env['hr.salary.rule'].search([('code','=','ADV100')])
        # if adv_account:
        #     self.credit_account_id = adv_account.adv_credit_account
        #     self.debit_account_id = adv_account.adv_debit_account
        #     self.journal_id = adv_account.adv_account_journal
        self.write({"state": "verify"})
                

    def action_approve(self):
        self.write({"state": "approved"})
        if self.approved_amount <= 0:
            raise UserError("Please provide the 'Approve Amount'")
        # self.approved_date = fields.Date.context_today(self)
        # amount = self.approved_amount
        # lists = []
        # lists.append(
        #         (
        #             0,
        #             0,
        #             {
        #                 "account_id": self.debit_account_id.id,
        #                 "debit": amount,
        #                 "credit": 0.0,
        #                 "name": "Advance Salary of "+str(self.employee_id.name),
        #             },
        #         )
        #     )
        # lists.append(
        #         (
        #             0,
        #             0,
        #             {
        #                 "account_id": self.credit_account_id.id,
        #                 "debit": 0.0,
        #                 "credit": amount,
        #                 "name": "Advance Salary of "+str(self.employee_id.name),
                    
        #             },
        #         )
        #     )
        # values = {
        #         "date": self.requested_date,
        #         "journal_id": self.journal_id.id,
        #         "move_type": "entry",
        #         "ref": "Advance Approved",
        #         "line_ids": lists,
        #     }
        # account_move_id = self.env["account.move"].sudo().create(values)
        # account_move_id.action_post()
        # if account_move_id:
        #     self.write({"state": "approved"})
        #     self.entry_id = account_move_id.id
            
    def action_refuse(self):
        self.write({"state": "refuse"})

    # def action_set_to_draft(self):
    #     self.write({"state": "draft"})

    def action_adv_register_payment(self):
        return {
            'name': 'ApprovedAdvancePayment',
            'view_mode': 'form',
            'res_model': 'advance.payment',
            'type': 'ir.actions.act_window',
            'target': 'new',
            'context': {'default_adv_employee_id': self.employee_id.id,
                        'default_advance_amount' : self.approved_amount,
                        # 'default_advance_journal' : self.journal_id.id,
            }
            } 

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("name", _("New")) == _("New"):
                vals["name"] = self.env["ir.sequence"].next_by_code("request.advance.seq")
        return super().create(vals_list)

    @api.onchange("employee_id")
    def _onchange_employee_id(self):
        for rec in self:
            rec.department_id = rec.employee_id.department_id.id
            rec.job_position_id = rec.employee_id.job_id.id

    def unlink(self):
        for each in self:
            if each.state in ("paid"):
                raise UserError(_("Cannot delete Advances that are already paid."))
        return super(RequestForAdvance, self).unlink()