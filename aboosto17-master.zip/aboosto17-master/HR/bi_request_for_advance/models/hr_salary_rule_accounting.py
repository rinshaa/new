# from odoo import fields, models

# class HrSalaryRule(models.Model):
#     _inherit = 'hr.salary.rule'

#     adv_debit_account = fields.Many2one(
#         'account.account', 'Advance Debit Account')
#     adv_credit_account = fields.Many2one(
#         'account.account', 'Advance Credit Account')
#     adv_account_journal = fields.Many2one(
#         'account.journal', 'Advance Journal')