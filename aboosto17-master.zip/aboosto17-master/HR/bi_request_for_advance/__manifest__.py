{
    "name": "Request For Advance",
    "version": "17.0.1.0.1",
    "summary": """ Request For Advance""",
    "description": """Request For Advance""",
    "author": "Bassam Infotech LLP",
    "company": "Bassam Infotech LLP",
    "maintainer": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "category": "HR",
    "depends": ["base", "hr", "bi_loan","hr_payroll"],
    "data": [
        "data/ra_sequence.xml",
        "data/data.xml",
        "security/ir.model.access.csv",
        "views/request_for_advance.xml",
        "security/security.xml",
        # "views/hr_salary_rule_accounting_views.xml",
        "views/approved_adv_payment_wizard_views.xml"
    ],
    "images": [
        'static/description/icon.png',
    ],
    "license": "OPL-1",
    "installable": True,
    "application": False,
}
