{
    'name': 'BI Leave Salary',
    'summary': ''' BI Leave Salary ''',
    'description': '''BI Leave Salary''',
    'author': 'Bassam Infotech LLP',
    'company': 'Bassam Infotech LLP',
    'maintainer': 'Bassam Infotech LLP',
    'website': 'https://bassaminfotech.com',
    'category': 'hr',
    'depends': ['base','hr','l10n_ae_hr_payroll'],
    'version': '17.0.0.1',
    'data': [
        "data/payroll_rule.xml",
        "views/hr_contract.xml",
    ],
    'images': [],
    'license': 'OPL-1',
    'installable': True,
    'application': False,
}

