from odoo import models, fields
from odoo.tools.date_utils import start_of, end_of
from datetime import date, timedelta,datetime
from dateutil.relativedelta import relativedelta 


class HrContract(models.Model):
    _inherit = "hr.contract"
    
    leave_allocation = fields.Float(string = "Leave Days", compute = "_compute_leave_allocation")
    leave_encash_date = fields.Date(string = "Leave Encash Date",compute = "_compute_leave_allocation")
    
    # compute both leave remaining and date to encash
    def _compute_leave_allocation(self):
        self.leave_allocation = 0
        self.leave_encash_date = False
        leave = 0
        for rec in self:
            if rec.state == 'open':
                leave = 30
            date_start = rec.date_start
            current_date = datetime.now().date()
            start_year = date_start.year
            current_year = current_date.year
            last_day_of_year = date(current_year, 12, 31)
            first_day_of_year = date(current_year, 1, 1)
            if current_year > start_year:
                year = current_year - start_year
                if year > 1:
                    check_month = date_start + relativedelta(years = year,months =1)
                    experience_year = date_start + relativedelta(years = year -1)
                else:
                    check_month = date_start + relativedelta(years = year,months =1)
                    experience_year = date_start   
                
            else:
                check_month = date_start + relativedelta(years = 1,months =1)
                experience_year = date_start
            if check_month.month ==  current_date.month:   
                rec.leave_encash_date = check_month      
            leave_type = self.env['hr.leave.type'].search([('name','=','Paid Time Off')])
            if not start_year ==  current_year and check_month.month ==  current_date.month:
                allocation_leave = self.env['hr.leave'].search([
                    ('employee_id', '=', rec.employee_id.id),  
                    ('holiday_status_id', '=', leave_type.id), 
                    ('state', '=', 'validate'),
                    ('request_date_from', '>=', experience_year),
                    ('request_date_to', '<=', check_month),
                ])
                duration = 0
                for allocate in allocation_leave:
                    duration += allocate.number_of_days_display
                if duration and duration < leave:
                    rec.leave_allocation = leave - duration
                elif duration > leave:
                    rec.leave_allocation = 0
                else:
                    rec.leave_allocation = leave    
                    
                    
                    