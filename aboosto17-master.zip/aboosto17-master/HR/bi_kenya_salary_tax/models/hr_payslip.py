from odoo import models,fields,api


class HrPayslip(models.Model):
    _inherit = "hr.payslip"
    
    
    @api.depends('employee_id', 'contract_id', 'struct_id', 'date_from', 'date_to')          
    def _compute_input_line_ids(self):
        res = super()._compute_input_line_ids()
                
        to_add_vals = []
        to_remove_vals_tax = to_remove_vals_nssf = to_remove_vals_shif = to_remove_vals_levy = []
        to_remove_vals_ir = to_remove_vals_ar = to_remove_vals_pr = to_remove_vals_paye = []
        for slip in self:
            current_month = slip.date_from.month
            current_year = slip.date_from.year
            
            if not slip.employee_id or not slip.date_from or not slip.date_to:
                continue

            salary = self.paid_amount  
            tax = 0.0

            # Tax bands
            first_band_limit = 24000
            second_band_limit = first_band_limit + 8333
            third_band_limit = second_band_limit + 467667
            fourth_band_limit = third_band_limit + 300000
            fifth_band_limit = 800000  

            ##########Tax Computation##########

            #first band
            if salary > first_band_limit:
                tax += first_band_limit * 0.1
                remaining_salary = salary - first_band_limit
                
                #second band
                if remaining_salary > (second_band_limit - first_band_limit):
                    tax += (second_band_limit - first_band_limit) * 0.25
                    remaining_salary -= (second_band_limit - first_band_limit)
                    
                    #third band
                    if remaining_salary > (third_band_limit - second_band_limit):
                        tax += (third_band_limit - second_band_limit) * 0.3
                        remaining_salary -= (third_band_limit - second_band_limit)
                        
                        #fourth band
                        if remaining_salary > (fourth_band_limit - third_band_limit):
                            tax += (fourth_band_limit - third_band_limit) * 0.325
                            remaining_salary -= (fourth_band_limit - third_band_limit)

                            #fifth band
                            tax += remaining_salary * 0.35

                        else:
                            # 32.5% tax on remaining amount in fourth band
                            tax += remaining_salary * 0.325
                    else:
                        # 30% tax on remaining amount in third band
                        tax += remaining_salary * 0.3
                else:
                    # 25% tax on remaining amount in second band
                    tax += remaining_salary * 0.25

            elif salary == first_band_limit:
                # 10% tax for salary of 24000
                tax = salary * 0.1

            # nssf
            if salary <= 36000:
                nssf = salary * 0.06
            else:
                nssf = 2160.0
                
            # shif 
            shif = salary * 0.0275

            # housing levy
            levy = salary * 0.015

            # insurance relief
            insurance_relief = shif * 0.15

            # ahl relief
            ahl_relief = levy * 0.15

            # personal relief
            personal_relief = 2400

            #paye
            paye = tax-(insurance_relief+ahl_relief+personal_relief)
            

            #tax
            if slip.struct_id:
                salary_type_tax = self.env.ref('bi_kenya_salary_tax.tax_s_rl')
                lines_to_remove_tax = slip.input_line_ids.filtered(lambda x: x.input_type_id == salary_type_tax)
                to_remove_vals_tax = [(3, line.id, False) for line in lines_to_remove_tax]

            #nssf
            if slip.struct_id:
                salary_type_nssf = self.env.ref('bi_kenya_salary_tax.nssf_s_rl')
                lines_to_remove_nssf = slip.input_line_ids.filtered(lambda x: x.input_type_id == salary_type_nssf)
                to_remove_vals_nssf = [(3, line.id, False) for line in lines_to_remove_nssf]

            #shif
            if slip.struct_id:
                salary_type_shif = self.env.ref('bi_kenya_salary_tax.shif_s_rl')
                lines_to_remove_shif = slip.input_line_ids.filtered(lambda x: x.input_type_id == salary_type_shif)
                to_remove_vals_shif = [(3, line.id, False) for line in lines_to_remove_shif]

            #housing levy
            if slip.struct_id:
                salary_type_levy = self.env.ref('bi_kenya_salary_tax.levy_s_rl')
                lines_to_remove_levy = slip.input_line_ids.filtered(lambda x: x.input_type_id == salary_type_levy)
                to_remove_vals_levy = [(3, line.id, False) for line in lines_to_remove_levy]


            #insurance relief
            if slip.struct_id:
                salary_type_ir = self.env.ref('bi_kenya_salary_tax.ir_s_rl')
                lines_to_remove_ir = slip.input_line_ids.filtered(lambda x: x.input_type_id == salary_type_ir)
                to_remove_vals_ir = [(3, line.id, False) for line in lines_to_remove_ir]

            #ahl relief
            if slip.struct_id:
                salary_type_ar = self.env.ref('bi_kenya_salary_tax.ar_s_rl')
                lines_to_remove_ar = slip.input_line_ids.filtered(lambda x: x.input_type_id == salary_type_ar)
                to_remove_vals_ar = [(3, line.id, False) for line in lines_to_remove_ar]

            #personal relief
            if slip.struct_id:
                salary_type_pr = self.env.ref('bi_kenya_salary_tax.pr_s_rl')
                lines_to_remove_pr = slip.input_line_ids.filtered(lambda x: x.input_type_id == salary_type_pr)
                to_remove_vals_pr = [(3, line.id, False) for line in lines_to_remove_pr]

            #paye
            if slip.struct_id:
                salary_type_paye = self.env.ref('bi_kenya_salary_tax.paye_s_rl')
                lines_to_remove_paye = slip.input_line_ids.filtered(lambda x: x.input_type_id == salary_type_paye)
                to_remove_vals_paye = [(3, line.id, False) for line in lines_to_remove_paye]

            #tax
            to_add_vals = [(0, 0, {
                'amount': tax,
                'name': 'Salary Tax',
                'input_type_id': self.env.ref('bi_kenya_salary_tax.tax_s_rl').id
            })]
            input_line_vals = to_remove_vals_tax + to_add_vals
            slip.update({'input_line_ids': input_line_vals})

            #nssf
            to_add_vals = [(0, 0, {
                'amount': nssf,
                'name': 'NSSF',
                'input_type_id': self.env.ref('bi_kenya_salary_tax.nssf_s_rl').id
            })]
            input_line_vals = to_remove_vals_nssf + to_add_vals
            slip.update({'input_line_ids': input_line_vals})

            #shif
            to_add_vals = [(0, 0, {
                'amount': shif,
                'name': 'SHIF',
                'input_type_id': self.env.ref('bi_kenya_salary_tax.shif_s_rl').id
            })]
            input_line_vals = to_remove_vals_shif + to_add_vals
            slip.update({'input_line_ids': input_line_vals})

            #housing levy
            to_add_vals = [(0, 0, {
                'amount': levy,
                'name': 'HOUSING LEVY',
                'input_type_id': self.env.ref('bi_kenya_salary_tax.levy_s_rl').id
            })]
            input_line_vals = to_remove_vals_levy + to_add_vals
            slip.update({'input_line_ids': input_line_vals})

            #insurance relief
            to_add_vals = [(0, 0, {
                'amount': insurance_relief,
                'name': 'INSURANCE RELIEF',
                'input_type_id': self.env.ref('bi_kenya_salary_tax.ir_s_rl').id
            })]
            input_line_vals = to_remove_vals_ir + to_add_vals
            slip.update({'input_line_ids': input_line_vals})

            #ahl relief
            to_add_vals = [(0, 0, {
                'amount': ahl_relief,
                'name': 'AHL RELIEF',
                'input_type_id': self.env.ref('bi_kenya_salary_tax.ar_s_rl').id
            })]
            input_line_vals = to_remove_vals_ar + to_add_vals
            slip.update({'input_line_ids': input_line_vals})

            #personal relief
            to_add_vals = [(0, 0, {
                'amount': personal_relief,
                'name': 'PERSONAL RELIEF',
                'input_type_id': self.env.ref('bi_kenya_salary_tax.pr_s_rl').id
            })]
            input_line_vals = to_remove_vals_pr + to_add_vals
            slip.update({'input_line_ids': input_line_vals})

            #paye
            to_add_vals = [(0, 0, {
                'amount': paye,
                'name': 'PAYE',
                'input_type_id': self.env.ref('bi_kenya_salary_tax.paye_s_rl').id
            })]
            input_line_vals = to_remove_vals_paye + to_add_vals
            slip.update({'input_line_ids': input_line_vals})

        return res




            

            
    
    