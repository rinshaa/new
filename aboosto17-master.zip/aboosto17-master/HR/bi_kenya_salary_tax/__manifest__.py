{
    "name": "Kenya Salary Tax",
    "version": "17.0.1.0.1",    
    "summary": """ Kenya Salary Tax""",
    "description": """Kenya Salary Tax""",
    "author": "Bassam Infotech LLP",
    "company": "Bassam Infotech LLP",
    "maintainer": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "category": "HR",
    "depends": ["base", "hr","hr_payroll","account","account_accountant"],
    "data": [
        "data/data.xml",
        ],
    "images": [
        'static/description/icon.png',
    ],
    "license": "OPL-1",
    "installable": True,
    "application": False,
}
