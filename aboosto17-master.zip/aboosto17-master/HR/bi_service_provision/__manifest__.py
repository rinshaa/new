
{
    'name': 'BI Service Provision',
    'summary': ''' BI Service Provision ''',
    'description': '''BI Service Provision''',
    'author': 'Bassam Infotech LLP',
    'company': 'Bassam Infotech LLP',
    'maintainer': 'Bassam Infotech LLP',
    'website': 'https://bassaminfotech.com',
    'category': 'hr',
    'depends': ['hr', 'account','base','l10n_ae_hr_payroll'],
    'version': '17.0.0.1',
    'data': [
        "security/ir.model.access.csv",
        "data/payroll_rule.xml",
        "views/employee_provision.xml",
    ],
    'images': [],
    'license': 'OPL-1',
    'installable': True,
    'application': False,
}

