from odoo import models, fields, api, _
from odoo.exceptions import UserError
from odoo.tools.date_utils import start_of, end_of
from datetime import date, timedelta,datetime
from dateutil.relativedelta import relativedelta 
import calendar


class EmployeeProvision(models.Model):
    _name = "employee.provision"
    _description = "Employee Provision"
    _rec_name = 'employee_id'
    
    employee_id = fields.Many2one('hr.employee',string ="employee", domain = "['|', ('active', '=', True), ('active', '=', False)]")
    contract_state = fields.Selection(selection = [
        ('draft','New'),
        ('open','Running'),
        ('close','Expired'),
        ('cancel','Cancelled')
    ],string = "Contract State")
    employee_provision_line_ids = fields.One2many('employee.provision.line','employee_provision_id',string = "Employee provision line")
    
    @api.onchange('employee_id')
    def onchange_employee_id(self):
        for rec in self:
            # active
            if rec.employee_id.contract_ids.active:
                start_date = rec.employee_id.contract_ids.date_start
                end_date = rec.employee_id.contract_ids.date_end
                number_of_days = rec.employee_id.contract_ids.l10n_ae_number_of_days
                state = rec.employee_id.contract_ids.state
                rec.contract_state = state
                if not number_of_days:
                    number_of_days = 21
                current_date = datetime.now()
                start_year = start_date.year
                start_month = start_date.month
                
               
                # end_month = start_date.month
                if end_date:
                    end_year = end_date.year
                    current_year = end_year
                else:    
                    current_year = current_date.year
                    current_month = current_date.month
            
                
                year = start_year 
                amount = (rec.employee_id.contract_ids.wage/30)*number_of_days
                exp = 0
                date = start_date   
                while year <= current_year:
                    if date == start_date:
                        amount = 0
                    else: 
                        amount = (rec.employee_id.contract_ids.wage/30)*number_of_days
                    if exp > 5:
                       number_of_days = 30
                       amount = (rec.employee_id.contract_ids.wage/30)*number_of_days 
                    rec.employee_provision_line_ids = [(0, 0, {
                        'year': date,
                        'experience':exp,
                        'amount': amount,
                    })]
                    year += 1
                    exp = year - start_year
                    date = start_date + relativedelta(years = exp)  

                
                
                
            
        # if self.month and self.expense:
        #     month_number = self.month
        #     split_amount = self.expense / month_number
        #     lines = []
        #     current_date = datetime.now()
        #     self.employee_purchase_line_ids = [(5,)]
            
        #     month_name = calendar.month_abbr[current_date.month]
        #     year = current_date.year
        #     lines.append((0, 0, {
        #         'employee_purchase_id': self.id,
        #         'sl': f"{month_name}-{year}",
        #         'expense': split_amount,
        #     }))
            
        #     for _ in range(1, month_number):
        #         current_date += relativedelta(months=1)
        #         if current_date.year == 9999 and current_date.month > 5:
        #             break
        #         month_name = calendar.month_abbr[current_date.month]
        #         year = current_date.year
        #         lines.append((0, 0, {
        #             'employee_purchase_id': self.id,
        #             'sl': f"{month_name}-{year}",
        #             'expense': split_amount,
        #         }))
                
        #     self.employee_purchase_line_ids = lines
                
                 

    
    
    
    
    
    
    
class EmployeeProvisionLine(models.Model):
    _name = "employee.provision.line"
    _description = " Employee Provision Line" 
    
    year = fields.Date(string = "year")
    experience = fields.Integer(string = "Experience")
    amount = fields.Float(string = 'Amount')  
    employee_provision_id = fields.Many2one('employee.provision',string = "Employee provision") 