from odoo import fields,models,api
import functools
import operator

class CrmLead(models.Model):
    _inherit = "crm.lead"
    
    def write(self, values):
        if 'stage_id' in values.keys():
            new_rec = values['stage_id']
            old_stage_id = self.stage_id.id
            if old_stage_id != new_rec:
                self.send_stage_change_email(values)
        return super(CrmLead, self).write(values)

    def send_stage_change_email(self,values):
        outgoing_mail_server = self.env['ir.mail_server'].sudo().search([], limit=1)
        recipient_groups = self.env['res.groups']
        new_stage = values['stage_id']
        updated_stage = self.env["crm.stage"].search([("id","=",new_stage)])
        sales_person = []
        for each in self:
            if self.env.user.id == each.user_id.id:
                recipient_groups |= self.env.ref("bi_crm_customization.group_md_crm")
                recipient_groups |= self.env.ref("bi_crm_customization.group_sales_manager_crm")
            elif self.env.user.has_group("bi_crm_customization.group_md_crm"):
                sales_person.append(each.user_id)
                recipient_groups |= self.env.ref("bi_crm_customization.group_sales_manager_crm")
            elif self.env.user.has_group("bi_crm_customization.group_sales_manager_crm"):
                recipient_groups |= self.env.ref("bi_crm_customization.group_md_crm")
                sales_person.append(each.user_id)
            users_in_group = []
            for group in recipient_groups:
                for user_group in group.users:
                    users_in_group.append([user_group])
                users_in_group.extend(sales_person)
            users = functools.reduce(operator.iconcat, users_in_group, [])
        for user in users:
            if user.email:
                vals = {
                    "subject" : 'Lead Stage Updated',
                    "body_html": f"{self.partner_id.name} Opportunity updated to {updated_stage.name} by {self.env.user.name}",
                    "email_to": user.login,
                    "email_cc": user.login,
                    "auto_delete": False,
                    "email_from": outgoing_mail_server.smtp_user,
                }
                mail_id = self.env["mail.mail"].sudo().create(vals)
                mail_id.sudo().send()
