{
    "name": "BI Crm Lead",
    "version": "17.0",
    "summary": """ Lead Access Control""",
    "description": """Lead Access Control""",
    "author": "Bassam Infotech LLP",
    "company": "Bassam Infotech LLP",
    "maintainer": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "category": "CRM",
    "depends": ["base","crm","bi_crm_customization"],
    "data": [
        "security/security.xml",
        "views/crm_lead_view.xml"
    ],
    "images": [],
    "license": "OPL-1",
    "installable": True,
    "application": False,
}
