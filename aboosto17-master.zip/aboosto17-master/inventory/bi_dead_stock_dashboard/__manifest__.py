{
    'name': 'Dead Stock Dashboard',
    'version': '17.0.1.0.1',
    'category': 'Dashboard',
    'summary': 'Detailed dashboard view for Dashboard module.',
    'description': """This module presents a detailed Dead stock dashboard view for the
    Dashboard module, delivering a comprehensive and concise overview that
    serves as a valuable tool for both Dashboard users and administrators.""",
    "author": "Bassam Infotech LLP",
    "company": "Bassam Infotech LLP",
    "maintainer": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    'depends': ['stock', 'base'],
    'data': [
        'views/res_config_settings_views.xml',
        'views/dashboard_menu.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&amp;display=swap',
            'bi_dead_stock_dashboard/static/src/css/dashboard.css',
            'bi_dead_stock_dashboard/static/src/js/dashboard.js',
            'bi_dead_stock_dashboard/static/src/xml/inventory_dashboard_template.xml',
            'https://cdn.jsdelivr.net/npm/chart.js',
        ],
    },
    'images': ['static/description/icon.png'],
    'license': 'OPL-1',
    'installable': True,
    'auto_install': False,  
    'application': False,
}
