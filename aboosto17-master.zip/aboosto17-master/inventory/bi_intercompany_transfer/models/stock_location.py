from odoo import models, fields 

class StockLocation(models.Model):
    _inherit ="stock.location"
    
    is_intercomp_location = fields.Boolean(string = "Is Inter Company Transfer")