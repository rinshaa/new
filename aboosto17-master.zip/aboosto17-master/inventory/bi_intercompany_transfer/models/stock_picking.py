from odoo import models, fields, api, _ 
from odoo.exceptions import UserError 

class StockPicking(models.Model):
    _inherit = "stock.picking"
    
    inter_company_transfer = fields.Boolean(string = "Inter-company Transfer")

    # def button_validate(self):
    #     """Creating the internal transfer if it is not created from another picking"""
    #     res = super(StockPicking, self).button_validate()
    #     if self.inter_company_transfer:
    #         if self.picking_type_code == 'internal' and self.partner_id:
    #             company = self.env['res.company'].sudo().search([('name', '=', self.partner_id.name)])
    #             company_partner = company.partner_id
    #             if not company:
    #                 raise UserError(_("Please select company in contact for Inter-company transfer"))
    #
    #             location_src_id = self.env['stock.location'].sudo().search(
    #                 [('is_intercomp_location', '=', True), ('usage', '=', 'transit')])
    #             location_dest_id = self.env['stock.location'].sudo().search(
    #                 [('company_id', '=', company.sudo().id), ('replenish_location', '=', True)])
    #             operation_type_id = self.env['stock.picking.type'].sudo().search(
    #                 [('code', '=', 'internal'), ('company_id', '=', company.id),
    #                  ('default_location_src_id', '=', location_src_id.sudo().id),
    #                  ('default_location_dest_id', '=', location_dest_id.sudo().id)])
    #             if location_src_id and location_dest_id:
    #                 picking_vals = {
    #                     'partner_id': self.env.company.partner_id.id,
    #                     'company_id': company.id,
    #                     'picking_type_id': operation_type_id.id,
    #                     'location_id': location_src_id.id,
    #                     'location_dest_id': location_dest_id.id,
    #                     'inter_company_transfer': False,
    #                     'origin': self.name,
    #                 }
    #             picking_id = self.env['stock.picking'].sudo().create(picking_vals)
    #
    #             for move in self.move_ids:
    #                 lines = self.move_line_ids.filtered(lambda x: x.product_id == move.product_id)
    #                 done_qty = sum(lines.mapped('quantity_product_uom'))
    #                 if not done_qty:
    #                     done_qty = sum(lines.mapped('quantity'))
    #                 product = self.env['product.product'].sudo().search(
    #                     [('name', '=', move.product_id.name), ('company_id', '=', company.id)], limit=1)
    #                 unit_cost = sum(move.stock_valuation_layer_ids.mapped('unit_cost'))
    #                 currency = self.env.company.currency_id
    #                 unit_cost_after_conversion = currency._convert(unit_cost, company.currency_id, self.company_id,
    #                                                                self.scheduled_date or fields.Date.today())
    #                 move_vals = {
    #                     'picking_id': picking_id.id,
    #                     'picking_type_id': operation_type_id.id,
    #                     'name': move.name,
    #                     'product_id': product.id,
    #                     'product_uom': product.uom_id.id,
    #                     'price_unit': unit_cost_after_conversion,
    #                     'product_uom_qty': done_qty,
    #                     'location_id': location_src_id.id,
    #                     'location_dest_id': location_dest_id.id,
    #                     'company_id': company.id
    #                 }
    #                 self.env['stock.move'].sudo().create(move_vals)
    #             if picking_id:
    #                 picking_id.sudo().action_confirm()
    #                 picking_id.sudo().action_assign()
    #
    #         # to create journal entry
    #         account_receivable = self.env['account.account'].search(
    #             [('reconcile', '=', True), ('code', '=', '203010'), ('company_id', '=', self.company_id.id)])
    #         # account_payable = self.env['account.account'].search([('reconcile','=',True),('code','=','201003'),('company_id','=',self.company_id.id)])
    #         # stock_interim_received = self.env['account.account'].search([('reconcile','=',True),('code','=','110200'),('company_id','=',self.company_id.id)])
    #         stock_interim_delivered = self.env['account.account'].search(
    #             [('reconcile', '=', True), ('code', '=', '110300'), ('company_id', '=', self.company_id.id)])
    #         # account_receivable_other_company =  self.env['account.account'].sudo().search([('reconcile','=',True),('code','=','203010'),('company_id','=',company.id)])
    #         account_payable_other_company = self.env['account.account'].sudo().search(
    #             [('reconcile', '=', True), ('code', '=', '201003'), ('company_id', '=', company.id)])
    #         stock_interim_received_other_company = self.env['account.account'].sudo().search(
    #             [('reconcile', '=', True), ('code', '=', '110200'), ('company_id', '=', company.id)])
    #         # stock_interim_delivered_other_company = self.env['account.account'].sudo().search([('reconcile','=',True),('code','=','110300'),('company_id','=',company.id)])
    #
    #         amount = done_qty * unit_cost
    #         amount_res_company = done_qty * unit_cost_after_conversion
    #         journal_id = self.env['account.journal'].search(
    #             [('type', '=', 'general'), ('code', '=', 'MISC'), ('company_id', '=', self.company_id.id)])
    #         journal_res_company_id = self.env['account.journal'].sudo().search(
    #             [('type', '=', 'general'), ('code', '=', 'MISC'), ('company_id', '=', company.id)])
    #
    #         move_line_vals_1 = {
    #             'name': _('Inter Company Transfer'),
    #             'account_id': account_receivable.id,
    #             'partner_id': company_partner.id,
    #             'debit': amount,
    #             'credit': 0,
    #         }
    #         move_line_vals_2 = {
    #             'name': _('Inter Company Transfer'),
    #             'account_id': stock_interim_delivered.id,
    #             'partner_id': company_partner.id,
    #             'debit': 0,
    #             'credit': amount,
    #         }
    #         move_val = [move_line_vals_1, move_line_vals_2]
    #
    #         account_vals = {
    #             'company_id': self.company_id.id,
    #             'journal_id': journal_id.id,
    #             'ref': picking_id.name,
    #             'date': fields.Date.today(),
    #             'line_ids': [(0, 0, line) for line in move_val]
    #         }
    #         account_journal = self.env['account.move'].create(account_vals)
    #         if account_journal:
    #             account_journal.sudo().action_post()
    #
    #         move_line_other_company_vals_1 = {
    #             'name': _('Inter Company Transfer'),
    #             'account_id': account_payable_other_company.id,
    #             'partner_id': self.env.company.partner_id.id,
    #             'debit': 0,
    #             'credit': amount_res_company,
    #         }
    #         move_line_other_company_vals_2 = {
    #             'name': _('Inter Company Transfer'),
    #             'account_id': stock_interim_received_other_company.id,
    #             'partner_id': self.env.company.partner_id.id,
    #             'debit': amount_res_company,
    #             'credit': 0,
    #         }
    #         move_val_other_company = [move_line_other_company_vals_1, move_line_other_company_vals_2]
    #
    #         account_other_company_vals = {
    #             'company_id': company.id,
    #             'journal_id': journal_res_company_id.id,
    #             'ref': picking_id.name,
    #             'date': fields.Date.today(),
    #             'line_ids': [(0, 0, line) for line in move_val_other_company]
    #         }
    #         account_journal_other_company = self.env['account.move'].sudo().create(account_other_company_vals)
    #
    #         if account_journal_other_company:
    #             account_journal_other_company.sudo().action_post()
    #
    #         #  self.env['account.move.line'].create({
    #         #         'name': _('Automatic Balancing Line'),
    #         #         'move_id': self.account_opening_move_id.id,
    #         #         'account_id': balancing_account.id,
    #         #         'debit': amount,
    #         #         'credit': amount,
    #         #     })
    #         # self.env['account.move.line'].create(move_vals)
    #
    #         #  picking_vals = {
    #         #             'partner_id': self.env.company.partner_id.id,
    #         #             'company_id': company.id,
    #         #             'picking_type_id': operation_type_id.id,
    #         #             'location_id': location_src_id.id,
    #         #             'location_dest_id': location_dest_id.id,
    #         #             'inter_company_transfer':False,
    #         #             'origin': self.name,
    #         #         }
    #         #     picking_id = self.env['stock.picking'].sudo().create(picking_vals)
    #
    #     return res
    
    def button_validate(self):
        """Creating the internal transfer if it is not created from another picking"""
        res = super(StockPicking, self).button_validate()
        if self.inter_company_transfer:
            if self.picking_type_code == 'internal' and self.partner_id:
                company = self.env['res.company'].sudo().search([('name','=',self.partner_id.name)])
                company_partner = company.partner_id
                if not company:
                    raise UserError(_("Please select company in contact for Inter-company transfer"))
               
                location_src_id = self.env['stock.location'].sudo().search([('is_intercomp_location','=',True),('usage','=','transit')])
                location_dest_id = self.env['stock.location'].sudo().search([('company_id','=',company.sudo().id),('replenish_location','=',True)])
                operation_type_id = self.env['stock.picking.type'].sudo().search([('code', '=', 'internal'),('company_id','=',company.id),('default_location_src_id','=',location_src_id.sudo().id),('default_location_dest_id','=',location_dest_id.sudo().id)])
                if location_src_id and location_dest_id:
                        picking_vals = {
                        'partner_id': self.env.company.partner_id.id,
                        'company_id': company.id,
                        'picking_type_id': operation_type_id.id,
                        'location_id': location_src_id.id,
                        'location_dest_id': location_dest_id.id,
                        'inter_company_transfer':False,
                        'origin': self.name,
                    }
                picking_id = self.env['stock.picking'].sudo().create(picking_vals)
                
                for move in self.move_ids:
                    lines = self.move_line_ids.filtered(lambda x: x.product_id == move.product_id)
                    done_qty = sum(lines.mapped('quantity_product_uom'))
                    if not done_qty:
                        done_qty = sum(lines.mapped('quantity'))
                    # product = self.env['product.product'].sudo().search([('name','=',move.product_id.name),('company_id','=',company.id)],limit=1)
                    # If in the case of products are configured with the Parent company instead of each branches.
                    if self.company_id.parent_id and company.parent_id:
                        product = self.env['product.product'].sudo().search(
                            [('name', '=', move.product_id.name),('company_id', '=', company.parent_id.id)], limit=1)
                    else:
                        product = self.env['product.product'].sudo().search(
                            [('name', '=', move.product_id.name),  '|', ('company_id','=',company.id), ('company_id', '=', company.parent_id.id)], limit=1)    
                    unit_cost =  sum(move.stock_valuation_layer_ids.mapped('unit_cost'))
                    currency = self.env.company.currency_id
                    unit_cost_after_conversion = currency._convert(unit_cost, company.currency_id, self.company_id, self.scheduled_date or fields.Date.today())
                    move_vals = {
                        'picking_id': picking_id.id,
                        'picking_type_id': operation_type_id.id,
                        'name': move.name,
                        'product_id': product.id,
                        'product_uom': product.uom_id.id,
                        'price_unit': unit_cost_after_conversion,
                        'product_uom_qty': done_qty,
                        'location_id': location_src_id.id,
                        'location_dest_id': location_dest_id.id,
                        'company_id': company.id
                    }
                    self.env['stock.move'].sudo().create(move_vals)
                if picking_id:
                    picking_id.sudo().action_confirm()
                    picking_id.sudo().action_assign()
                    
            #to create journal entry
            if self.company_id.parent_id:
                account_receivable = self.env['account.account'].search([('reconcile','=',True),('code','=','203010'),('company_id','=',self.company_id.parent_id.id)])
            else:
                account_receivable = self.env['account.account'].search([('reconcile','=',True),('code','=','203010'),('company_id','=',self.company_id.id)])
            # account_payable = self.env['account.account'].search([('reconcile','=',True),('code','=','201003'),('company_id','=',self.company_id.id)])
            # stock_interim_received = self.env['account.account'].search([('reconcile','=',True),('code','=','110200'),('company_id','=',self.company_id.id)])
            if self.company_id.parent_id:
                stock_interim_delivered = self.env['account.account'].search([('reconcile','=',True),('code','=','110300'),('company_id','=',self.company_id.parent_id.id)])
            else:
                stock_interim_delivered = self.env['account.account'].search([('reconcile','=',True),('code','=','110300'),('company_id','=',self.company_id.id)])
            # account_receivable_other_company =  self.env['account.account'].sudo().search([('reconcile','=',True),('code','=','203010'),('company_id','=',company.id)])
            # account_payable_other_company = self.env['account.account'].sudo().search([('reconcile','=',True),('code','=','201003'),('company_id','=',company.id)])
            # If in the case of products are configured with the Parent company instead of each branches.
            account_payable_other_company = self.env['account.account'].sudo().search([('reconcile','=',True),('code','=','201003'), '|', ('company_id','=',company.id), ('company_id', '=', company.parent_id.id)])
            # stock_interim_received_other_company = self.env['account.account'].sudo().search([('reconcile','=',True),('code','=','110200'),('company_id','=',company.id)])
            # If in the case of products are configured with the Parent company instead of each branches.
            stock_interim_received_other_company = self.env['account.account'].sudo().search([('reconcile','=',True),('code','=','110200'), '|', ('company_id','=',company.id), ('company_id', '=', company.parent_id.id)])
            # stock_interim_delivered_other_company = self.env['account.account'].sudo().search([('reconcile','=',True),('code','=','110300'),('company_id','=',company.id)])
            
            amount = done_qty * unit_cost
            amount_res_company = done_qty * unit_cost_after_conversion
            if self.company_id.parent_id:
                journal_id = self.env['account.journal'].search([('type','=','general'),('code','=','MISC'),('company_id','=',self.company_id.parent_id.id)])
            else:
                journal_id = self.env['account.journal'].search([('type','=','general'),('code','=','MISC'),('company_id','=',self.company_id.id)])    
            # If in the case of products are configured with the Parent company instead of each branches.
            journal_res_company_id = self.env['account.journal'].sudo().search([('type','=','general'),('code','=','MISC'), '|', ('company_id','=',company.id), ('company_id', '=', company.parent_id.id)])

            move_line_vals_1 = {
                       'name': _('Inter Company Transfer'),
                        'account_id': account_receivable.id,
                        'partner_id':company_partner.id,
                        'debit': amount,
                        'credit': 0,
                     }
            move_line_vals_2 = {
                       'name': _('Inter Company Transfer'),
                        'account_id': stock_interim_delivered.id,
                        'partner_id':company_partner.id,
                        'debit': 0,
                        'credit': amount,
                    }
            move_val = [move_line_vals_1,move_line_vals_2]
            

            
            account_vals = {
                        'company_id':self.company_id.id,
                        'journal_id':journal_id.id,
                        'ref':picking_id.name,
                        'date':fields.Date.today(),
                        'line_ids':[(0, 0, line) for line in move_val]        
                }
            account_journal = self.env['account.move'].create(account_vals)
            if account_journal:
                    account_journal.sudo().action_post()
            
            
            move_line_other_company_vals_1 = {
                       'name': _('Inter Company Transfer'),
                        'account_id': account_payable_other_company.id,
                        'partner_id':self.env.company.partner_id.id,
                        'debit': 0,
                        'credit': amount_res_company,
                     }
            move_line_other_company_vals_2 = {
                       'name': _('Inter Company Transfer'),
                        'account_id': stock_interim_received_other_company.id,
                        'partner_id':self.env.company.partner_id.id,
                        'debit': amount_res_company,
                        'credit': 0,
                    }
            move_val_other_company = [move_line_other_company_vals_1,move_line_other_company_vals_2]
 
            account_other_company_vals = {
                        'company_id':company.id,
                        'journal_id':journal_res_company_id.id,
                        'ref':picking_id.name,
                        'date':fields.Date.today(),
                        'line_ids':[(0, 0, line) for line in move_val_other_company]      
                }
            account_journal_other_company = self.env['account.move'].sudo().create(account_other_company_vals)
            
            if account_journal_other_company:
                    account_journal_other_company.sudo().action_post()
            
            
                #  self.env['account.move.line'].create({
                #         'name': _('Automatic Balancing Line'),
                #         'move_id': self.account_opening_move_id.id,
                #         'account_id': balancing_account.id,
                #         'debit': amount,
                #         'credit': amount,
                #     })
            # self.env['account.move.line'].create(move_vals)
            
            

            #  picking_vals = {
            #             'partner_id': self.env.company.partner_id.id,
            #             'company_id': company.id,
            #             'picking_type_id': operation_type_id.id,
            #             'location_id': location_src_id.id,
            #             'location_dest_id': location_dest_id.id,
            #             'inter_company_transfer':False,
            #             'origin': self.name,
            #         }
            #     picking_id = self.env['stock.picking'].sudo().create(picking_vals)
                     
 
        return res
    
    