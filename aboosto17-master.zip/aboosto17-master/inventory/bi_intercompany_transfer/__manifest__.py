{
    'name': 'BI Stock Inter Transfer',
    'summary': ''' Stock Inter Transfer ''',
    'description': '''Stock Inter Transfer''',
    'author': 'Bassam Infotech LLP',
    'company': 'Bassam Infotech LLP',
    'maintainer': 'Bassam Infotech LLP',
    'website': 'https://bassaminfotech.com',
    'category': 'stock',
    'depends': ['stock'],
    "version": "17.0.1.0.0",
    'data': [
        'views/stock_location.xml',
        'views/stock_picking.xml'
    ],
    'images': [],
    'license': 'OPL-1',
    'installable': True,
    'application': False,
}
