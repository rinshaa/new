from odoo import api, fields, models, tools
from odoo.tools import float_compare, float_is_zero
from lxml import etree


class StockValuationLayer(models.Model):
    _inherit = 'stock.valuation.layer'

    # @api.model
    # def fields_get(self, allfields=None, attributes=None):
    #     fields = super().fields_get(allfields, attributes)
    #     print("fields___", fields)
    #     if 'value' in fields:
    #         fields['value'].update({'invisible': True})
    #         fields['remaining_value'].update({'invisible': True})
    #         fields['value'].update({'invisible': True})
    #     print("fields___after___", fields)
    #     return fields
