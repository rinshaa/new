from . import product
from . import pos_stock_min_rule
from . import stock_picking
from . import product_brand
from . import product_template