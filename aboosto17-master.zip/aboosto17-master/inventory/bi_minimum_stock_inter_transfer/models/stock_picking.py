from odoo import api, fields, models, _
from odoo.exceptions import UserError
from odoo.tools import float_is_zero, float_compare


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    test_field_one = fields.Char(string='TEST ONE')

    @api.model
    def _create_picking_from_pos_order_lines(self, location_dest_id, lines, picking_type, partner=False):
        res = super(StockPicking, self)._create_picking_from_pos_order_lines(location_dest_id, lines, picking_type,
                                                                             partner=False)
        stockable_lines = lines.filtered(
            lambda l: l.product_id.type in ['product', 'consu'] and not float_is_zero(l.qty,
                                                                                      precision_rounding=l.product_id.uom_id.rounding))
        if stockable_lines:
            for stockable_line in stockable_lines:
                pos_min_stock_rule_id = self.env['pos.stock.min.rule'].search(
                    [('product_categ_id', '=', stockable_line.product_id.categ_id.id),
                     ('destination_location_id', '=', picking_type.default_location_src_id.id)], limit=1)
                qty_on_hand = self.env['stock.quant']._get_available_quantity(stockable_line.product_id,
                                                                              picking_type.default_location_src_id)
                if pos_min_stock_rule_id and qty_on_hand <= pos_min_stock_rule_id.product_min_quantity:
                    internal_picking_id = self.env['stock.picking.type'].search(
                        [('code', '=', 'internal'), ('company_id', '=', self.env.company.id)], limit=1)
                    existing_move_id = self.env['stock.move'].search([('product_id', '=', stockable_line.product_id.id),
                                                                      ('product_uom_qty', '=',
                                                                       pos_min_stock_rule_id.product_max_quantity),
                                                                      ('location_id', '=',
                                                                       pos_min_stock_rule_id.location_id.id),
                                                                      ('location_dest_id', '=',
                                                                       pos_min_stock_rule_id.destination_location_id.id),
                                                                      ('picking_id.picking_type_id', '=',
                                                                       internal_picking_id.id),
                                                                      ('picking_id.state', '=', 'draft'),
                                                                      ])
                    if not existing_move_id:
                        picking_id = self.env['stock.picking'].create(
                            {
                                'move_type': 'direct',
                                'location_id': pos_min_stock_rule_id.location_id.id,
                                'location_dest_id': pos_min_stock_rule_id.destination_location_id.id,
                                'state': 'draft',
                                'picking_type_id': internal_picking_id.id,
                                'move_ids_without_package': [(0, 0, {
                                    'name': stockable_line.product_id.name,
                                    'product_id': stockable_line.product_id.id,
                                    'product_uom': stockable_line.product_id.uom_id.id,
                                    'product_uom_qty': pos_min_stock_rule_id.product_max_quantity,
                                    'location_id': pos_min_stock_rule_id.location_id.id,
                                    'location_dest_id': pos_min_stock_rule_id.destination_location_id.id,
                                })]
                            }
                        )
        return res
