from odoo import api, fields, models, _
from odoo.exceptions import UserError


class PosStockMinRule(models.Model):
    _name = 'pos.stock.min.rule'
    _description = "Minimum POS Stock Rule"

    company_id = fields.Many2one(
        'res.company', 'Company',
        default=lambda self: self.env.company, index=True)
    # product_id = fields.Many2one('product.product', string='Product')
    product_categ_id = fields.Many2one('product.category', string='Product Category')
    location_id = fields.Many2one(
        'stock.location', 'Source Location')
    destination_location_id = fields.Many2one(
        'stock.location', 'Destination Location')
    # qty_on_hand = fields.Float('On Hand', readonly=True, compute='_compute_on_hand_qty',
    #                            digits='Product Unit of Measure')
    product_min_quantity = fields.Float(string='Min Quantity')
    product_max_quantity = fields.Float(string='Max Quantity')

    # def _compute_on_hand_qty(self):
    #     for rec in self:
    #         rec.qty_on_hand = self.env['stock.quant']._get_available_quantity(rec.product_id, rec.destination_location_id)
