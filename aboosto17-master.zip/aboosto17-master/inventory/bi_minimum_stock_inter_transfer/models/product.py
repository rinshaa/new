from odoo import api, fields, models, _
from odoo.exceptions import UserError


class ProductProduct(models.Model):
    _inherit = 'product.product'

    # def action_view_related_pos_min_rules(self):
    #     self.ensure_one()
    #     domain = [
    #         ('product_id', '=', self.id),
    #     ]
    #     return self.env['product.template']._get_action_view_related_pos_min_rules(domain)

    @api.model
    def default_get(self, fields_list):
        defaults = super(ProductProduct,self).default_get(fields_list)
        defaults['company_id'] = self.env.company.id
        return defaults


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    @api.model
    def default_get(self, fields_list):
        defaults = super(ProductTemplate,self).default_get(fields_list)
        defaults['company_id'] = self.env.company.id
        return defaults

    # def action_view_related_pos_min_rules(self):
    #     self.ensure_one()
    #     domain = [
    #         ('product_id', '=', self.id),
    #     ]
    #     return self._get_action_view_related_pos_min_rules(domain)

    # @api.model
    # def _get_action_view_related_pos_min_rules(self, domain):
    #     return {
    #         'name': _('POS Min Stock Rules'),
    #         'type': 'ir.actions.act_window',
    #         'res_model': 'pos.stock.min.rule',
    #         'view_mode': 'list',
    #         'domain': domain,
    #         'context': {'product_id': self.product_variant_ids.ids}
    #     }
