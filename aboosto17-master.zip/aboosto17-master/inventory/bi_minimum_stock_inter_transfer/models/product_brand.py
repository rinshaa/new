from odoo import api, fields, models, _
from odoo.exceptions import UserError


class ProductBrand(models.Model):
    _name = 'product.brand'
    _description = 'Product Brand'

    name = fields.Char(string="Name")