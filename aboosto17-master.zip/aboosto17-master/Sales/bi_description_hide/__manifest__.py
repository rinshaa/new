{
    "name": "Description Hide",
    "summary": """ Description Hide""",
    "description": """Description Hide""",
    "author": "Bassam Infotech LLP",
    "company": "Bassam Infotech LLP",
    "maintainer": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "category": "Sales",
    "version": "17.0.0.1",
    "depends": ['sale','account'],
    "data": [
        'views/sale_order.xml',
        'views/account_move.xml',
        'views/report_invoice.xml'
    ],
    "images": [],
    "license": "OPL-1",
    "installable": True,
    "application": False,
}
