{
    'name': 'BI Phone Country Code',
    'summary': ''' BI Phone Country Code ''',
    'description': '''BI Phone Country Code''',
    'author': 'Bassam Infotech LLP',
    'company': 'Bassam Infotech LLP',
    'maintainer': 'Bassam Infotech LLP',
    'website': 'https://bassaminfotech.com',
    'category': 'stock',
    'depends': ['sale', 'point_of_sale'],
    'version': '17.0.0.1',
    # 'data': [
    #     'data/mail_template_data.xml',
    #     'data/whatsapp_template_data.xml',
    # ],

    'assets': {
        'point_of_sale._assets_pos': [
            'bi_phone_country_code/static/src/js/country_code.js',
            'bi_phone_country_code/static/src/xml/partner_details.xml'
        ]
    },
    'images': [],
    'license': 'OPL-1',
    'installable': True,
    'application': False,
}
