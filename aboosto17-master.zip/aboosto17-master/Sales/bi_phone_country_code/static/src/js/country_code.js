/** @odoo-module */

import { PartnerDetailsEdit } from "@point_of_sale/app/screens/partner_list/partner_editor/partner_editor";
import { patch } from "@web/core/utils/patch";
import { _t } from "@web/core/l10n/translation";

patch(PartnerDetailsEdit.prototype, {
    /**
     * Triggered when the country dropdown changes.
     * @param {Event} ev - The change event
     */
    async onCountryChange(ev) {
        console.log("Country change event:", ev);
        const countryId = parseInt(ev.target.value);
        console.log("Selected country ID:", countryId);

        // Find the country in the preloaded list
        const country = this.pos.countries.find(c => c.id === countryId);

        if (country) {
            console.log("Selected country:", country);
            try {
                // Use searchRead to fetch the country details
                const result = await this.env.services.orm.searchRead(
                    "res.country",
                    [["id", "=", country.id]],
                    ["phone_code"] // Fetch only the required field
                );
                if (result.length > 0) {
                    const countryPhoneCode = result[0].phone_code;
                    console.log("Fetched phone code:", countryPhoneCode);
                    if(countryPhoneCode){
                        console.log("knlknln",countryPhoneCode)
                        console.log(this,'111111111111')
                        if (countryPhoneCode) {
                            console.log("Phone code exists:", countryPhoneCode);
                            if (this.changes.phone) {
                                this.changes.phone = `+${countryPhoneCode} ${this.changes.phone}`;
                            } else {
                                // Set countryPhoneCode as the phone value
                                this.changes.phone = `+${countryPhoneCode}`;
                            }
                            if (this.changes.mobile) {
                                this.changes.mobile = `+${countryPhoneCode} ${this.changes.mobile}`
                            } else {
                                // Set countryPhoneCode as the mobile value
                                this.changes.mobile = `+${countryPhoneCode}`
                            }
                        }


                    }
                } else {
                    console.warn("No country found with the given ID.");
                }
            
            } catch (error) {
                console.error("Error fetching country code:", error);
            }
        } else {
            console.error("Country not found in the list.");
        }
    },
});

