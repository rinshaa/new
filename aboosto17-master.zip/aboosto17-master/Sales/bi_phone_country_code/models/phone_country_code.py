from odoo import models, fields, api

class ResPartner(models.Model):
    _inherit = 'res.partner'

    @api.onchange('country_id')
    def _onchange_country_code(self):
        self.phone = False 
        if self.country_id:
            country_code = self.country_id.phone_code
            formatted_country_code = f"+{str(country_code)}" if not str(country_code).startswith('+') else str(country_code)

            if self.phone and not self.phone.startswith(formatted_country_code):
                self.phone = f"{formatted_country_code} {self.phone}"
            elif not self.phone:
                self.phone = f"{formatted_country_code} "







