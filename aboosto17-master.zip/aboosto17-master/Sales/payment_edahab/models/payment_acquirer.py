import logging

from odoo import fields, models

_logger = logging.getLogger(__name__)


class PaymentAcquirer(models.Model):
    _inherit = 'payment.provider'

    code = fields.Selection(selection_add=[('edahab', "eDahab")], ondelete={'edahab': 'set default'})
    api_key = fields.Char("API Key", required_if_provider='edahab', default='')
    secret = fields.Char("Secret Key", required_if_provider='edahab', default='')
    agent_code = fields.Char("Agent Code", required_if_provider='edahab', default='')

    def _get_default_payment_method_id(self, *_args):
        self.ensure_one()
        if self.code != 'edahab':
            return super()._get_default_payment_method_id()
        return self.env.ref('payment_edahab.payment_method_edahab').id

