import http.client
import requests
import logging
import re
import unicodedata

import xml.etree.ElementTree as ET
from datetime import datetime

from odoo import models, _, api, fields
from odoo.exceptions import ValidationError, UserError
from odoo.tools import float_compare
from werkzeug import urls

import hashlib
import json
from odoo.http import request
import time

_logger = logging.getLogger(__name__)


class PaymentTransaction(models.Model):
    _inherit = 'payment.transaction'

    def _get_specific_rendering_values(self, processing_values):
        res = super()._get_specific_rendering_values(processing_values)
        if self.provider_code != 'edahab':
            return res
        rendering_values = {}
        partner_id = self.env['res.partner'].browse(processing_values.get('partner_id'))
        amount = processing_values.get('amount')
        base_currency_id = self.env['res.currency'].browse(processing_values.get('currency_id'))
        if base_currency_id.name != 'USD':
            usd_currency_id = self.env['res.currency'].search([('name', '=', 'USD')], limit=1)
            amount = base_currency_id._convert(
                            processing_values.get('amount'),
                            usd_currency_id,
                            self.env.company,
                            fields.Date.context_today(self),
                        )
        request_params = {
            "apiKey": self.provider_id.api_key,
            "edahabNumber": partner_id.mobile if partner_id.mobile else partner_id.phone,
            "amount": amount,
            "agentCode": self.provider_id.agent_code,
            "returnUrl": f"{self.get_base_url()}/payment/edahab/return/{self.reference}",
            # "currency": "SLSH",
        }

        # Encode request params as JSON string (unescaped slashes)
        json_data = json.dumps(request_params, separators=(',', ':'))

        # Generate SHA256 hash
        secret = self.provider_id.secret
        hashed_data = hashlib.sha256((json_data + secret).encode("utf-8")).hexdigest()

        # Construct the URL with hash parameter
        url = f"https://edahab.net/api/api/IssueInvoice?hash={hashed_data}"

        # Prepare request headers
        headers = {"Content-Type": "application/json"}
        try:
            # pass
            # Send POST request with JSON data
            response = requests.post(url, data=json_data, headers=headers, timeout=1)
            response.raise_for_status()  # Raise exception for non-200 status codes

            # Process the API response
            response_data = response.json()
            self.provider_reference = response_data.get('InvoiceId')

        except requests.exceptions.RequestException as e:
            print(f"Error making API request: {e}")
            raise UserError(_(e))
        time.sleep(10)  # Pause for 10 seconds
        if response_data.get('StatusDescription') == 'Success':
            rendering_values.update({
                'api_url': 'https://edahab.net/api/payment?invoiceId=%s' % response_data.get('InvoiceId'),
            })
        else:
            if response_data.get('ValidationErrors'):
                raise UserError(_(response_data.get('ValidationErrors')))
            else:
                raise UserError(_(response_data.get('StatusDescription')))
        return rendering_values

    @api.model
    def _get_tx_from_notification_data(self, provider, data):
        tx = super()._get_tx_from_notification_data(provider, data)
        if provider != 'edahab':
            return tx

        reference = data
        tx = self.search([('reference', '=', reference), ('provider_code', '=', 'edahab')])
        if not tx:
            raise ValidationError(
                "eDahab: " + _("No transaction found matching reference %s.", reference)
            )
        return tx

    def _process_notification_data(self, data):
        super()._process_notification_data(data)
        if self.provider_code != 'edahab':
            return

        request_param = {
            "apiKey": self.provider_id.api_key,
            "invoiceId": self.provider_reference
        }
        # Encode it into a JSON string.
        json_data = json.dumps(request_param, separators=(',', ':'))
        secret = self.provider_id.secret
        hashed = hashlib.sha256((json_data + secret).encode()).hexdigest()
        url = "https://edahab.net/api/api/CheckInvoiceStatus?hash=" + hashed
        response = requests.post(url, data=json_data, headers={'Content-Type': 'application/json'})
        response_data = response.json()
        if response_data.get('InvoiceStatus') == 'Paid':
            self._set_done()
        else:
            self._set_pending()

