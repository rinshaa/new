#
# Copyright (c) 2024 DPO Group (Pty) Ltd
#
# Author: App Inlet (Pty) Ltd
#
# Released under the GNU General Public License
#

import logging
import pprint

from odoo import http
from odoo.http import request

_logger = logging.getLogger(__name__)


class eDahabController(http.Controller):

    @http.route('/payment/edahab/return/<string:order_reference>', type='http', auth="public", methods=['GET'])
    def edahab_return_from_redirect(self, order_reference, **data):
        """ edahab Pay return """
        print("order_reference___", order_reference)
        print("edahab_return_from_redirect__data___", data)
        _logger.info("received eDahab Payment return data:\n%s", pprint.pformat(data))
        request.env['payment.transaction'].sudo()._handle_notification_data('edahab', order_reference)
        return request.redirect('/payment/status')
