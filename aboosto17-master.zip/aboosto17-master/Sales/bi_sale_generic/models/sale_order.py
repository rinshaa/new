
from odoo import _, api, fields, models

class SaleOrder(models.Model):
    _inherit = "sale.order"

    #Super create method to make direct sale order while quotation created from website
    @api.model_create_multi
    def create(self, vals_list):
        sale_orders = super(SaleOrder, self).create(vals_list)
        for sale_order in sale_orders:
            website_id = next((vals.get('website_id') for vals in vals_list if vals.get('website_id') == sale_order.website_id.id), False)
            if website_id:
                if sale_order.website_id:
                    sale_order.sudo().action_confirm()
        return sale_orders