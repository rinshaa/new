{
    "name": "Sales Generic Customisation",
    "summary": """ Sales Generic Customisation""",
    "description": """Sales Generic Customisation""",
    "author": "Bassam Infotech LLP",
    "company": "Bassam Infotech LLP",
    "maintainer": "Bassam Infotech LLP",
    "website": "https://bassaminfotech.com",
    "category": "Sales",
    "version": "17.3",
    "depends": ["sale","sale_management","website_sale"],
    "data": [
        "views/sale_order.xml",
    ],
    "images": [],
    "license": "OPL-1",
    "installable": True,
    "application": False,
}
