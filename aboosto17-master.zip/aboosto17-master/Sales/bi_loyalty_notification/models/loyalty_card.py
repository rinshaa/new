from odoo import api, fields, models, tools


class LoyaltyCard(models.Model):
    _inherit = 'loyalty.card'

    last_addon_point = fields.Float(string='Last addon point')
    # last_addon_sale_id = fields.Many2one('sale.order', string='Last addon sale')
    # last_addon_pos_order_id = fields.Many2one('sale.order', string='Last addon POS Order')
    last_addon_order_ref = fields.Char(string='Last addon Order Ref')
    name = fields.Char()

    def send_wa_message(self):
        whatsapp_composer = self.env['whatsapp.composer'].with_context({'active_id': self.id}).create(
            {
                'phone': self.partner_id.mobile,
                'wa_template_id': self.env.ref(
                    'bi_loyalty_notification.whatsapp_template_loyalty_points_loyalty_card').id,
                'res_model': 'loyalty.card'
            }
        )
        whatsapp_composer._send_whatsapp_template()

    def send_sms(self):
        sms_body = (f"Loyalty Reward\nHello {self.partner_id.name}, Congratulations! You earned "
                    f"{self.last_addon_point} Loyalty Points from your order {self.last_addon_order_ref}.\n"
                    f"Your Total Loyalty Points: {self.points}\n"
                    f"Use this promo code: {self.code} on your next order\n"
                    f"Thank You")
        sms_values = [{'partner_id': self.partner_id.id, 'body': sms_body, 'number': self.partner_id.mobile}]
        self.env['sms.sms'].sudo().create(sms_values).send()
