import logging
import pprint

from odoo import http
from odoo.http import request

_logger = logging.getLogger(__name__)


class PesapalController(http.Controller):

    @http.route('/RegisterIPN', type='http', auth="public", methods=['GET', 'POST'],
                csrf=False)
    def pesapal_register_ipn(self, **data):
        return True

    @http.route('/payment/pesapal/redirect', type='http', auth="public", methods=['GET', 'POST'], csrf=False)
    def pesapal_return_from_redirect(self, **data):
        """ Pesapal return """
        order_reference = data.get('OrderMerchantReference')
        _logger.info("received Pesapal Payment return data:\n%s", pprint.pformat(data))
        request.env['payment.transaction'].sudo()._handle_notification_data('pesapal', dict(data, merchantReference=order_reference))
        return request.redirect('/payment/status')
