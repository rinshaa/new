import logging

from odoo import fields, models

_logger = logging.getLogger(__name__)


class PaymentAcquirer(models.Model):
    _inherit = 'payment.provider'

    code = fields.Selection(selection_add=[('pesapal', "Pesapal")], ondelete={'pesapal': 'set default'})
    consumer_key = fields.Char(string="Consumer Key", required_if_provider='pesapal')
    consumer_secret = fields.Char(string="Consumer Secret", required_if_provider='pesapal')

    def _get_default_payment_method_id(self, *_args):
        self.ensure_one()
        if self.code != 'pesapal':
            return super()._get_default_payment_method_id()
        return self.env.ref('payment_pesapal.payment_method_pesapal').id

