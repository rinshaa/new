import http.client
import requests
import logging
import re
import unicodedata

import xml.etree.ElementTree as ET
from datetime import datetime

from odoo import models, _, api, fields
from odoo.exceptions import ValidationError, UserError
from odoo.tools import float_compare
from werkzeug import urls

import hashlib
import json
from odoo.http import request
import time

_logger = logging.getLogger(__name__)


class PaymentTransaction(models.Model):
    _inherit = 'payment.transaction'

    pesapal_access_token = fields.Char(string='Pesapal Access Token')

    def _get_specific_rendering_values(self, processing_values):
        res = super()._get_specific_rendering_values(processing_values)
        if self.provider_code != 'pesapal':
            return res
        rendering_values = {}

        api_url = self._get_pesapal_endpoints()
        consumer_key = self.provider_id.consumer_key
        consumer_secret = self.provider_id.consumer_secret

        # Prepare the URL and headers
        url = f"{api_url}/api/Auth/RequestToken"
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
        # Prepare the data for generate token
        data = {
            "consumer_key": consumer_key,
            "consumer_secret": consumer_secret
        }
        try:
            response = requests.post(url, headers=headers, json=data)
            # Print status code and raw response
            response_json = response.json()
            if response_json.get('status') == '200':
                token = response_json.get('token')
                self.pesapal_access_token = token
                register_ipn = self.pesapal_register_ipn(token)
                ipn_id = register_ipn.get('ipn_id')

                order_request = self.submit_order_request(processing_values, ipn_id, token)
                if order_request.get('status') == '200':
                    rendering_values.update({
                        'api_url': order_request.get('redirect_url'),
                    })
                else:
                    raise UserError(_(order_request.get('error', {}).get('message')))
            else:
                raise UserError(_(response_json.get('error', {}).get('message')))

        except requests.exceptions.RequestException as e:
            # print(f"Request failed: {e}")
            _logger.info(f"Request failed: {e}")

        return rendering_values

    def submit_order_request(self, processing_values, ipn_id, token):
        amount = processing_values.get('amount')
        base_currency_id = self.env['res.currency'].browse(processing_values.get('currency_id'))
        if base_currency_id.name != 'USD':
            usd_currency_id = self.env['res.currency'].search([('name', '=', 'USD')], limit=1)
            amount = base_currency_id._convert(
                processing_values.get('amount'),
                usd_currency_id,
                self.env.company,
                fields.Date.context_today(self),
            )

        api_url = self._get_pesapal_endpoints()
        url = f"{api_url}/api/Transactions/SubmitOrderRequest"

        # Get the base URL
        base_url = self.get_base_url()
        base_amount = processing_values.get('amount')
        payload = json.dumps({
            "id": self.reference,  # should be removed the + "1"
            "currency": base_currency_id.name,
            "amount": base_amount,
            "description": self.reference,
            "callback_url": f"{base_url}/payment/pesapal/redirect",
            "notification_id": ipn_id,
            "billing_address": {
                "email_address": self.partner_id.email,
                "phone_number": self.partner_id.mobile if self.partner_id.mobile else self.partner_id.phone,
                "country_code": self.partner_id.country_code,
                "first_name": self.partner_id.name,
                "middle_name": "",
                "last_name": "",
                "line_1": self.partner_id.street,
                "line_2": self.partner_id.street2,
                "city": self.partner_id.city,
                "state": self.partner_id.state_id.name,
                "postal_code": self.partner_id.zip,
                "zip_code": self.partner_id.zip
            }
        })
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}"
        }

        try:
            # Send the POST request
            response = requests.request("POST", url, headers=headers, data=payload)
        except requests.exceptions.RequestException as e:
            _logger.info(f"Request failed: {e}")
            return None  # Optionally return None or handle the error appropriately

        return response.json()

    def pesapal_register_ipn(self, token):
        # Build the API URL
        api_url = self._get_pesapal_endpoints()
        url = f"{api_url}/api/URLSetup/RegisterIPN"

        # Get the base URL
        base_url = self.get_base_url()

        # Prepare the payload
        payload = {
            "url": f"{base_url}/RegisterIPN",
            "ipn_notification_type": "POST"
        }

        # Convert payload to JSON string
        payload_json = json.dumps(payload)

        # Prepare headers
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}"
        }
        try:
            # Send the POST request
            response = requests.request("POST", url, headers=headers, data=payload_json)
            # Check for HTTP errors
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            _logger.info(f"Request failed: {e}")
            return None  # Optionally return None or handle the error appropriately

        try:
            # Return the JSON response
            return response.json()
        except ValueError:
            return None

    def _get_pesapal_endpoints(self):
        """ waafipay URLS """
        if self.provider_id.state == 'enabled':
            return 'https://pay.pesapal.com/v3'
        else:
            return 'https://cybqa.pesapal.com/pesapalv3'

    @api.model
    def _get_tx_from_notification_data(self, provider, data):
        print("provider, data___", provider, data)
        tx = super()._get_tx_from_notification_data(provider, data)
        if provider != 'pesapal':
            return tx

        reference = data.get('OrderMerchantReference')
        tx = self.search([('reference', '=', reference), ('provider_code', '=', 'pesapal')])
        if not tx:
            raise ValidationError(
                "Pesapal: " + _("No transaction found matching reference %s.", reference)
            )
        return tx

    def _process_notification_data(self, data):
        super()._process_notification_data(data)
        if self.provider_code != 'pesapal':
            return
        payment_transaction_status = self.get_pesapal_payment_transaction_status(data.get('OrderTrackingId'))
        if payment_transaction_status.get('status_code') == 1:
            self._set_done()
        else:
            self._set_canceled()

    def get_pesapal_payment_transaction_status(self, order_tracking_id):
        api_url = self._get_pesapal_endpoints()
        url = f"{api_url}/api/Transactions/GetTransactionStatus?orderTrackingId={order_tracking_id}"
        payload = {}
        token = self.pesapal_access_token
        headers = {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            "Authorization": f"Bearer {token}"
        }

        try:
            # Send the POST request
            response = requests.request("GET", url, headers=headers, data=payload)
            # Check for HTTP errors
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            _logger.info(f"Request failed: {e}")
            return None  # Optionally return None or handle the error appropriately

        try:
            # Return the JSON response
            return response.json()
        except ValueError:
            return None # Optionally return None or handle the error appropriately
