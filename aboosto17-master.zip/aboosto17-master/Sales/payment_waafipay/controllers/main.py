#
# Copyright (c) 2024 DPO Group (Pty) Ltd
#
# Author: App Inlet (Pty) Ltd
#
# Released under the GNU General Public License
#

import logging
import pprint

from odoo import http
from odoo.http import request

_logger = logging.getLogger(__name__)


class WaafiController(http.Controller):

    @http.route('/payment/waafi/status/<string:order_reference>', type='http', auth="public", methods=['GET', 'POST'], csrf=False)
    def waafi_return_from_redirect(self, order_reference, **data):
        """ Waafi Pay return """
        print("order_reference___", order_reference)
        print("waafi_return_from_redirect___data___", data)
        tx_id = request.env['payment.transaction'].search([('reference', '=', order_reference)])
        tx_id.waafipayment_token = data.get('hppResultToken')
        _logger.info("received WAAFI Payment return data:\n%s", pprint.pformat(data))
        request.env['payment.transaction'].sudo()._handle_notification_data('waafipay', order_reference)
        return request.redirect('/payment/status')
