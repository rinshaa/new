import http.client
import requests
import logging
import re
import unicodedata

import xml.etree.ElementTree as ET
from datetime import datetime

from odoo import models, _, api, fields
from odoo.exceptions import ValidationError, UserError
from odoo.tools import float_compare
from werkzeug import urls

import hashlib
import json
from odoo.http import request
import time

_logger = logging.getLogger(__name__)


class PaymentTransaction(models.Model):
    _inherit = 'payment.transaction'

    waafipayment_token = fields.Char(string='Waafi Payment Token')

    def _get_specific_rendering_values(self, processing_values):
        res = super()._get_specific_rendering_values(processing_values)
        if self.provider_code != 'waafipay':
            return res
        rendering_values = {}

        amount = processing_values.get('amount')
        base_currency_id = self.env['res.currency'].browse(processing_values.get('currency_id'))
        if base_currency_id.name != 'USD':
            usd_currency_id = self.env['res.currency'].search([('name', '=', 'USD')], limit=1)
            amount = base_currency_id._convert(
                processing_values.get('amount'),
                usd_currency_id,
                self.env.company,
                fields.Date.context_today(self),
            )

        payload = {
            "schemaVersion": "1.0",
            # "requestId": "WAAFI-" + str(self.reference),
            "requestId": "WAAFI-" + str(fields.Datetime.now()),
            "timestamp": str(fields.Datetime.now()),
            "channelName": "WEB",
            "serviceName": "HPP_PURCHASE",
            "serviceParams": {
                "merchantUid": self.provider_id.waafipay_merchant_id,
                "storeId": self.provider_id.waafipay_storeid,
                "hppKey": self.provider_id.waafipay_hppkey,
                "hppSuccessCallbackUrl": f"{self.get_base_url()}/payment/waafi/status/{self.reference}",
                "hppFailureCallbackUrl": f"{self.get_base_url()}/payment/waafi/status/{self.reference}",
                "hppRespDataFormat": "4",
                "paymentMethod": "MWALLET_ACCOUNT",
                "transactionInfo": {
                    "referenceId": "WAAFI-" + str(self.reference),
                    "invoiceId": self.reference,
                    "amount": amount,
                    "currency": "USD",
                    "description": "Payment for %s" % self.reference,
                }
            }
        }
        endpoint = self._get_waafipay_endpoints()
        try:
            response = requests.post(endpoint, json=payload, headers={'Content-Type': 'application/json'})
            # response_data = response.json()
            # time.sleep(10)
        except requests.exceptions.RequestException as e:
            print(f"Error making API request: {e}")
            raise UserError(_(e))
        if response.ok:
            response_content = response.json()
            if response_content['responseMsg'] == 'RCS_SUCCESS':
                rendering_values.update({
                    # 'hppUrl': "https://sandbox.waafipay.net/hpp/token/61576E3169523466315438386C554634636148732F773D3D",
                    'hppUrl': response_content.get('params').get('hppUrl'),
                    "hppRequestId": response_content.get('params').get('hppRequestId'),
                    "referenceId": response_content.get('params').get('referenceId'),
                })
            else:
                raise UserError(_(response_content.get('responseMsg')))

        return rendering_values

    def _get_waafipay_endpoints(self):
        """ waafipay URLS """
        if self.provider_id.state == 'enabled':
            return 'https://api.waafipay.net/asm'
        else:
            return 'https://sandbox.waafipay.net/asm'

    @api.model
    def _get_tx_from_notification_data(self, provider, data):
        tx = super()._get_tx_from_notification_data(provider, data)
        if provider != 'waafipay':
            return tx

        reference = data
        tx = self.search([('reference', '=', reference), ('provider_code', '=', 'waafipay')])
        if not tx:
            raise ValidationError(
                "WaafiPay: " + _("No transaction found matching reference %s.", reference)
            )
        return tx

    def _process_notification_data(self, data):
        super()._process_notification_data(data)
        if self.provider_code != 'waafipay':
            return
        request_param = {
            "schemaVersion": "1.0",
            "requestId": "WAAFI-" + str(fields.Datetime.now()),
            "timestamp": str(fields.Datetime.now()),
            "channelName": "WEB",
            "serviceName": "HPP_GETRESULTINFO",
            "serviceParams": {
                "merchantUid": self.provider_id.waafipay_merchant_id,
                "storeId": self.provider_id.waafipay_storeid,
                "hppKey": self.provider_id.waafipay_hppkey,
                "hppResultToken": self.waafipayment_token
            }
        }
        # Encode it into a JSON string.
        url = self._get_waafipay_endpoints()
        response = requests.post(url, json=request_param, headers={'Content-Type': 'application/json'})
        response_data = response.json()
        if response_data.get('params').get('state') == 'APPROVED':
            self._set_done()
        else:
            self._set_canceled()
