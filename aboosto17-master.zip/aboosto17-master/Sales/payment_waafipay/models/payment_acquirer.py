import logging

from odoo import fields, models

_logger = logging.getLogger(__name__)


class PaymentAcquirer(models.Model):
    _inherit = 'payment.provider'

    code = fields.Selection(selection_add=[('waafipay', "Waafipay")], ondelete={'waafipay': 'set default'})
    waafipay_merchant_id = fields.Char(string="Merchant ID", required_if_provider='waafipay')
    waafipay_storeid = fields.Char(string="Store ID", required_if_provider='waafipay')
    waafipay_hppkey = fields.Char(string="HPP Key", required_if_provider='waafipay')
    # bank = fields.Boolean(string="Bank Account")
    # creditcard = fields.Boolean(string="Credit Card")
    # mobilwallet = fields.Boolean(string="Mobile Account")

    def _get_default_payment_method_id(self, *_args):
        self.ensure_one()
        if self.code != 'waafipay':
            return super()._get_default_payment_method_id()
        return self.env.ref('payment_waafipay.payment_method_waafipay').id

