from odoo import http
from odoo.exceptions import UserError
from odoo.http import request


class ProgramChart(http.Controller):


    @http.route('/get/project', type='json', auth='public', method=['POST'], csrf=False)
    def get_employee_ids(self):
        program_project = request.env['program.project'].sudo().search([])
        names = []
        key = []
        if len(program_project) == 1:
            key.append(program_project.id)
            key.append(len(program_project.child_ids))
            return key
        else:
            for pr in program_project:
                names.append(pr.name)
                
    

    




