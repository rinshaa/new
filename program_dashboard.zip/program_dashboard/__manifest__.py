

{
    'name': 'Odoo 14 Program Dashboard.',
    'version': '14.0.1.0.1',
    'sequence': 4,
    'summary': 'Odoo 14 Program Dashboard',
    'category' : 'Extra Tools',
    'description': """
    		Program Dashboard in odoo 14
    """,
    'author': 'Bassam Infotech LLP',
    'website' : 'https://www.bassaminfotech.com',
    'depends': ['base',"pivot_activity_customization"],
    
    'data': [   'views/assets.xml',
                'views/pivot_program_dashboard.xml',
                'security/ir.model.access.csv',
             ],
    'qweb': ['static/src/xml/program_dashboard.xml',
             'static/src/xml/program_redirect.xml'],
    'installable': True,
    'application': True,
    'auto_install': False,
    'images': [ 
    ],

}
