odoo.define("program_dashboard.program_dashboard", function (require) {
    "use strict";
    
    const core = require('web.core');
    const AbstractAction = require('web.AbstractAction');
    const Dialog = require('web.Dialog');
    const ajax = require('web.ajax');
    const QWeb = core.qweb;
    var _t = core._t;
  
    const OrgChartProgram = AbstractAction.extend({
        events: {
            'click .program': 'view_sub_program_dashboard',
            'click .project': 'view_sub_project_dashboard',
            'click .task': 'view_sub_task_dashboard',
            'click .dashboard-search-button': 'searchNodes',
            'change .dashboard-favorites-dropdown': 'applyFavoriteFilter',
            'click .dashboard-save-favorite-button': 'saveFavorite',
            'click .dashboard-delete-favorite-button': 'deleteFavorite',
        },
        init: function (parent, context) {
            this._super(parent, context);
            this.program_data = []; // Store the full hierarchy data
            this.searchTerm = '';   // Current search term
            this.favorites = [];    // Store favorite filters

            this._fetchFavorites();
            if (context.tag === 'program_dashboard_chart') {
                this._fetchProgramData();
            }
        },

        /**
         * Fetch Program Hierarchy Data
         */
        _fetchProgramData: function () {
            ajax.jsonRpc('/get_program_dashboard', 'call', {}).then((data) => {
                this.program_data = data.hierarchy_data;
                this._renderHierarchy(this.program_data);
            });
        },

        /**
         * Render Program Hierarchy Data
         */
        _renderHierarchy(data) {
            const container = this.$('.program-nodes-container');
            container.empty();
            data.forEach((node, index) => this._renderNode(node, container, index === 0)); // Mark first node as root
            data.forEach(node => this._bindClickEvents(node));
        },

        _bindClickEvents(node) {
            console.log(node,'fsdfsdfsdfsdfsd')
            this.$('.program').on('click', this.view_sub_program_dashboard(node.id));
            this.$('.project').on('click', this.view_sub_project_dashboard(node.id));
            this.$('.task').on('click', this.view_sub_task_dashboard(node.id));
        },
        

        /**
         * Render a Single Node
         */
        _renderNode(node, container, isRoot = false) {
            // Create the main node HTML structure
            const nodeHtml = `
                <div class="node-container">
                    ${isRoot ? '' : '<div class="node-values"></div>'} <!-- Remove line for root node -->
                    <div class="node ${node.type} ${node.highlight ? 'highlight-node' : ''}">
                        <span class="node-title">${node.name}</span>
                    </div>
                </div>
            `;
        
            // Append the node to the container
            const $node = $(nodeHtml);
            $node.data('id', node.id);
        
            // Bind click events based on node type
            if (node.type === 'program') {
                $node.addClass('program').on('click', this.view_sub_program_dashboard.bind(this));
            } else if (node.type === 'project') {
                $node.addClass('project').on('click', this.view_sub_project_dashboard.bind(this));
            } else if (node.type === 'task') {
                $node.addClass('task').on('click', this.view_sub_task_dashboard.bind(this));
            }
            container.append($node);
        
            // Render children if they exist
            if (node.children && node.children.length > 0) {
                const $childrenContainer = $('<div class="node-children-containers"></div>');
                node.children.forEach(child => this._renderNode(child, $childrenContainer, false));
                container.append($childrenContainer);
            }
        },
        
        
        /**
         * Search Nodes Based on Input
         */
        searchNodes: function () {
            const searchTerm = this.$('.dashboard-search-input').val().toLowerCase();
            this.searchTerm = searchTerm;

            // Filter the program data based on the search term
            const filteredData = this._filterNodes(this.program_data, searchTerm);
            this._renderHierarchy(filteredData);
        },


        _filterNodes: function (nodes, searchTerm) {
            const filteredNodes = [];

            const highlightText = (text) => {
                if (!text) return text;
                const regex = new RegExp(`(${searchTerm})`, 'gi');
                return text.replace(regex, '<span class="highlighted">$1</span>');
            };

            nodes.forEach(node => {
                // Check if the current node matches the search term
                const nodeMatches = node.name.toLowerCase().includes(searchTerm);

                if (nodeMatches) {
                    // Include only direct children, do not process further recursively
                    const directChildren = node.children ? node.children.map(child => ({
                        ...child,
                        children: [] // Empty out further nested children
                    })) : [];

                    filteredNodes.push({
                        ...node,
                        name: highlightText(node.name),
                        highlight: true,
                        children: directChildren, // Only direct children
                    });
                } else if (node.children && node.children.length > 0) {
                    // If parent doesn't match, check its children recursively
                    const filteredChildren = this._filterNodes(node.children, searchTerm);
                    if (filteredChildren.length > 0) {
                        filteredNodes.push({
                            ...node,
                            name: node.name,
                            children: filteredChildren,
                        });
                    }
                }
            });

            return filteredNodes;
        },   

        /**
         * Apply Saved Favorite Filter
         */
        applyFavoriteFilter: function () {
            const favoriteId = this.$('.dashboard-favorites-dropdown').val();
            const selectedFavorite = this.favorites.find(fav => fav.id === parseInt(favoriteId));

            if (selectedFavorite) {
                this.$('.dashboard-search-input').val(selectedFavorite.search_term);
                this.searchTerm = selectedFavorite.search_term;

                const filteredData = this._filterNodes(this.program_data, this.searchTerm);
                this._renderHierarchy(filteredData);
            }
        },

        /**
         * Save Current Search as Favorite
         */
        saveFavorite: function () {
            const searchTerm = this.searchTerm;
            if (!searchTerm) {
                alert('Please perform a search before saving as a favorite.');
                return;
            }
            const favoriteName = prompt('Enter a name for this favorite:');
            if (favoriteName) {
                this._rpc({
                    model: 'dashboard.favorite',
                    method: 'create',
                    args: [{ name: favoriteName, search_term: searchTerm }],
                }).then(favorite => {
                    this.favorites.push(favorite);
                    this._updateFavoritesDropdown();
                });
            }
        },

        /**
         * Fetch Existing Favorites
         */
        _fetchFavorites: function () {
            this._rpc({
                model: 'dashboard.favorite',
                method: 'search_read',
                fields: ['id', 'name', 'search_term'],
            }).then(favorites => {
                this.favorites = favorites;
                this._updateFavoritesDropdown();
            });
        },

        _updateFavoritesDropdown: function () {
            const $dropdown = this.$('.dashboard-favorites-dropdown');
            $dropdown.empty();
            $dropdown.append('<option value="" selected disabled>Select Favorite</option>');
            this.favorites.forEach(fav => {
                $dropdown.append(`<option value="${fav.id}">${fav.name}</option>`);
            });
        },
    
        
        _renderFilteredData: function (filteredData) {
            this.$('.org-chart-vertical').empty();
        
            const $content = $(QWeb.render('program_dashboard.program_dash_template', {
                widget: {
                    program_data: filteredData,
                    favorites: this.favorites,
                },
            }));
            this.$('.org-chart-vertical').append($content);
        },

        willStart: function () {
            return $.when(ajax.loadLibs(this), this._super());
        },
  
        start: function () {
            return this._super();
        },
  
        _fetchProgramData: function () {
            var self = this;
            this._rpc({ route: '/get/project' })
                .then(function (result) {
                    return self._rpc({
                        model: 'program.dashboard',
                        method: 'get_program_dashboard',
                        args: [result],
                    });
                })
                .then(function (values) {
                    self.program_data = values.hierarchy_data || [];
                    self.render();
                });
        },
  
        render: function () {
            var org_chart_html = QWeb.render('program_dashboard.program_dash_template', {
                widget: this,
            });
            $(".o_control_panel").addClass("o_hidden");
            this.$el.html(org_chart_html);
        },
        // show main program values 
        view_dashboard_program: function (ev) {
          const projectId = $(ev.currentTarget).data("project-id");
      
          if (projectId && $(ev.currentTarget).hasClass('popup-enabled')) {
              this._showProjectDetails(projectId);
          }
      },
  
        _showProjectDetails: function (projectId) {
            var self = this;
            this._rpc({
                model: 'program.project',
                method: 'read',
                args: [[projectId], ['program_number']['name']],
            }).then(function (projectData) {
                if (projectData && projectData.length > 0) {
                    const project = projectData[0];
                    const content = QWeb.render('program_dashboard.project_detail_table', {
                        project: project,
                    });
                  const dialog = new Dialog(this, {
                        size: 'medium',
                        title: "",
                        $content: $(content),
                        backdrop: true, 
                      buttons: [],
                  }).open();
  
                  dialog.opened().then(function () {
                    dialog.$el.on('click', '.fetch-metric-button', function (ev) {
                        self.fetchMetricDetails(ev);  
                    });
                });
                  }
              });
        },
        fetchMetricDetails: function (ev) {
            const projectId = $(ev.currentTarget).data('project-id');
            const self = this;
    
            if (projectId) {
                this._rpc({
                    model: 'metric.metrics',
                    method: 'search_read',
                    domain: [['parent_program_id', '=', projectId]],
                    fields: ['name', 'target', 'latest_value'],
                }).then(function (metrics) {
                    if (metrics.length > 0) {
                        const content = QWeb.render('program_dashboard.metric_detail_table', {
                            metrics: metrics,
                        });
    
                        const dialog = new Dialog(this, {
                            size: 'medium',
                            title: "",
                            $content: $(content),
                            backdrop: true,
                            buttons: [],
                        }).open();
                        dialog.opened().then(function () {
                            dialog.$el.on('click', '.metric-name', function (ev) {
                                self.Show_metric_popup(ev);  
                            });
                        });
                          }
                });
            }
        },
        Show_metric_popup: function (ev) {
            var self = this;
            var metricId = $(ev.currentTarget).data('id');            
            if (metricId) {
                this._rpc({
                    model: 'metric.metrics',
                    method: 'read',
                    args: [[metricId], ['name', 'target', 'latest_value']],
                }).then(function (metric) {
                    if (metric && metric.length > 0) {
                        self._rpc({
                            model: 'metric.value.lines',
                            method: 'search_read',
                            domain: [['metric_value_line_id', '=', metricId]],
                            fields: ['period_name', 'from_date', 'to_date', 'periodic_target', 'value'],
                        }).then(function (metric_lines) {
                            const content = QWeb.render('program_dashboard.metric_popup', {
                                metric: metric[0],
                                metric_lines: metric_lines,
                            });
        
                            const dialog = new Dialog(this, {
                                size: 'medium',
                                title: "",
                                $content: $(content),
                                backdrop: true,
                                buttons: [],
                            }).open();
                            dialog.opened().then(function () {
                                dialog.$el.on('click', '.fetch-sub-metric-button', function (ev) {
                                    self._SubmetricDetails(ev);  // Pass ev to fetchMetricDetails
                                });
                            });
                        });
                    }
                });
            }
        },
        _SubmetricDetails: function (ev) {
            const MetricId = $(ev.currentTarget).data('project-id');
            const self = this;
            console.log(MetricId,'MetricId')
            if (MetricId) {
                this._rpc({
                    model: 'metric.metrics',
                    method: 'search_read',
                    domain: [['parent_metric_id', '=', MetricId]],
                    fields: ['name', 'target', 'latest_value'],
                }).then(function (metrics) {
                    if (metrics.length > 0) {
                        const content = QWeb.render('program_dashboard.metric_detail_table', {
                            metrics: metrics,
                        });
    
                        const dialog = new Dialog(this, {
                            size: 'medium',
                            title: "",
                            $content: $(content),
                            backdrop: true,
                            buttons: [],
                        }).open();
                        dialog.opened().then(function () {
                            dialog.$el.on('click', '.metric-name', function (ev) {
                                self.Show_metric_popup(ev);  
                            });
                        });
                          }
                });
            }

        },
        // show cjild value
        view_child_dashboard: function (ev) {
            const childNodeId = $(ev.currentTarget).data("id");
            if (childNodeId) {
                this._showChildNodeDetails(childNodeId);
            }
        },

        // Show details of a child node
        _showChildNodeDetails: function (childNodeId) {
            var self = this;
            this._rpc({
                model: 'program.project',
                method: 'read',
                args: [[childNodeId], ['program_number']['name']],
            }).then(function (childData) {
                if (childData && childData.length > 0) {
                    const child = childData[0];
                    const content = QWeb.render('program_dashboard.project_detail_table', {
                        project: child,
                    });

                    const dialog = new Dialog(self, {
                        size: 'medium',
                        title: "",
                        $content: $(content),
                        backdrop: true,
                        buttons: [],
                    }).open();
                    dialog.opened().then(function () {
                        dialog.$el.on('click', '.fetch-metric-button', function (ev) {
                            self.ChildfetchMetricDetails(ev);  // Pass ev to fetchMetricDetails
                        });
                    });
                }
            });
        },

        // Function to fetch metrics for the child node (same as parent)
        ChildfetchMetricDetails: function (ev) {
            const projectId = $(ev.currentTarget).data('project-id');
            const self = this;
            if (projectId) {
                // Fetch metric details for the selected project
                this._rpc({
                    model: 'metric.metrics',
                    method: 'search_read',
                    domain: [['parent_program_id', '=', projectId]],
                    fields: ['name', 'target', 'latest_value'],
                }).then(function (metrics) {
                    if (metrics.length > 0) {
                        // Render the dialog content with metrics data
                        const content = QWeb.render('program_dashboard.metric_detail_table', {
                            metrics: metrics,
                        });
    
                        const dialog = new Dialog(self, {
                            size: 'medium',
                            title: "",
                            $content: $(content),
                            backdrop: true,
                            buttons: [],
                        }).open();
                        dialog.opened().then(function () {
                            dialog.$el.on('click', '.metric-name', function (ev) {
                                self.child_Show_metric_popup(ev);  // Pass ev to fetchMetricDetails
                            });
                        });
                          }
                });
            }
        },

        child_Show_metric_popup: function (ev) {
            var self = this;
            var metricId = $(ev.currentTarget).data('id');            
            if (metricId) {
                // Fetch the metric details by ID, including metric lines
                this._rpc({
                    model: 'metric.metrics',
                    method: 'read',
                    args: [[metricId], ['name', 'target', 'latest_value']],
                }).then(function (metric) {
                    if (metric && metric.length > 0) {
                        // Fetch metric lines separately using search_read
                        self._rpc({
                            model: 'metric.value.lines',
                            method: 'search_read',
                            domain: [['metric_value_line_id', '=', metricId]],
                            fields: ['period_name', 'from_date', 'to_date', 'periodic_target', 'value'],
                            
                        }).then(function (metric_lines) {
                            const content = QWeb.render('program_dashboard.metric_popup', {
                                metric: metric[0],
                                metric_lines: metric_lines,
                            });
        
                            // Open the dialog with the metric details and metric lines
                            const dialog = new Dialog(this, {
                                size: 'medium',
                                title: "",
                                $content: $(content),
                                backdrop: true,
                                buttons: [],
                            }).open();
                            dialog.opened().then(function () {
                                dialog.$el.on('click', '.fetch-sub-metric-button', function (ev) {
                                    self._SubmetricDetails(ev);  // Pass ev to fetchMetricDetails
                                });
                            });
                        });
                    }
                });
            }
        },
        // show task values
        view_task_child_dashboard: function (ev) {
            const ViewChildvalue = $(ev.currentTarget).data("id");
            if (ViewChildvalue) {
                this._showSubChildNodeDetails(ViewChildvalue);
            }
        },

        // Show details of a child node
        _showSubChildNodeDetails: function (ViewChildvalue) {
            var self = this;
            this._rpc({
                model: 'project.project',
                method: 'read',
                args: [[ViewChildvalue], ['name', 'number', 'owner_id','planned_start_date','planned_end_date','actual_start_date',
                    'actual_end_date','department_id','category_id','prj_type_id','priority','complete','total_effort','budget_amount','actual_amount','variance','variance_percentage']],
            }).then(function (childDatas) {
                if (childDatas && childDatas.length > 0) {
                    const child = childDatas[0];
                    const content = QWeb.render('program_dashboard.project_detail_table_value', {
                        project: child,
                    });

                    const dialog = new Dialog(self, {
                        size: 'medium',
                        title: "",
                        $content: $(content),
                        backdrop: true,
                        buttons: [],
                    }).open();
                    dialog.opened().then(function () {
                        dialog.$el.on('click', '.fetch-metric-button', function (ev) {
                            self.SubchildfetchMetricDetails(ev);  // Pass ev to fetchMetricDetails
                        });
                    });
                }
            });
        },

        // Function to fetch metrics for the child node (same as parent)
        SubchildfetchMetricDetails: function (ev) {
            const projectId = $(ev.currentTarget).data('project-id');
            const self = this;
            if (projectId) {
                // Fetch metric details for the selected project
                this._rpc({
                    model: 'metric.metrics',
                    method: 'search_read',
                    domain: [['parent_project_id', '=', projectId]],
                    fields: ['name', 'target', 'latest_value'],
                }).then(function (metrics) {
                    if (metrics.length > 0) {
                        // Render the dialog content with metrics data
                        const content = QWeb.render('program_dashboard.metric_detail_table', {
                            metrics: metrics,
                        });
    
                        const dialog = new Dialog(self, {
                            size: 'medium',
                            title: "",
                            $content: $(content),
                            backdrop: true,
                            buttons: [],
                        }).open();
                        dialog.opened().then(function () {
                            dialog.$el.on('click', '.metric-name', function (ev) {
                                self.sub_child_Show_metric_popup(ev);  // Pass ev to fetchMetricDetails
                            });
                        });
                          }
                });
            }
        },

        sub_child_Show_metric_popup: function (ev) {
            var self = this;
            var metricId = $(ev.currentTarget).data('id');            
            if (metricId) {
                // Fetch the metric details by ID, including metric lines
                this._rpc({
                    model: 'metric.metrics',
                    method: 'read',
                    args: [[metricId], ['name', 'target', 'latest_value']],
                }).then(function (metric) {
                    if (metric && metric.length > 0) {
                        // Fetch metric lines separately using search_read
                        self._rpc({
                            model: 'metric.value.lines',
                            method: 'search_read',
                            domain: [['metric_value_line_id', '=', metricId]],
                            fields: ['period_name', 'from_date', 'to_date', 'periodic_target', 'value'],
                        }).then(function (metric_lines) {
                            const content = QWeb.render('program_dashboard.metric_popup', {
                                metric: metric[0],
                                metric_lines: metric_lines,
                            });
        
                            // Open the dialog with the metric details and metric lines
                            const dialog = new Dialog(this, {
                                size: 'medium',
                                title: "",
                                $content: $(content),
                                backdrop: true,
                                buttons: [],
                            }).open();
                            dialog.opened().then(function () {
                                dialog.$el.on('click', '.fetch-sub-metric-button', function (ev) {
                                    self._SubmetricDetails(ev);  // Pass ev to fetchMetricDetails
                                });
                            });
                        });
                    }
                });
            }
        },

        // show sub task values
        view_sub_task_dashboard: function (ev) {
            const subTask = $(ev.currentTarget).data("id");
            if (subTask) {
                this._showSubtaskDetails(subTask);
            }
        },

        _showSubtaskDetails: function (subTask) {
            var self = this;
            this._rpc({
                model: 'project.task',
                method: 'read',
                args: [[subTask], ['name', 'task_number', 'owner_id','planned_start_date','planned_end_date','actual_start_date',
                    'actual_end_date','department_id','task_category_id','type','task_priority','complete_percentage','total_effort','budget_amount','actual_amount','variance','variance_percentage']],
            }).then(function (childDatas) {
                if (childDatas && childDatas.length > 0) {
                    const sub_task = childDatas[0];
                    const content = QWeb.render('program_dashboard.project_task_details_value', {
                        project: sub_task,
                    });

                    const dialog = new Dialog(self, {
                        size: 'medium',
                        title: "",
                        $content: $(content),
                        backdrop: true,
                        buttons: [],
                    }).open();
                    dialog.opened().then(function () {
                        dialog.$el.on('click', '.fetch-metric-button', function (ev) {
                            self.SubprojectTaskdetails(ev);  // Pass ev to fetchMetricDetails
                        });
                    });
                }
            });
        },
        SubprojectTaskdetails: function (ev) {
            const SubtaskId = $(ev.currentTarget).data('project-id');
            const self = this;
            if (SubtaskId) {
                // Fetch metric details for the selected project
                this._rpc({
                    model: 'metric.metrics',
                    method: 'search_read',
                    domain: [['parent_task_id', '=', SubtaskId]],
                    fields: ['name', 'target', 'latest_value'],
                }).then(function (metrics) {
                    if (metrics.length > 0) {
                        // Render the dialog content with metrics data
                        const content = QWeb.render('program_dashboard.metric_detail_table', {
                            metrics: metrics,
                        });
    
                        const dialog = new Dialog(self, {
                            size: 'medium',
                            title: "",
                            $content: $(content),
                            backdrop: true,
                            buttons: [],
                        }).open();
                        dialog.opened().then(function () {
                            dialog.$el.on('click', '.metric-name', function (ev) {
                                self.sub_task_Show_metric_popup(ev);  // Pass ev to fetchMetricDetails
                            });
                        });
                          }
                });
            }
        },

        sub_task_Show_metric_popup: function (ev) {
            var self = this;
            var metricId = $(ev.currentTarget).data('id');            
            if (metricId) {
                // Fetch the metric details by ID, including metric lines
                this._rpc({
                    model: 'metric.metrics',
                    method: 'read',
                    args: [[metricId], ['name', 'target', 'latest_value']],
                }).then(function (metric) {
                    if (metric && metric.length > 0) {
                        // Fetch metric lines separately using search_read
                        self._rpc({
                            model: 'metric.value.lines',
                            method: 'search_read',
                            domain: [['metric_value_line_id', '=', metricId]],
                            fields: ['period_name', 'from_date', 'to_date', 'periodic_target', 'value'],
                        }).then(function (metric_lines) {
                            const content = QWeb.render('program_dashboard.metric_popup', {
                                metric: metric[0],
                                metric_lines: metric_lines,
                            });
        
                            // Open the dialog with the metric details and metric lines
                            const dialog = new Dialog(this, {
                                size: 'medium',
                                title: "",
                                $content: $(content),
                                backdrop: true,
                                buttons: [],
                            }).open();
                            dialog.opened().then(function () {
                                dialog.$el.on('click', '.fetch-sub-metric-button', function (ev) {
                                    self._SubmetricDetails(ev);  // Pass ev to fetchMetricDetails
                                });
                            });
                        });
                    }
                });
            }
        },
        // sub sub task details
        view_sub_sub_task_dashboard: function (ev) {
            const subTask = $(ev.currentTarget).data("id");
            if (subTask) {
                this._showSubsubtaskDetails(subTask);
            }
        },

        _showSubsubtaskDetails: function (subTask) {
            var self = this;
            this._rpc({
                model: 'project.task',
                method: 'read',
                args: [[subTask], ['name', 'task_number', 'owner_id','planned_start_date','planned_end_date','actual_start_date',
                    'actual_end_date','department_id','task_category_id','type','task_priority','complete_percentage','total_effort','budget_amount','actual_amount','variance','variance_percentage']],
            }).then(function (childDatas) {
                if (childDatas && childDatas.length > 0) {
                    const sub_task = childDatas[0];
                    const content = QWeb.render('program_dashboard.project_task_details_value', {
                        project: sub_task,
                    });

                    const dialog = new Dialog(self, {
                        size: 'medium',
                        title: "",
                        $content: $(content),
                        backdrop: true,
                        buttons: [],
                    }).open();
                    dialog.opened().then(function () {
                        dialog.$el.on('click', '.fetch-metric-button', function (ev) {
                            self.SubsubprojectTaskdetails(ev);  // Pass ev to fetchMetricDetails
                        });
                    });
                }
            });
        },
        SubsubprojectTaskdetails: function (ev) {
            const SubtaskId = $(ev.currentTarget).data('project-id');
            const self = this;
            if (SubtaskId) {
                // Fetch metric details for the selected project
                this._rpc({
                    model: 'metric.metrics',
                    method: 'search_read',
                    domain: [['parent_task_id', '=', SubtaskId]],
                    fields: ['name', 'target', 'latest_value'],
                }).then(function (metrics) {
                    if (metrics.length > 0) {
                        // Render the dialog content with metrics data
                        const content = QWeb.render('program_dashboard.metric_detail_table', {
                            metrics: metrics,
                        });
    
                        const dialog = new Dialog(self, {
                            size: 'medium',
                            title: "",
                            $content: $(content),
                            backdrop: true,
                            buttons: [],
                        }).open();
                        dialog.opened().then(function () {
                            dialog.$el.on('click', '.metric-name', function (ev) {
                                self.sub_sub_task_Show_metric_popup(ev);  // Pass ev to fetchMetricDetails
                            });
                        });
                          }
                });
            }
        },

        sub_sub_task_Show_metric_popup: function (ev) {
            var self = this;
            var metricId = $(ev.currentTarget).data('id');            
            if (metricId) {
                // Fetch the metric details by ID, including metric lines
                this._rpc({
                    model: 'metric.metrics',
                    method: 'read',
                    args: [[metricId], ['name', 'target', 'latest_value']],
                }).then(function (metric) {
                    if (metric && metric.length > 0) {
                        // Fetch metric lines separately using search_read
                        self._rpc({
                            model: 'metric.value.lines',
                            method: 'search_read',
                            domain: [['metric_value_line_id', '=', metricId]],
                            fields: ['period_name', 'from_date', 'to_date', 'periodic_target', 'value'],
                        }).then(function (metric_lines) {
                            const content = QWeb.render('program_dashboard.metric_popup', {
                                metric: metric[0],
                                metric_lines: metric_lines,
                            });
        
                            // Open the dialog with the metric details and metric lines
                            const dialog = new Dialog(this, {
                                size: 'medium',
                                title: "",
                                $content: $(content),
                                backdrop: true,
                                buttons: [],
                            }).open();
                            dialog.opened().then(function () {
                                dialog.$el.on('click', '.fetch-sub-metric-button', function (ev) {
                                    self._SubmetricDetails(ev);  // Pass ev to fetchMetricDetails
                                });
                            });
                        });
                    }
                });
            }
        },

        // sub program details
        view_sub_program_dashboard: function (ev) {
            const subprogram = $(ev.currentTarget).data("id");
            console.log(subprogram,'88888888888888888')
            if (subprogram || subprogram != undefined)  {
                this._showsubprogramdetails(subprogram);
            }
        },

        _showsubprogramdetails: function (subprogram) {
            var self = this;
            this._rpc({
                model: 'program.project',
                method: 'read',
                args: [[subprogram], ['program_number']['name']],
            }).then(function (childData) {
                if (childData && childData.length > 0) {
                    const child = childData[0];
                    const content = QWeb.render('program_dashboard.project_detail_table', {
                        project: child,
                    });

                    const dialog = new Dialog(self, {
                        size: 'medium',
                        title: "",
                        $content: $(content),
                        backdrop: true,
                        buttons: [],
                    }).open();
                    dialog.opened().then(function () {
                        dialog.$el.on('click', '.fetch-metric-button', function (ev) {
                            self.SubprogramDetails(ev);  // Pass ev to fetchMetricDetails
                        });
                    });
                }
            });
        },
        SubprogramDetails: function (ev) {
            const projectId = $(ev.currentTarget).data('project-id');
            const self = this;
    
            if (projectId) {
                this._rpc({
                    model: 'metric.metrics',
                    method: 'search_read',
                    domain: [['parent_program_id', '=', projectId]],
                    fields: ['name', 'target', 'latest_value'],
                }).then(function (metrics) {
                    if (metrics.length > 0) {
                        const content = QWeb.render('program_dashboard.metric_detail_table', {
                            metrics: metrics,
                        });
    
                        const dialog = new Dialog(this, {
                            size: 'medium',
                            title: "",
                            $content: $(content),
                            backdrop: true,
                            buttons: [],
                        }).open();
                        dialog.opened().then(function () {
                            dialog.$el.on('click', '.metric-name', function (ev) {
                                self.Show_subprogram_metric_popup(ev);  
                            });
                        });
                          }
                });
            }
        },
        Show_subprogram_metric_popup: function (ev) {
            var self = this;
            var metricId = $(ev.currentTarget).data('id');            
            if (metricId) {
                this._rpc({
                    model: 'metric.metrics',
                    method: 'read',
                    args: [[metricId], ['name', 'target', 'latest_value']],
                }).then(function (metric) {
                    if (metric && metric.length > 0) {
                        self._rpc({
                            model: 'metric.value.lines',
                            method: 'search_read',
                            domain: [['metric_value_line_id', '=', metricId]],
                            fields: ['period_name', 'from_date', 'to_date', 'periodic_target', 'value'],
                        }).then(function (metric_lines) {
                            const content = QWeb.render('program_dashboard.metric_popup', {
                                metric: metric[0],
                                metric_lines: metric_lines,
                            });
        
                            const dialog = new Dialog(this, {
                                size: 'medium',
                                title: "",
                                $content: $(content),
                                backdrop: true,
                                buttons: [],
                            }).open();
                            dialog.opened().then(function () {
                                dialog.$el.on('click', '.fetch-sub-metric-button', function (ev) {
                                    self._SubmetricDetails(ev);  // Pass ev to fetchMetricDetails
                                });
                            });
                        });
                    }
                });
            }
        },
        // main project
        view_sub_project_dashboard: function (ev) {
            const ViewChildvalue = $(ev.currentTarget).data("id");
            if (ViewChildvalue) {
                this._showSProjectNodeDetails(ViewChildvalue);
            }
        },

        // Show details of a child node
        _showSProjectNodeDetails: function (ViewChildvalue) {
            var self = this;
            this._rpc({
                model: 'project.project',
                method: 'read',
                args: [[ViewChildvalue], ['name', 'number', 'owner_id','planned_start_date','planned_end_date','actual_start_date',
                    'actual_end_date','department_id','category_id','prj_type_id','priority','complete','total_effort','budget_amount','actual_amount','variance','variance_percentage']],
            }).then(function (childDatas) {
                if (childDatas && childDatas.length > 0) {
                    const child = childDatas[0];
                    const content = QWeb.render('program_dashboard.project_detail_table_value', {
                        project: child,
                    });

                    const dialog = new Dialog(self, {
                        size: 'medium',
                        title: "",
                        $content: $(content),
                        backdrop: true,
                        buttons: [],
                    }).open();
                    dialog.opened().then(function () {
                        dialog.$el.on('click', '.fetch-metric-button', function (ev) {
                            self.SubprojectfetchMetricDetails(ev);  // Pass ev to fetchMetricDetails
                        });
                    });
                }
            });
        },

        // Function to fetch metrics for the child node (same as parent)
        SubprojectfetchMetricDetails: function (ev) {
            const projectId = $(ev.currentTarget).data('project-id');
            const self = this;
            if (projectId) {
                // Fetch metric details for the selected project
                this._rpc({
                    model: 'metric.metrics',
                    method: 'search_read',
                    domain: [['parent_project_id', '=', projectId]],
                    fields: ['name', 'target', 'latest_value'],
                }).then(function (metrics) {
                    if (metrics.length > 0) {
                        // Render the dialog content with metrics data
                        const content = QWeb.render('program_dashboard.metric_detail_table', {
                            metrics: metrics,
                        });
    
                        const dialog = new Dialog(self, {
                            size: 'medium',
                            title: "",
                            $content: $(content),
                            backdrop: true,
                            buttons: [],
                        }).open();
                        dialog.opened().then(function () {
                            dialog.$el.on('click', '.metric-name', function (ev) {
                                self.sub_child_Show_metric_popup(ev);  // Pass ev to fetchMetricDetails
                            });
                        });
                          }
                });
            }
        },

        sub_child_Show_metric_popup: function (ev) {
            var self = this;
            var metricId = $(ev.currentTarget).data('id');            
            if (metricId) {
                // Fetch the metric details by ID, including metric lines
                this._rpc({
                    model: 'metric.metrics',
                    method: 'read',
                    args: [[metricId], ['name', 'target', 'latest_value']],
                }).then(function (metric) {
                    if (metric && metric.length > 0) {
                        // Fetch metric lines separately using search_read
                        self._rpc({
                            model: 'metric.value.lines',
                            method: 'search_read',
                            domain: [['metric_value_line_id', '=', metricId]],
                            fields: ['period_name', 'from_date', 'to_date', 'periodic_target', 'value'],
                        }).then(function (metric_lines) {
                            const content = QWeb.render('program_dashboard.metric_popup', {
                                metric: metric[0],
                                metric_lines: metric_lines,
                            });
        
                            // Open the dialog with the metric details and metric lines
                            const dialog = new Dialog(this, {
                                size: 'medium',
                                title: "",
                                $content: $(content),
                                backdrop: true,
                                buttons: [],
                            }).open();
                            dialog.opened().then(function () {
                                dialog.$el.on('click', '.fetch-sub-metric-button', function (ev) {
                                    self._SubmetricDetails(ev);  // Pass ev to fetchMetricDetails
                                });
                            });
                        });
                    }
                });
            }
        },
        
        
    });
  
    core.action_registry.add('program_dashboard_chart', OrgChartProgram);
  
    return OrgChartProgram;
  });
  