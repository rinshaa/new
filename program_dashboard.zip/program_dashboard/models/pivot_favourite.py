from odoo import models, fields, http,api
from odoo.http import request

class DashboardFavorite(models.Model):
    _name = 'dashboard.favorite'
    _description = 'Dashboard Favorite Searches'

    name = fields.Char(string="Favorite Name", )
    search_term = fields.Char(string="Search Term",)
