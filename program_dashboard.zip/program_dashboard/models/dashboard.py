from odoo import models, api, fields

class ProgramDashboard(models.Model):
    _name = 'program.dashboard'
    _description = "Program Dashboard"

    @api.model
    def get_program_dashboard(self, emp_id=None):
        """
        Fetch the hierarchical program, project, and task data dynamically.
        """
        parent_projects = self.env['program.project'].search([('parent_view_access', '=', False), ('parent_id', '=', False)])

        data = []
        for parent in parent_projects:
            hierarchy = self._build_hierarchy(parent)
            data.append(hierarchy)

        return {'hierarchy_data': data}

    def _build_hierarchy(self, record):
        """
        Recursively build the hierarchy for a given program, project, or task.
        """

        hierarchy = {
            'id': record.id,
            'name': record.name,
            'type': self._get_record_type(record),
            'children': []
        }

        if not record.parent_id:
            hierarchy['main_project'] = True
        else:
            hierarchy['main_project'] = False

        if record._name == 'program.project':
            child_programs = self.env['program.project'].search([('parent_id', '=', record.id)])
            for child_program in child_programs:
                hierarchy['children'].append(self._build_hierarchy(child_program))

            # Fetch projects under this program
            projects = self.env['project.project'].search([('program_id', '=', record.id), ('parent_id', '=', False)])
            for project in projects:
                hierarchy['children'].append(self._build_hierarchy(project))

            # Fetch tasks directly under this program
            tasks = self.env['project.task'].search([('program_id', '=', record.id), ('parent_id', '=', False), ('project_id', '=', False)])
            for task in tasks:
                hierarchy['children'].append(self._build_hierarchy(task))

        elif record._name == 'project.project':
            # Fetch sub-projects
            sub_projects = self.env['project.project'].search([('parent_id', '=', record.id)])
            for sub_project in sub_projects:
                hierarchy['children'].append(self._build_hierarchy(sub_project))

            tasks = self.env['project.task'].search([('project_id', '=', record.id), ('parent_id', '=', False)])
            for task in tasks:
                hierarchy['children'].append(self._build_hierarchy(task))

        elif record._name == 'project.task':
            sub_tasks = self.env['project.task'].search([('parent_id', '=', record.id)])
            for sub_task in sub_tasks:
                hierarchy['children'].append(self._build_hierarchy(sub_task))

        return hierarchy

    def refresh_hierarchy(self):
        """
        Method to refresh the hierarchy when needed.
        Can be triggered from create/write methods of dependent models.
        """
        return self.get_program_dashboard()

    @api.model
    def create(self, vals):
        """
        Override create method to update the hierarchy dynamically.
        """
        res = super().create(vals)
        self.refresh_hierarchy()
        return res



    def _get_record_type(self, record):
        """
        Determine the type of the record: program, project, or task.
        """
        if record._name == 'program.project':
            return 'program'
        elif record._name == 'project.project':
            return 'project'
        elif record._name == 'project.task':
            return 'task'
        return 'unknown'


class ProgramProject(models.Model):
    _inherit = 'program.project'

    @api.model
    def create(self, vals):
        res = super().create(vals)
        self.env['program.dashboard'].refresh_hierarchy()
        return res

    def write(self, vals):
        res = super().write(vals)
        self.env['program.dashboard'].refresh_hierarchy()
        return res


class ProjectProject(models.Model):
    _inherit = 'project.project'

    @api.model
    def create(self, vals):
        res = super().create(vals)
        self.env['program.dashboard'].refresh_hierarchy()
        return res

    def write(self, vals):
        res = super().write(vals)
        self.env['program.dashboard'].refresh_hierarchy()
        return res


class ProjectTask(models.Model):
    _inherit = 'project.task'

    @api.model
    def create(self, vals):
        res = super().create(vals)
        self.env['program.dashboard'].refresh_hierarchy()
        return res

    def write(self, vals):
        res = super().write(vals)
        self.env['program.dashboard'].refresh_hierarchy()
        return res
    